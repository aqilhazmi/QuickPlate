<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'food_id',
        'food_name',
        'food_description',
        'food_category',
        'unit_price',
        'quantity',
        'subtotal',
        'special_notes',
    ];

    protected $casts = [
        'unit_price' => 'decimal:2',
        'subtotal' => 'decimal:2',
        'quantity' => 'integer',
    ];

    /**
     * Get the order that owns the order item.
     */
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the food item that belongs to the order item.
     */
    public function foodItem()
    {
        return $this->belongsTo(FoodItem::class, 'food_id');
    }

    /**
     * Get formatted unit price.
     */
    public function getFormattedUnitPriceAttribute()
    {
        return 'RM ' . number_format($this->unit_price, 2);
    }

    /**
     * Get formatted subtotal.
     */
    public function getFormattedSubtotalAttribute()
    {
        return 'RM ' . number_format($this->subtotal, 2);
    }

    /**
     * Calculate subtotal based on unit price and quantity.
     */
    public function calculateSubtotal()
    {
        return $this->unit_price * $this->quantity;
    }

    /**
     * Boot method to automatically calculate subtotal.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($orderItem) {
            $orderItem->subtotal = $orderItem->calculateSubtotal();
        });

        static::updating(function ($orderItem) {
            $orderItem->subtotal = $orderItem->calculateSubtotal();
        });
    }
}