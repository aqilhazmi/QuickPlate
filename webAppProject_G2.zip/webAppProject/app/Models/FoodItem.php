<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FoodItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description', 
        'price',
        'category',
        'image',
        'is_available'
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'is_available' => 'boolean'
    ];

    /**
     * Get the full image URL for the food item
     */
    public function getImageUrlAttribute()
    {
    // If no image is set, use default
    if (!$this->image) {
        return asset('assets/img/menu/default.jpg');
    }
    
    // Check if image field contains full URL (PHP compatibility fix)
    if (substr($this->image, 0, 4) === 'http') {
        return $this->image;
    }
    
    // Build URL from filename
    return asset('assets/img/menu/' . $this->image);
    }
    /**
     * Get formatted price
     */
    public function getFormattedPriceAttribute()
    {
        return 'RM ' . number_format($this->price, 2);
    }

    /**
     * Scope for available items
     */
    public function scopeAvailable($query)
    {
        return $query->where('is_available', true);
    }

    /**
     * Scope for specific category
     */
    public function scopeCategory($query, $category)
    {
        return $query->where('category', $category);
    }
}