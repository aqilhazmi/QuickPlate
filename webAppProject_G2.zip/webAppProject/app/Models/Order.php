<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'customer_name',
        'customer_email',
        'customer_phone',
        'delivery_address',
        'postal_code',
        'city',
        'state',
        'status',
        'payment_method',
        'payment_status',
        'subtotal',
        'delivery_fee',
        'service_tax',
        'total_amount',
        'special_instructions',
        'estimated_delivery_time',
        'delivered_at',
        'cancellation_reason',
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'delivery_fee' => 'decimal:2',
        'service_tax' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'estimated_delivery_time' => 'datetime',
        'delivered_at' => 'datetime',
    ];

    /**
     * Get the user that owns the order.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the order items for the order.
     */
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Get the order items with food item details.
     */
    public function orderItemsWithFood()
    {
        return $this->orderItems()->with('foodItem');
    }

    /**
     * Get formatted total amount.
     */
    public function getFormattedTotalAttribute()
    {
        return 'RM ' . number_format($this->total_amount, 2);
    }

    /**
     * Get formatted subtotal.
     */
    public function getFormattedSubtotalAttribute()
    {
        return 'RM ' . number_format($this->subtotal, 2);
    }

    /**
     * Get formatted delivery fee.
     */
    public function getFormattedDeliveryFeeAttribute()
    {
        return 'RM ' . number_format($this->delivery_fee, 2);
    }

    /**
     * Get formatted service tax.
     */
    public function getFormattedServiceTaxAttribute()
    {
        return 'RM ' . number_format($this->service_tax, 2);
    }

    /**
     * Get status badge color for UI.
     */
    public function getStatusBadgeColorAttribute()
    {
        return match($this->status) {
            'pending' => 'warning',
            'confirmed' => 'info',
            'preparing' => 'primary',
            'out_for_delivery' => 'success',
            'delivered' => 'success',
            'cancelled' => 'danger',
            default => 'secondary'
        };
    }

    /**
     * Get status color (alias for tracking view compatibility).
     */
    public function getStatusColorAttribute()
    {
        return $this->status_badge_color;
    }

    /**
     * Get human readable status.
     */
    public function getStatusLabelAttribute()
    {
        return match($this->status) {
            'pending' => 'Pending Confirmation',
            'confirmed' => 'Order Confirmed',
            'preparing' => 'Preparing Your Food',
            'out_for_delivery' => 'Out for Delivery',
            'delivered' => 'Delivered',
            'cancelled' => 'Cancelled',
            default => ucfirst($this->status)
        };
    }

    /**
     * Get status text (alias for tracking view compatibility).
     */
    public function getStatusTextAttribute()
    {
        return match($this->status) {
            'pending' => 'Order Received',
            'confirmed' => 'Order Confirmed',
            'preparing' => 'Preparing',
            'out_for_delivery' => 'Out for Delivery',
            'delivered' => 'Delivered',
            'cancelled' => 'Cancelled',
            default => ucfirst($this->status)
        };
    }

    /**
     * Get Bootstrap badge class for status.
     */
    public function getStatusBadgeClass()
    {
        return 'bg-' . $this->status_badge_color;
    }

    /**
     * Get payment status badge color.
     */
    public function getPaymentStatusBadgeColorAttribute()
    {
        return match($this->payment_status) {
            'pending' => 'warning',
            'paid' => 'success',
            'failed' => 'danger',
            'refunded' => 'info',
            default => 'secondary'
        };
    }

    /**
     * Get order number (formatted ID).
     */
    public function getOrderNumberAttribute()
    {
        return 'QP' . str_pad($this->id, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Get total items count.
     */
    public function getTotalItemsAttribute()
    {
        return $this->orderItems->sum('quantity');
    }

    /**
     * Check if order can be cancelled.
     */
    public function canBeCancelled()
    {
        return in_array($this->status, ['pending', 'confirmed']);
    }

    /**
     * Check if order is completed.
     */
    public function isCompleted()
    {
        return $this->status === 'delivered';
    }

    /**
     * Check if order is active (not cancelled or delivered).
     */
    public function isActive()
    {
        return !in_array($this->status, ['delivered', 'cancelled']);
    }

    /**
     * Check if order can be tracked.
     */
    public function isTrackable()
    {
        return !in_array($this->status, ['cancelled']);
    }

    /**
     * Get next expected status.
     */
    public function getNextStatusAttribute()
    {
        $statusFlow = [
            'pending' => 'confirmed',
            'confirmed' => 'preparing', 
            'preparing' => 'out_for_delivery',
            'out_for_delivery' => 'delivered'
        ];

        return $statusFlow[$this->status] ?? null;
    }

    /**
     * Scope for specific status.
     */
    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope for active orders.
     */
    public function scopeActive($query)
    {
        return $query->whereNotIn('status', ['delivered', 'cancelled']);
    }

    /**
     * Scope for trackable orders.
     */
    public function scopeTrackable($query)
    {
        return $query->whereNotIn('status', ['cancelled']);
    }

    /**
     * Scope for completed orders.
     */
    public function scopeCompleted($query)
    {
        return $query->where('status', 'delivered');
    }

    /**
     * Calculate estimated delivery time (default 45 minutes from now).
     */
    public function calculateEstimatedDeliveryTime()
    {
        return Carbon::now()->addMinutes(45);
    }

    /**
     * Update order status and handle side effects.
     */
    public function updateStatus($newStatus)
    {
        $this->status = $newStatus;
        
        // Set delivered timestamp when status changes to delivered
        if ($newStatus === 'delivered') {
            $this->delivered_at = Carbon::now();
            $this->payment_status = 'paid'; // Assume payment is completed on delivery
        }
        
        $this->save();
        
        return $this;
    }
}