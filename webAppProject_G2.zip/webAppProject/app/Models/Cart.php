<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
    ];

    /**
     * Get the user that owns the cart.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the cart items for the cart.
     */
    public function cartItems()
    {
        return $this->hasMany(CartItem::class);
    }

    /**
     * Get the cart items with food item details.
     */
    public function cartItemsWithFood()
    {
        return $this->cartItems()->with('foodItem');
    }

    /**
     * Calculate total amount of cart.
     */
    public function getTotalAmountAttribute()
    {
        return $this->cartItems->sum(function ($cartItem) {
            return $cartItem->quantity * $cartItem->foodItem->price;
        });
    }

    /**
     * Get total items count in cart.
     */
    public function getTotalItemsAttribute()
    {
        return $this->cartItems->sum('quantity');
    }

    /**
     * Check if cart is empty.
     */
    public function isEmpty()
    {
        return $this->cartItems->count() === 0;
    }

    /**
     * Clear all items from cart.
     */
    public function clearCart()
    {
        $this->cartItems()->delete();
    }
}