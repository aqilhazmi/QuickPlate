<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = '/dashboard';

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('auth')->only('logout');
    }

    /**
     * Handle post-authentication redirection.
     */
    protected function authenticated(Request $request, $user)
    {
        // Clear any cached routes
        \Artisan::call('route:clear');
        
        if ($user->isAdmin) {
            return redirect('/admin/dashboard');
        }

        return redirect('/dashboard');
    }

    /**
     * Get the post-authentication redirect path.
     */
    public function redirectPath()
    {
        if (auth()->user()->isAdmin) {
            return '/admin/dashboard';
        }
        
        return '/dashboard';
    }
}