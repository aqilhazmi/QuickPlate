<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoodItem;
use App\Models\Order;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = auth()->user();
        
        // Get user statistics
        $totalOrders = $user->orders()->count();
        $completedOrders = $user->orders()->where('status', 'delivered')->count();
        $totalSpent = $user->orders()->where('status', 'delivered')->sum('total_amount');
        
        // Get cart info
        $cart = $user->cart;
        $cartItemsCount = $cart ? $cart->cartItems->sum('quantity') : 0;
        
        // Get recent orders (limit to 5)
        $recentOrders = $user->orders()->latest()->take(5)->get();
        
        // Get featured food items
        $featuredItems = FoodItem::where('is_available', true)->latest()->take(6)->get();
        
        return view('dashboard', compact(
            'totalOrders',
            'completedOrders', 
            'totalSpent',
            'cartItemsCount',
            'recentOrders',
            'featuredItems'
        ));
    }
}