<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FoodItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class FoodItemController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function index()
    {
        $foodItems = FoodItem::latest()->paginate(15);
        return view('admin.food-items.index', compact('foodItems'));
    }

    public function create()
    {
        $categories = $this->getCategories();
        return view('admin.food-items.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:1000',
            'price' => 'required|numeric|min:0.01|max:999.99',
            'category' => 'required|string|max:50',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_available' => 'boolean'
        ]);

        $data = $request->only(['name', 'description', 'price', 'category', 'is_available']);
        
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->storeAs('public/food_images', $imageName);
            $data['image'] = $imageName;
        }

        FoodItem::create($data);

        return redirect()->route('admin.food-items.index')
                        ->with('success', 'Food item created successfully!');
    }

    public function edit(FoodItem $foodItem)
    {
        $categories = $this->getCategories();
        return view('admin.food-items.edit', compact('foodItem', 'categories'));
    }

    public function update(Request $request, FoodItem $foodItem)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:1000',
            'price' => 'required|numeric|min:0.01|max:999.99',
            'category' => 'required|string|max:50',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_available' => 'boolean'
        ]);

        $data = $request->only(['name', 'description', 'price', 'category', 'is_available']);
        
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($foodItem->image) {
                Storage::delete('public/food_images/' . $foodItem->image);
            }
            
            $image = $request->file('image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->storeAs('public/food_images', $imageName);
            $data['image'] = $imageName;
        }

        $foodItem->update($data);

        return redirect()->route('admin.food-items.index')
                        ->with('success', 'Food item updated successfully!');
    }

    public function destroy(FoodItem $foodItem)
    {
        // Check if food item is in any active orders
        $hasActiveOrders = $foodItem->orderItems()
            ->whereHas('order', function ($query) {
                $query->whereNotIn('status', ['delivered', 'cancelled']);
            })->exists();

        if ($hasActiveOrders) {
            return redirect()->route('admin.food-items.index')
                           ->with('error', 'Cannot delete food item with active orders!');
        }

        // Delete image if exists
        if ($foodItem->image) {
            Storage::delete('public/food_images/' . $foodItem->image);
        }

        $foodItem->delete();

        return redirect()->route('admin.food-items.index')
                        ->with('success', 'Food item deleted successfully!');
    }

    private function getCategories()
    {
        return [
            'appetizer' => 'Appetizer',
            'main' => 'Main Course',
            'dessert' => 'Dessert',
            'beverage' => 'Beverage',
            'specialty' => 'Specialty'
        ];
    }
}