<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show user's order tracking page.
     */
    public function tracking()
    {
        $user = auth()->user();
        
        // Get user's orders with order items and food items, ordered by latest first
        $orders = Order::where('user_id', $user->id)
                      ->with(['orderItems.foodItem'])
                      ->orderBy('created_at', 'desc')
                      ->get();
        
        return view('tracking', compact('orders'));
    }

    /**
     * Show all orders for the user.
     */
    public function index()
    {
        $user = auth()->user();
        
        $orders = Order::where('user_id', $user->id)
                      ->with(['orderItems.foodItem'])
                      ->orderBy('created_at', 'desc')
                      ->paginate(10);
        
        return view('orders.index', compact('orders'));
    }

    /**
     * Show specific order details.
     */
    public function show($id)
    {
        $user = auth()->user();
        
        $order = Order::where('user_id', $user->id)
                     ->where('id', $id)
                     ->with(['orderItems.foodItem'])
                     ->firstOrFail();
        
        return view('orders.show', compact('order'));
    }
}