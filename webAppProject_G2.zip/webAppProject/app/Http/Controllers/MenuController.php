<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoodItem;

class MenuController extends Controller
{
    /**
     * Display the menu page with all food items.
     */
    public function index(Request $request)
    {
        $query = FoodItem::where('is_available', true);
        
        // Search functionality
        if ($request->filled('search')) {
            $searchTerm = $request->search;
            $query->where(function($q) use ($searchTerm) {
                $q->where('name', 'LIKE', "%{$searchTerm}%")
                  ->orWhere('description', 'LIKE', "%{$searchTerm}%");
            });
        }
        
        // Category filter
        if ($request->filled('category') && $request->category !== 'all') {
            $query->where('category', $request->category);
        }
        
        // Price range filter
        if ($request->filled('min_price')) {
            $query->where('price', '>=', $request->min_price);
        }
        
        if ($request->filled('max_price')) {
            $query->where('price', '<=', $request->max_price);
        }
        
        // Sorting
        $sortBy = $request->get('sort', 'name');
        $sortOrder = $request->get('order', 'asc');
        
        switch ($sortBy) {
            case 'price':
                $query->orderBy('price', $sortOrder);
                break;
            case 'name':
                $query->orderBy('name', $sortOrder);
                break;
            case 'latest':
                $query->latest();
                break;
            default:
                $query->orderBy('name', 'asc');
        }
        
        // Get paginated results
        $foodItems = $query->paginate(12)->appends($request->query());
        
        // Get categories - simplified query
        $categories = FoodItem::where('is_available', true)
                              ->select('category')
                              ->distinct()
                              ->pluck('category');
        
        // Get price range - simplified
        $priceStats = FoodItem::where('is_available', true)
                              ->selectRaw('MIN(price) as min_price, MAX(price) as max_price')
                              ->first();
        
        $priceRange = [
            'min' => $priceStats->min_price ?? 0,
            'max' => $priceStats->max_price ?? 100
        ];
        
        // Get category counts - single query
        $categoryData = FoodItem::where('is_available', true)
                                ->selectRaw('category, COUNT(*) as count')
                                ->groupBy('category')
                                ->pluck('count', 'category');
        
        $categoryCounts = [
            'all' => $foodItems->total(),
            'food' => $categoryData['food'] ?? 0,
            'drinks' => $categoryData['drinks'] ?? 0,
            'dessert' => $categoryData['dessert'] ?? 0,
            'specialty' => $categoryData['specialty'] ?? 0,
        ];
        
        return view('menu.index', compact(
            'foodItems',
            'categories',
            'priceRange',
            'categoryCounts'
        ));
    }
    
    /**
     * Show a specific food item (for AJAX requests or modal).
     */
    public function show(FoodItem $foodItem)
    {
        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'food_item' => [
                    'id' => $foodItem->id,
                    'name' => $foodItem->name,
                    'description' => $foodItem->description,
                    'price' => $foodItem->price,
                    'formatted_price' => $foodItem->formatted_price,
                    'category' => $foodItem->category,
                    'image_url' => $foodItem->image_url,
                    'is_available' => $foodItem->is_available,
                ]
            ]);
        }
        
        return view('menu.show', compact('foodItem'));
    }
    
    /**
     * Get food items by category (AJAX endpoint).
     */
    public function getByCategory(Request $request, $category)
    {
        $query = FoodItem::where('is_available', true);
        
        if ($category !== 'all') {
            $query->where('category', $category);
        }
        
        $foodItems = $query->orderBy('name')->get();
        
        return response()->json([
            'success' => true,
            'food_items' => $foodItems->map(function($item) {
                return [
                    'id' => $item->id,
                    'name' => $item->name,
                    'description' => $item->description,
                    'formatted_price' => $item->formatted_price,
                    'image_url' => $item->image_url,
                    'category' => $item->category,
                ];
            })
        ]);
    }
}