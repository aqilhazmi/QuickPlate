<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Cart;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    public function __construct()
    {
        // Only apply auth middleware to specific methods
        $this->middleware('auth')->except(['showTrackForm', 'trackPublic']);
    }

    /**
     * Show the checkout page.
     */
    public function index()
    {
        $user = auth()->user();
        $cart = $user->cart;
        
        // Check if cart exists and has items
        if (!$cart || $cart->cartItems->isEmpty()) {
            return redirect()->route('menu')->with('error', 'Your cart is empty. Please add items before checkout.');
        }
        
        $cartItems = $cart->cartItemsWithFood;
        $subtotal = $cart->total_amount;
        $deliveryFee = 5.00; // Fixed delivery fee
        $serviceTax = $subtotal * 0.06; // 6% service tax
        $total = $subtotal + $deliveryFee + $serviceTax;
        
        return view('checkout.index', compact(
            'cartItems',
            'subtotal',
            'deliveryFee', 
            'serviceTax',
            'total'
        ));
    }

    /**
     * Process the checkout and create order.
     */
    public function store(Request $request)
    {
        $user = auth()->user();
        $cart = $user->cart;
        
        // Validate cart exists and has items
        if (!$cart || $cart->cartItems->isEmpty()) {
            return redirect()->route('menu')->with('error', 'Your cart is empty.');
        }
        
        // Validate form data
        $validated = $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_email' => 'required|email|max:255',
            'customer_phone' => 'required|string|max:20',
            'delivery_address' => 'required|string|max:500',
            'postal_code' => 'nullable|string|max:10',
            'city' => 'required|string|max:100',
            'state' => 'required|string|max:100',
            'payment_method' => 'required|in:cash_on_delivery,bank_transfer,online_payment',
            'special_instructions' => 'nullable|string|max:500',
        ]);

        DB::beginTransaction();
        
        try {
            // Calculate order totals
            $subtotal = $cart->total_amount;
            $deliveryFee = 5.00;
            $serviceTax = $subtotal * 0.06;
            $total = $subtotal + $deliveryFee + $serviceTax;
            
            // Create the order
            $order = Order::create([
                'user_id' => $user->id,
                'customer_name' => $validated['customer_name'],
                'customer_email' => $validated['customer_email'],
                'customer_phone' => $validated['customer_phone'],
                'delivery_address' => $validated['delivery_address'],
                'postal_code' => $validated['postal_code'],
                'city' => $validated['city'],
                'state' => $validated['state'],
                'payment_method' => $validated['payment_method'],
                'special_instructions' => $validated['special_instructions'],
                'subtotal' => $subtotal,
                'delivery_fee' => $deliveryFee,
                'service_tax' => $serviceTax,
                'total_amount' => $total,
                'estimated_delivery_time' => now()->addMinutes(45),
                'status' => 'pending',
                'payment_status' => 'pending',
            ]);

            // Create order items from cart items
            foreach ($cart->cartItems as $cartItem) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'food_id' => $cartItem->food_id,
                    'food_name' => $cartItem->foodItem->name,
                    'food_description' => $cartItem->foodItem->description,
                    'food_category' => $cartItem->foodItem->category,
                    'unit_price' => $cartItem->foodItem->price,
                    'quantity' => $cartItem->quantity,
                    'subtotal' => $cartItem->subtotal,
                ]);
            }

            // Clear the cart after successful order
            $cart->clearCart();

            DB::commit();

            // Redirect to order confirmation
            return redirect()->route('checkout.confirmation', $order->id)
                           ->with('success', 'Your order has been placed successfully!');

        } catch (\Exception $e) {
            DB::rollback();
            
            return redirect()->back()
                           ->withInput()
                           ->with('error', 'Failed to process your order. Please try again.');
        }
    }

    /**
     * Show order confirmation page.
     */
    public function confirmation(Order $order)
    {
        // Ensure user owns this order
        if ($order->user_id !== auth()->id()) {
            abort(403, 'Access denied.');
        }

        $order->load('orderItems.foodItem');
        
        return view('checkout.confirmation', compact('order'));
    }

    /**
     * Show order tracking page (for logged-in users).
     */
    public function track($orderNumber)
    {
        // Extract order ID from order number (remove 'QP' prefix and leading zeros)
        $orderId = (int) ltrim(str_replace('QP', '', $orderNumber), '0');
        
        $order = Order::where('id', $orderId)
                     ->where('user_id', auth()->id())
                     ->firstOrFail();
                     
        $order->load('orderItems.foodItem');
        
        return view('checkout.track', compact('order'));
    }

    /**
     * Show public track order form.
     */
    public function showTrackForm()
    {
        return view('orders.track-form');
    }

    /**
     * Track order publicly (no login required).
     */
    public function trackPublic(Request $request)
    {
        $request->validate([
            'order_number' => 'required|string',
            'phone' => 'required|string',
        ]);

        // Extract order ID from order number
        $orderNumber = strtoupper(trim($request->order_number));
        $orderId = (int) ltrim(str_replace('QP', '', $orderNumber), '0');
        
        // Find order by ID and phone number for security
        $order = Order::where('id', $orderId)
                     ->where('customer_phone', $request->phone)
                     ->first();

        if (!$order) {
            return redirect()->back()
                           ->withInput()
                           ->with('error', 'Order not found. Please check your order number and phone number.');
        }

        $order->load('orderItems.foodItem');
        
        return view('orders.track-result', compact('order'));
    }
}