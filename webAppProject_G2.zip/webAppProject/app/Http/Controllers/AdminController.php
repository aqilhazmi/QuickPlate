<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoodItem;
use App\Models\User;
use App\Models\Order;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Schema;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }

    /**
     * Show the admin dashboard.
     */
    public function dashboard()
    {
        // Get statistics for dashboard - with safety checks
        $totalFoodItems = FoodItem::count();
        
        // Check if orders table exists before querying
        $ordersTableExists = Schema::hasTable('orders');
        
        if ($ordersTableExists) {
            try {
                $totalOrders = Order::count();
                $totalRevenue = Order::where('payment_status', 'paid')->sum('total_amount') ?? 0;
                $recentOrders = Order::with('user', 'orderItems')->latest()->take(5)->get();
            } catch (\Exception $e) {
                // If there's any error with Order queries, set defaults
                $totalOrders = 0;
                $totalRevenue = 0;
                $recentOrders = collect();
            }
        } else {
            // If orders table doesn't exist, set defaults
            $totalOrders = 0;
            $totalRevenue = 0;
            $recentOrders = collect();
        }
        
        $totalUsers = User::where('isAdmin', false)->count();
        
        return view('admin.dashboard', compact(
            'totalFoodItems',
            'totalOrders', 
            'totalUsers',
            'totalRevenue',
            'recentOrders'
        ));
    }

    /**
     * Display a listing of food items.
     */
    public function index(Request $request)
    {
        $query = FoodItem::query();
        
        // Search functionality
        if ($request->filled('search')) {
            $searchTerm = $request->search;
            $query->where(function($q) use ($searchTerm) {
                $q->where('name', 'LIKE', "%{$searchTerm}%")
                  ->orWhere('description', 'LIKE', "%{$searchTerm}%");
            });
        }
        
        // Category filter
        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        
        // Get paginated results
        $foodItems = $query->latest()->paginate(10)->appends($request->query());
        
        return view('admin.food-items.index', compact('foodItems'));
    }

    /**
     * Show the form for creating a new food item.
     */
    public function create()
    {
        return view('admin.food-items.create');
    }

    /**
     * Store a newly created food item.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'category' => 'required|in:food,drinks,dessert,specialty',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_available' => 'boolean'
        ]);

        // Handle image upload
        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('food-items', 'public');
        }

        // Set availability
        $validated['is_available'] = $request->has('is_available');

        FoodItem::create($validated);

        return redirect()->route('admin.food-items.index')
                        ->with('success', 'Food item created successfully!');
    }

    /**
     * Display the specified food item.
     */
    public function show(FoodItem $foodItem)
    {
        return view('admin.food-items.show', compact('foodItem'));
    }

    /**
     * Show the form for editing the specified food item.
     */
    public function edit(FoodItem $foodItem)
    {
        return view('admin.food-items.edit', compact('foodItem'));
    }

    /**
     * Update the specified food item.
     */
    public function update(Request $request, FoodItem $foodItem)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'category' => 'required|in:food,drinks,dessert,specialty',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_available' => 'boolean'
        ]);

        // Handle image upload
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($foodItem->image) {
                Storage::disk('public')->delete($foodItem->image);
            }
            $validated['image'] = $request->file('image')->store('food-items', 'public');
        }

        // Set availability
        $validated['is_available'] = $request->has('is_available');

        $foodItem->update($validated);

        return redirect()->route('admin.food-items.index')
                        ->with('success', 'Food item updated successfully!');
    }

    /**
     * Remove the specified food item.
     */
    public function destroy(FoodItem $foodItem)
    {
        // Delete image if exists
        if ($foodItem->image) {
            Storage::disk('public')->delete($foodItem->image);
        }

        $foodItem->delete();

        return redirect()->route('admin.food-items.index')
                        ->with('success', 'Food item deleted successfully!');
    }

    /**
     * Display admin orders dashboard.
     */
    public function ordersDashboard()
    {
        // Check if orders table exists
        if (!Schema::hasTable('orders')) {
            return redirect()->route('admin.dashboard')
                           ->with('error', 'Orders feature is not yet set up. Please create the orders table first.');
        }

        try {
            $stats = [
                'total_orders' => Order::count(),
                'pending_orders' => Order::where('status', 'pending')->count(),
                'active_orders' => Order::active()->count(),
                'todays_orders' => Order::whereDate('created_at', today())->count(),
                'todays_revenue' => Order::whereDate('created_at', today())
                                                  ->where('payment_status', 'paid')
                                                  ->sum('total_amount') ?? 0,
                'total_revenue' => Order::where('payment_status', 'paid')->sum('total_amount') ?? 0,
            ];

            // Get recent orders
            $recentOrders = Order::with('user', 'orderItems')
                                            ->latest()
                                            ->take(10)
                                            ->get();

            // Get pending orders (need attention)
            $pendingOrders = Order::with('user', 'orderItems')
                                             ->where('status', 'pending')
                                             ->latest()
                                             ->get();

            return view('admin.orders.dashboard', compact('stats', 'recentOrders', 'pendingOrders'));
        } catch (\Exception $e) {
            return redirect()->route('admin.dashboard')
                           ->with('error', 'Error accessing orders data: ' . $e->getMessage());
        }
    }

    /**
     * Display all orders for admin.
     */
    public function ordersIndex(Request $request)
    {
        // Check if orders table exists
        if (!Schema::hasTable('orders')) {
            return redirect()->route('admin.dashboard')
                           ->with('error', 'Orders feature is not yet set up. Please create the orders table first.');
        }

        try {
            $query = Order::with('user', 'orderItems.foodItem');
            
            // Search by order number or customer name
            if ($request->filled('search')) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('id', 'LIKE', "%{$search}%")
                      ->orWhere('customer_name', 'LIKE', "%{$search}%")
                      ->orWhere('customer_phone', 'LIKE', "%{$search}%")
                      ->orWhere('customer_email', 'LIKE', "%{$search}%");
                });
            }
            
            // Filter by status
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            
            // Filter by payment status
            if ($request->filled('payment_status')) {
                $query->where('payment_status', $request->payment_status);
            }
            
            // Filter by date range
            if ($request->filled('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }
            
            if ($request->filled('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }
            
            // Sort by latest first
            $orders = $query->latest()->paginate(15)->appends($request->query());
            
            return view('admin.orders.index', compact('orders'));
        } catch (\Exception $e) {
            return redirect()->route('admin.dashboard')
                           ->with('error', 'Error accessing orders data: ' . $e->getMessage());
        }
    }

    /**
     * Show specific order details for admin.
     */
    public function ordersShow(Order $order)
    {
        try {
            $order->load('user', 'orderItems.foodItem');
            
            return view('admin.orders.show', compact('order'));
        } catch (\Exception $e) {
            return redirect()->route('admin.orders.index')
                           ->with('error', 'Error loading order details: ' . $e->getMessage());
        }
    }

    /**
     * Update order status.
     */
    public function updateOrderStatus(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|in:pending,confirmed,preparing,out_for_delivery,delivered,cancelled',
            'notes' => 'nullable|string|max:500'
        ]);

        try {
            $oldStatus = $order->status;
            $newStatus = $request->status;
            
            // Update the order status
            $order->updateStatus($newStatus);
            
            $message = "Order #{$order->order_number} status updated from " . 
                       ucfirst($oldStatus) . " to " . ucfirst($newStatus);
            
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => true,
                    'message' => $message,
                    'status' => $newStatus,
                    'status_label' => $order->status_label,
                    'badge_color' => $order->status_badge_color
                ]);
            }
            
            return redirect()->back()->with('success', $message);
        } catch (\Exception $e) {
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error updating order status: ' . $e->getMessage()
                ]);
            }
            
            return redirect()->back()->with('error', 'Error updating order status: ' . $e->getMessage());
        }
    }

    /**
     * Get order statistics for dashboard.
     */
    public function getOrderStats()
    {
        // Check if orders table exists
        if (!Schema::hasTable('orders')) {
            return response()->json([
                'error' => 'Orders table not found'
            ], 404);
        }

        try {
            $stats = [
                'today' => [
                    'orders' => Order::whereDate('created_at', today())->count(),
                    'revenue' => Order::whereDate('created_at', today())
                                                ->where('payment_status', 'paid')
                                                ->sum('total_amount') ?? 0,
                ],
                'week' => [
                    'orders' => Order::whereBetween('created_at', [
                        now()->startOfWeek(), 
                        now()->endOfWeek()
                    ])->count(),
                    'revenue' => Order::whereBetween('created_at', [
                        now()->startOfWeek(), 
                        now()->endOfWeek()
                    ])->where('payment_status', 'paid')->sum('total_amount') ?? 0,
                ],
                'month' => [
                    'orders' => Order::whereMonth('created_at', now()->month)
                                               ->whereYear('created_at', now()->year)
                                               ->count(),
                    'revenue' => Order::whereMonth('created_at', now()->month)
                                                ->whereYear('created_at', now()->year)
                                                ->where('payment_status', 'paid')
                                                ->sum('total_amount') ?? 0,
                ]
            ];
            
            return response()->json($stats);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Error fetching order statistics: ' . $e->getMessage()
            ], 500);
        }
    }
}