<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\FoodItem;

class CartController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display the cart page.
     */
    public function index()
    {
        $user = auth()->user();
        $cart = $user->cart;
        
        if (!$cart) {
            $cart = Cart::create(['user_id' => $user->id]);
        }
        
        $cartItems = $cart->cartItemsWithFood;
        $totalAmount = $cart->total_amount;
        
        return view('cart.index', compact('cartItems', 'totalAmount'));
    }

    /**
     * Add item to cart.
     */
    public function add(Request $request, FoodItem $foodItem)
    {
        if (!$foodItem->is_available) {
            return response()->json([
                'success' => false,
                'message' => 'This item is currently unavailable.'
            ], 400);
        }

        $request->validate([
            'quantity' => 'integer|min:1|max:10'
        ]);

        $user = auth()->user();
        $cart = $user->cart;
        
        if (!$cart) {
            $cart = Cart::create(['user_id' => $user->id]);
        }

        $quantity = $request->get('quantity', 1);
        
        // Check if item already exists in cart
        $cartItem = $cart->cartItems()->where('food_id', $foodItem->id)->first();
        
        if ($cartItem) {
            // Update quantity
            $cartItem->quantity += $quantity;
            $cartItem->save();
        } else {
            // Create new cart item
            CartItem::create([
                'cart_id' => $cart->id,
                'food_id' => $foodItem->id,
                'quantity' => $quantity
            ]);
        }

        // Get updated cart count
        $cartCount = $cart->cartItems->sum('quantity');

        return response()->json([
            'success' => true,
            'message' => 'Item added to cart successfully!',
            'cart_count' => $cartCount,
            'item_name' => $foodItem->name,
            'quantity' => $quantity
        ]);
    }

    /**
     * Update cart item quantity.
     */
    public function update(Request $request, CartItem $cartItem)
    {
        // Ensure user owns this cart item
        if ($cartItem->cart->user_id !== auth()->id()) {
            abort(403);
        }

        $request->validate([
            'quantity' => 'required|integer|min:1|max:10'
        ]);

        $cartItem->update([
            'quantity' => $request->quantity
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Cart updated successfully!',
            'subtotal' => $cartItem->formatted_subtotal,
            'total' => $cartItem->cart->total_amount
        ]);
    }

    /**
     * Remove item from cart.
     */
    public function remove(CartItem $cartItem)
    {
        // Ensure user owns this cart item
        if ($cartItem->cart->user_id !== auth()->id()) {
            abort(403);
        }

        $itemName = $cartItem->foodItem->name;
        $cartItem->delete();

        return response()->json([
            'success' => true,
            'message' => "{$itemName} removed from cart!",
            'cart_count' => $cartItem->cart->cartItems->sum('quantity')
        ]);
    }

    /**
     * Clear entire cart.
     */
    public function clear()
    {
        $user = auth()->user();
        $cart = $user->cart;
        
        if ($cart) {
            $cart->clearCart();
        }

        return response()->json([
            'success' => true,
            'message' => 'Cart cleared successfully!'
        ]);
    }

    /**
     * Get cart count for AJAX requests.
     */
    public function getCartCount()
    {
        $user = auth()->user();
        $cart = $user->cart;
        $count = $cart ? $cart->cartItems->sum('quantity') : 0;

        return response()->json([
            'cart_count' => $count
        ]);
    }
}