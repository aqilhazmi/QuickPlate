<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\FoodItem;
use App\Models\User;
use Carbon\Carbon;

class OrdersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Make sure we have some food items and users
        $foodItems = FoodItem::all();
        $users = User::where('isAdmin', false)->get();
        
        if ($foodItems->isEmpty()) {
            $this->command->info('No food items found. Creating some sample food items first...');
            
            // Create some sample food items
            $sampleFoodItems = [
                [
                    'name' => 'Nasi Lemak Special',
                    'description' => 'Traditional Malaysian coconut rice with sambal, anchovies, peanuts, boiled egg, and fried chicken',
                    'price' => 8.50,
                    'category' => 'food',
                    'is_available' => true,
                ],
                [
                    'name' => 'Ayam Penyet',
                    'description' => 'Indonesian fried chicken served with spicy sambal and steamed rice',
                    'price' => 9.90,
                    'category' => 'food',
                    'is_available' => true,
                ],
                [
                    'name' => 'Mee Goreng Mamak',
                    'description' => 'Spicy stir-fried yellow noodles with vegetables, tofu, and egg',
                    'price' => 7.00,
                    'category' => 'food',
                    'is_available' => true,
                ],
                [
                    'name' => 'Teh Tarik',
                    'description' => 'Traditional Malaysian pulled milk tea',
                    'price' => 2.50,
                    'category' => 'drinks',
                    'is_available' => true,
                ],
                [
                    'name' => 'Rendang Daging',
                    'description' => 'Slow-cooked beef in coconut milk and spices - our signature dish',
                    'price' => 12.90,
                    'category' => 'specialty',
                    'is_available' => true,
                ],
                [
                    'name' => 'Cendol',
                    'description' => 'Traditional dessert with pandan jelly, coconut milk, and palm sugar',
                    'price' => 4.50,
                    'category' => 'dessert',
                    'is_available' => true,
                ],
            ];
            
            foreach ($sampleFoodItems as $item) {
                FoodItem::create($item);
            }
            
            $foodItems = FoodItem::all();
        }
        
        if ($users->isEmpty()) {
            $this->command->info('No regular users found. Creating a sample customer...');
            
            $user = User::create([
                'name' => 'John Customer',
                'email' => 'customer@example.com',
                'email_verified_at' => now(),
                'password' => bcrypt('password'),
                'isAdmin' => false,
            ]);
            
            $users = collect([$user]);
        }
        
        $this->command->info('Creating sample orders...');
        
        // Sample customer data for orders
        $sampleCustomers = [
            [
                'name' => 'Ahmad Rahman',
                'email' => 'ahmad@example.com',
                'phone' => '+60123456789',
                'address' => 'No. 123, Jalan Bukit Bintang, 55100 Kuala Lumpur',
                'city' => 'Kuala Lumpur',
                'state' => 'Federal Territory',
                'postal_code' => '55100',
            ],
            [
                'name' => 'Siti Nurhaliza',
                'email' => 'siti@example.com',
                'phone' => '+60129876543',
                'address' => 'Lot 456, Taman Melawati, 53100 Kuala Lumpur',
                'city' => 'Kuala Lumpur',
                'state' => 'Selangor',
                'postal_code' => '53100',
            ],
            [
                'name' => 'David Tan',
                'email' => 'david@example.com',
                'phone' => '+60134567890',
                'address' => '789 Jalan Ampang, 50450 Kuala Lumpur',
                'city' => 'Kuala Lumpur',
                'state' => 'Federal Territory',
                'postal_code' => '50450',
            ],
        ];
        
        $statuses = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered'];
        $paymentMethods = ['cash_on_delivery', 'online_banking', 'e_wallet'];
        $paymentStatuses = ['pending', 'paid'];
        
        // Create 15 sample orders
        for ($i = 1; $i <= 15; $i++) {
            $customer = $sampleCustomers[array_rand($sampleCustomers)];
            $user = $users->random();
            $status = $statuses[array_rand($statuses)];
            $paymentMethod = $paymentMethods[array_rand($paymentMethods)];
            $paymentStatus = $status === 'delivered' ? 'paid' : $paymentStatuses[array_rand($paymentStatuses)];
            
            // Create order with random date in the last 7 days
            $orderDate = Carbon::now()->subDays(rand(0, 7))->subHours(rand(0, 23));
            
            $order = Order::create([
                'user_id' => rand(0, 1) ? $user->id : null, // Some orders are guest orders
                'customer_name' => $customer['name'],
                'customer_email' => $customer['email'],
                'customer_phone' => $customer['phone'],
                'delivery_address' => $customer['address'],
                'city' => $customer['city'],
                'state' => $customer['state'],
                'postal_code' => $customer['postal_code'],
                'status' => $status,
                'payment_method' => $paymentMethod,
                'payment_status' => $paymentStatus,
                'subtotal' => 0, // Will be calculated after adding items
                'delivery_fee' => 5.00,
                'service_tax' => 0,
                'total_amount' => 0, // Will be calculated after adding items
                'special_instructions' => rand(0, 1) ? 'Please call when you arrive' : null,
                'estimated_delivery_time' => $orderDate->addMinutes(45),
                'delivered_at' => $status === 'delivered' ? $orderDate->addMinutes(45) : null,
                'created_at' => $orderDate,
                'updated_at' => $orderDate,
            ]);
            
            // Add random items to the order (1-4 items per order)
            $itemCount = rand(1, 4);
            $subtotal = 0;
            
            $selectedItems = $foodItems->random($itemCount);
            
            foreach ($selectedItems as $foodItem) {
                $quantity = rand(1, 3);
                $itemSubtotal = $foodItem->price * $quantity;
                $subtotal += $itemSubtotal;
                
                OrderItem::create([
                    'order_id' => $order->id,
                    'food_id' => $foodItem->id,
                    'food_name' => $foodItem->name,
                    'food_description' => $foodItem->description,
                    'food_category' => $foodItem->category,
                    'unit_price' => $foodItem->price,
                    'quantity' => $quantity,
                    'subtotal' => $itemSubtotal,
                    'special_notes' => rand(0, 3) == 0 ? 'Less spicy please' : null,
                ]);
            }
            
            // Calculate service tax (6% in Malaysia)
            $serviceTax = $subtotal * 0.06;
            $totalAmount = $subtotal + $order->delivery_fee + $serviceTax;
            
            // Update order totals
            $order->update([
                'subtotal' => $subtotal,
                'service_tax' => $serviceTax,
                'total_amount' => $totalAmount,
            ]);
            
            $this->command->info("Created order #{$order->order_number} for {$customer['name']} - Status: {$status}");
        }
        
        $this->command->info('Sample orders created successfully!');
        $this->command->info('You can now test the admin order management system.');
    }
}