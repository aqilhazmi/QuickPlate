<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        // Create admin user
        User::create([
            'name' => 'Admin User',
            'email' => 'admin@quickplate.com',
            'password' => bcrypt('admin123'),
            'isAdmin' => true,
            'email_verified_at' => now(),
        ]);

        // Create your personal admin account
        User::create([
            'name' => 'Haikal',
            'email' => 'haiil@gmail.com',
            'password' => bcrypt('admin123'),
            'isAdmin' => true,
            'email_verified_at' => now(),
        ]);
    }
}