<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->onDelete('cascade');
            $table->foreignId('food_id')->constrained('food_items')->onDelete('cascade');
            
            // Item Details (snapshot at time of order)
            $table->string('food_name'); // Store name in case food item is deleted later
            $table->text('food_description')->nullable();
            $table->string('food_category');
            $table->decimal('unit_price', 10, 2); // Price at time of order
            $table->integer('quantity');
            $table->decimal('subtotal', 10, 2); // unit_price * quantity
            
            // Additional Information
            $table->text('special_notes')->nullable(); // Customer notes for this item
            
            $table->timestamps();
            
            // Indexes
            $table->index(['order_id', 'food_id']);
            $table->index('order_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('order_items');
    }
};