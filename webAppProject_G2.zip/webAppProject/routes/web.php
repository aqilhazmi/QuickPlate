<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\OrderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Public routes
Route::get('/', function () {
    return view('mainpage');
})->name('home');

// Public menu route (accessible to all users)
Route::get('/menu', [MenuController::class, 'index'])->name('menu');

// Authentication Routes
Auth::routes();

// Redirect /home to dashboard for authenticated users
Route::get('/home', function () {
    if (auth()->check()) {
        if (auth()->user()->isAdmin) {
            return redirect()->route('admin.dashboard');
        }
        return redirect()->route('dashboard');
    }
    return redirect()->route('login');
});

// Regular authenticated user routes
Route::middleware(['auth'])->group(function () {
    // Regular user dashboard
    Route::get('/dashboard', function () {
    return redirect()->route('home');
    })->name('dashboard');
    
    // Cart routes
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::prefix('cart')->name('cart.')->group(function () {
    Route::get('/', [CartController::class, 'index'])->name('index');
    Route::patch('/update/{cartItem}', [CartController::class, 'update'])->name('update');
    Route::delete('/remove/{cartItem}', [CartController::class, 'remove'])->name('remove');
    Route::delete('/clear', [CartController::class, 'clear'])->name('clear');
    });
    
    // Order routes - UPDATED WITH TRACKING
    Route::prefix('orders')->name('orders.')->group(function () {
        Route::get('/', [OrderController::class, 'index'])->name('index');
        Route::get('/tracking', [OrderController::class, 'tracking'])->name('tracking'); // NEW: Order tracking
        Route::get('/{order}', [OrderController::class, 'show'])->name('show');
    });

    // Legacy order routes (for compatibility)
    Route::get('/orders/{id}', [OrderController::class, 'show']);
    
    // Checkout routes
     Route::prefix('checkout')->name('checkout.')->group(function () {
        Route::get('/', [CheckoutController::class, 'index'])->name('index');
        Route::post('/', [CheckoutController::class, 'store'])->name('store');
        Route::get('/confirmation/{order}', [CheckoutController::class, 'confirmation'])->name('confirmation');
        Route::get('/track/{orderNumber}', [CheckoutController::class, 'track'])->name('track');
    });
});
// Admin routes - Using AdminController with admin middleware
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    // Admin dashboard
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
    
    // Food items management - Individual routes (instead of resource)
    Route::get('/food-items', [AdminController::class, 'index'])->name('food-items.index');
    Route::get('/food-items/create', [AdminController::class, 'create'])->name('food-items.create');
    Route::post('/food-items', [AdminController::class, 'store'])->name('food-items.store');
    Route::get('/food-items/{foodItem}', [AdminController::class, 'show'])->name('food-items.show');
    Route::get('/food-items/{foodItem}/edit', [AdminController::class, 'edit'])->name('food-items.edit');
    Route::put('/food-items/{foodItem}', [AdminController::class, 'update'])->name('food-items.update');
    Route::delete('/food-items/{foodItem}', [AdminController::class, 'destroy'])->name('food-items.destroy');
    
    // Order management routes 
    Route::prefix('orders')->name('orders.')->group(function () {
        Route::get('/', [AdminController::class, 'ordersIndex'])->name('index');
        Route::get('/dashboard', [AdminController::class, 'ordersDashboard'])->name('dashboard');
        Route::get('/{order}', [AdminController::class, 'ordersShow'])->name('show');
        Route::patch('/{order}/status', [AdminController::class, 'updateOrderStatus'])->name('update-status');
        Route::get('/stats/data', [AdminController::class, 'getOrderStats'])->name('stats');
    });
    
    // User management (placeholder routes)
    Route::prefix('users')->name('users.')->group(function () {
        Route::get('/', function () {
            return "Admin Users Management - Coming Soon!";
        })->name('index');
    });
});

// API routes for AJAX calls
Route::prefix('api')->name('api.')->group(function () {
    // Get menu item details
    Route::get('/menu/{foodItem}', [MenuController::class, 'show'])->name('menu.show');
    
    // Get items by category
    Route::get('/menu/category/{category}', [MenuController::class, 'getByCategory'])->name('menu.category');
    
    // Cart API routes
    Route::middleware(['auth'])->group(function () {
        Route::get('/my-orders/tracking', [OrderController::class, 'tracking'])->name('orders.tracking');
        Route::post('/cart/add/{foodItem}', [CartController::class, 'add'])->name('cart.add');
        Route::get('/cart/count', [CartController::class, 'getCartCount'])->name('cart.count');
        
    });
});

// Fallback route for 404 errors
Route::fallback(function () {
    return response()->view('errors.404', [], 404);
});