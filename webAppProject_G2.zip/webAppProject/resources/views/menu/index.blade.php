@extends('master.layout')

@section('title', 'Our Menu')

@section('content')
<main class="main">
    <!-- Hero Section -->
    <section id="menu-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Our Delicious Menu</h1>
                    <p>Discover our carefully crafted halal dishes made with the finest ingredients</p>
                    @auth
                        <div class="btns mt-4">
                            <a href="{{ route('cart.index') }}" class="btn-get-started">
                                <i class="bi bi-cart"></i> View Cart
                                @php
                                    $cart = auth()->user()->cart;
                                    $cartCount = $cart ? $cart->cartItems->sum('quantity') : 0;
                                @endphp
                                @if($cartCount > 0)
                                    <span class="badge bg-warning text-dark ms-1">{{ $cartCount }}</span>
                                @endif
                            </a>
                        </div>
                    @else
                        <div class="btns mt-4">
                            <a href="{{ route('register') }}" class="btn-get-started">
                                <i class="bi bi-person-plus"></i> Register to Order
                            </a>
                        </div>
                    @endauth
                </div>
            </div>
        </div>
    </section>

    <!-- Menu Section -->
    <section id="menu" class="menu section">
        <div class="container">
            
            <!-- Search and Filter Bar -->
            <div class="row mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="col-lg-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search for food..." id="menuSearch">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-filter"></i></span>
                        <select class="form-select" id="priceFilter">
                            <option value="">All Prices</option>
                            <option value="0-10">Under RM 10</option>
                            <option value="10-20">RM 10 - RM 20</option>
                            <option value="20-50">RM 20 - RM 50</option>
                            <option value="50+">Above RM 50</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Menu Filters -->
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-lg-12 d-flex justify-content-center">
                    <ul class="menu-filters isotope-filters">
                        <li data-filter="*" class="filter-active">All ({{ $categoryCounts['all'] ?? 0 }})</li>
                        <li data-filter=".filter-food">Food ({{ $categoryCounts['food'] ?? 0 }})</li>
                        <li data-filter=".filter-drinks">Drinks ({{ $categoryCounts['drinks'] ?? 0 }})</li>
                        <li data-filter=".filter-dessert">Desserts ({{ $categoryCounts['dessert'] ?? 0 }})</li>
                        <li data-filter=".filter-specialty">Specialty ({{ $categoryCounts['specialty'] ?? 0 }})</li>
                    </ul>
                </div>
            </div>

            <!-- Menu Items -->
            @if($foodItems->count() > 0)
                <div class="row" data-aos="fade-up" data-aos-delay="200" id="menuContainer">
                    @foreach($foodItems as $item)
                    <div class="col-lg-6 col-md-6 mb-4 menu-item filter-{{ $item->category }} food-card" 
                         data-name="{{ strtolower($item->name) }}" 
                         data-price="{{ $item->price }}"
                         data-description="{{ strtolower($item->description) }}">
                        
                        <div class="menu-item-card h-100">
                            @if($item->image)
                                <img src="{{ $item->image_url }}" class="menu-img" alt="{{ $item->name }}">
                            @else
                                <div class="menu-img bg-light d-flex align-items-center justify-content-center">
                                    <i class="bi bi-image text-muted" style="font-size: 3rem;"></i>
                                </div>
                            @endif
                            
                            <div class="menu-content">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h5 class="item-name">{{ $item->name }}</h5>
                                    <span class="price">{{ $item->formatted_price }}</span>
                                </div>
                                
                                @if(!$item->is_available)
                                    <span class="badge bg-danger mb-2">Out of Stock</span>
                                @endif
                                
                                <div class="menu-ingredients">
                                    <p class="text-muted">{{ Str::limit($item->description, 100) }}</p>
                                    
                                    @auth
                                        @if($item->is_available)
                                            <div class="mt-3">
                                                <div class="d-flex align-items-center gap-2">
                                                    <div class="quantity-controls">
                                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="decreaseQuantity({{ $item->id }})">-</button>
                                                        <span class="quantity-display mx-2" id="quantity-{{ $item->id }}">1</span>
                                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="increaseQuantity({{ $item->id }})">+</button>
                                                    </div>
                                                    <button type="button" class="btn btn-primary btn-sm flex-grow-1" onclick="addToCart({{ $item->id }}, '{{ $item->name }}')">
                                                        <i class="bi bi-cart-plus"></i> Add to Cart
                                                    </button>
                                                </div>
                                            </div>
                                        @else
                                            <div class="mt-3">
                                                <button class="btn btn-secondary btn-sm w-100" disabled>
                                                    <i class="bi bi-x-circle"></i> Currently Unavailable
                                                </button>
                                            </div>
                                        @endif
                                    @else
                                        <div class="mt-3">
                                            <a href="{{ route('login') }}" class="btn btn-outline-primary btn-sm w-100">
                                                <i class="bi bi-box-arrow-in-right"></i> Login to Order
                                            </a>
                                        </div>
                                    @endauth
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>

                <!-- Pagination -->
                @if($foodItems->hasPages())
                <div class="text-center mt-4">
                    {{ $foodItems->links() }}
                </div>
                @endif

            @else
                <div class="text-center py-5" data-aos="fade-up" data-aos-delay="200">
                    <i class="bi bi-grid-3x3-gap text-muted" style="font-size: 5rem;"></i>
                    <h3 class="mt-3">No Menu Items Found</h3>
                    <p class="text-muted">
                        @if(request()->hasAny(['search', 'category']))
                            No items match your search criteria. Try adjusting your filters.
                        @else
                            Our menu is being prepared. Please check back later!
                        @endif
                    </p>
                    @if(auth()->check() && auth()->user()->isAdmin)
                        <div class="mt-3">
                            <a href="{{ route('admin.food-items.create') }}" class="btn btn-primary">
                                <i class="bi bi-plus-circle"></i> Add Menu Items
                            </a>
                        </div>
                    @endif
                </div>
            @endif
        </div>
    </section>
</main>

@auth
<!-- Success Toast -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="cartToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <i class="bi bi-cart-check text-success me-2"></i>
            <strong class="me-auto">Added to Cart</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body" id="toastBody">
            Item added to your cart successfully!
        </div>
    </div>
</div>
@endauth

<style>
.menu-item-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    transition: transform 0.3s ease;
    margin-bottom: 20px;
}

.menu-item-card:hover {
    transform: translateY(-5px);
}

.menu-img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.quantity-controls {
    display: flex;
    align-items: center;
}

.quantity-display {
    min-width: 30px;
    text-align: center;
    font-weight: bold;
}

.price {
    color: #ce1212;
    font-weight: bold;
    font-size: 1.1em;
}

.item-name {
    color: #333;
    margin-bottom: 5px;
}

.menu-filters {
    display: flex;
    justify-content: center;
    list-style: none;
    padding: 0;
    margin: 20px 0;
}

.menu-filters li {
    margin: 0 10px;
    padding: 10px 20px;
    background: #f8f9fa;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.menu-filters li.filter-active,
.menu-filters li:hover {
    background: #ce1212;
    color: white;
}
</style>

@auth
@push('scripts')
<script>
    let quantities = {};

    function increaseQuantity(itemId) {
        if (!quantities[itemId]) quantities[itemId] = 1;
        quantities[itemId]++;
        document.getElementById(`quantity-${itemId}`).textContent = quantities[itemId];
    }

    function decreaseQuantity(itemId) {
        if (!quantities[itemId]) quantities[itemId] = 1;
        if (quantities[itemId] > 1) {
            quantities[itemId]--;
            document.getElementById(`quantity-${itemId}`).textContent = quantities[itemId];
        }
    }

    function addToCart(itemId, itemName) {
        const quantity = quantities[itemId] || 1;
        const button = event.target.closest('button');
        const originalText = button.innerHTML;
        
        // Show loading state
        button.innerHTML = '<i class="bi bi-hourglass-split"></i> Adding...';
        button.disabled = true;
        
        fetch(`/api/cart/add/${itemId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ quantity: quantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success toast
                document.getElementById('toastBody').textContent = `${quantity} × ${itemName} added to cart!`;
                new bootstrap.Toast(document.getElementById('cartToast')).show();
                
                // Reset quantity
                quantities[itemId] = 1;
                document.getElementById(`quantity-${itemId}`).textContent = 1;
                
                // Show success state
                button.innerHTML = '<i class="bi bi-check-circle"></i> Added!';
                button.classList.remove('btn-primary');
                button.classList.add('btn-success');
                
                // Reset button after 2 seconds
                setTimeout(() => {
                    button.innerHTML = originalText;
                    button.classList.remove('btn-success');
                    button.classList.add('btn-primary');
                    button.disabled = false;
                }, 2000);
            } else {
                // Show error
                alert(data.message || 'Error adding item to cart');
                button.innerHTML = originalText;
                button.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Network error. Please try again.');
            button.innerHTML = originalText;
            button.disabled = false;
        });
    }

    // Search and filter functionality
    document.getElementById('menuSearch').addEventListener('input', filterMenu);
    document.getElementById('priceFilter').addEventListener('change', filterMenu);

    function filterMenu() {
        const searchTerm = document.getElementById('menuSearch').value.toLowerCase();
        const priceRange = document.getElementById('priceFilter').value;
        const cards = document.querySelectorAll('.food-card');

        cards.forEach(card => {
            const name = card.getAttribute('data-name');
            const description = card.getAttribute('data-description');
            const price = parseFloat(card.getAttribute('data-price'));
            
            let matchesSearch = name.includes(searchTerm) || description.includes(searchTerm);
            let matchesPrice = true;
            
            if (priceRange) {
                if (priceRange === '0-10') matchesPrice = price < 10;
                else if (priceRange === '10-20') matchesPrice = price >= 10 && price < 20;
                else if (priceRange === '20-50') matchesPrice = price >= 20 && price < 50;
                else if (priceRange === '50+') matchesPrice = price >= 50;
            }
            
            card.style.display = (matchesSearch && matchesPrice) ? 'block' : 'none';
        });
    }

    // Category filter functionality
    document.querySelectorAll('.menu-filters li').forEach(filter => {
        filter.addEventListener('click', function() {
            // Remove active class from all filters
            document.querySelectorAll('.menu-filters li').forEach(f => f.classList.remove('filter-active'));
            
            // Add active class to clicked filter
            this.classList.add('filter-active');
            
            // Get filter value
            const filterValue = this.getAttribute('data-filter');
            const cards = document.querySelectorAll('.food-card');
            
            cards.forEach(card => {
                if (filterValue === '*') {
                    card.style.display = 'block';
                } else {
                    const categoryClass = filterValue.replace('.', '');
                    if (card.classList.contains(categoryClass)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
        });
    });
</script>
@endpush
@endauth
@endsection