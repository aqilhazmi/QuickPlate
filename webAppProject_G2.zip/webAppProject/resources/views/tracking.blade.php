@extends('master.layout')

@section('title', 'Order Tracking - QuickPlate')

@section('content')
<div class="container py-5" style="margin-top: 120px; margin-bottom: 80px;">
    <div class="row">
        <div class="col-12">
            <h2><i class="fas fa-map-marker-alt me-2"></i>Track Your Orders</h2>
            <hr>
        </div>
    </div>

    @if($orders->count() > 0)
        @foreach($orders as $order)
            <div class="card mb-4 shadow">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">Order {{ $order->order_number }}</h5>
                        <small class="text-muted">Placed on {{ $order->created_at->format('M d, Y \a\t g:i A') }}</small>
                    </div>
                    <span class="badge bg-{{ $order->status_color }} fs-6">
                        {{ $order->status_text }}
                    </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- Order Progress -->
                            <div class="order-progress mb-3">
                                <div class="progress-step {{ in_array($order->status, ['confirmed', 'preparing', 'out_for_delivery', 'delivered']) ? 'completed' : '' }}">
                                    <div class="step-icon">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Order Received</h6>
                                        <small>Your order has been placed</small>
                                        <br><small class="text-muted">{{ $order->created_at->format('g:i A') }}</small>
                                    </div>
                                </div>
                                
                                <div class="progress-step {{ in_array($order->status, ['preparing', 'out_for_delivery', 'delivered']) ? 'completed' : ($order->status === 'confirmed' ? 'active' : '') }}">
                                    <div class="step-icon">
                                        <i class="fas fa-utensils"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Preparing Order</h6>
                                        <small>Your food is being prepared</small>
                                        @if(in_array($order->status, ['preparing', 'out_for_delivery', 'delivered']))
                                            <br><small class="text-muted">{{ $order->updated_at->format('g:i A') }}</small>
                                        @endif
                                    </div>
                                </div>
                                
                                <div class="progress-step {{ in_array($order->status, ['out_for_delivery', 'delivered']) ? 'completed' : ($order->status === 'preparing' ? 'active' : '') }}">
                                    <div class="step-icon">
                                        <i class="fas fa-motorcycle"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Out for Delivery</h6>
                                        <small>Your order is on the way</small>
                                        @if(in_array($order->status, ['out_for_delivery', 'delivered']))
                                            <br><small class="text-muted">{{ $order->updated_at->format('g:i A') }}</small>
                                        @endif
                                    </div>
                                </div>
                                
                                <div class="progress-step {{ $order->status === 'delivered' ? 'completed' : ($order->status === 'out_for_delivery' ? 'active' : '') }}">
                                    <div class="step-icon">
                                        <i class="fas fa-home"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Delivered</h6>
                                        <small>Order has been delivered</small>
                                        @if($order->status === 'delivered')
                                            <br><small class="text-muted">{{ $order->delivered_at ? $order->delivered_at->format('g:i A') : $order->updated_at->format('g:i A') }}</small>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Delivery Info -->
                            <div class="delivery-info">
                                <h6><i class="fas fa-map-marker-alt me-2"></i>Delivery Address</h6>
                                <p class="mb-1"><strong>{{ $order->customer_name }}</strong></p>
                                <p class="mb-1">{{ $order->delivery_address }}</p>
                                <p class="mb-1">{{ $order->city }}, {{ $order->state }}</p>
                                @if($order->postal_code)
                                    <p class="mb-1">{{ $order->postal_code }}</p>
                                @endif
                                <p class="mb-0 text-muted">
                                    <i class="fas fa-phone me-1"></i>{{ $order->customer_phone }}
                                </p>
                                
                                <!-- Estimated Delivery Time -->
                                @if($order->estimated_delivery_time && $order->status !== 'delivered')
                                    <div class="alert alert-info mt-3">
                                        <i class="fas fa-clock me-2"></i>
                                        <strong>Estimated Delivery:</strong> 
                                        {{ $order->estimated_delivery_time->format('g:i A') }}
                                    </div>
                                @endif
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <!-- Order Items -->
                            <h6>Your Order</h6>
                            @foreach($order->orderItems as $item)
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="d-flex align-items-center">
                                        @if($item->foodItem && $item->foodItem->image_url)
                                            <img src="{{ $item->foodItem->image_url }}" 
                                                 class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                        @else
                                            <div class="bg-secondary rounded me-2 d-flex align-items-center justify-content-center" 
                                                 style="width: 40px; height: 40px;">
                                                <i class="fas fa-utensils text-white"></i>
                                            </div>
                                        @endif
                                        <div>
                                            <small class="fw-bold">{{ $item->food_name }}</small><br>
                                            <small class="text-muted">Qty: {{ $item->quantity }}</small>
                                        </div>
                                    </div>
                                    <span>RM{{ number_format($item->subtotal, 2) }}</span>
                                </div>
                            @endforeach
                            
                            <hr>
                            <!-- Order Summary -->
                            <div class="d-flex justify-content-between mb-1">
                                <span>Subtotal:</span>
                                <span>RM{{ number_format($order->subtotal, 2) }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-1">
                                <span>Delivery Fee:</span>
                                <span>RM{{ number_format($order->delivery_fee, 2) }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-1">
                                <span>Service Tax:</span>
                                <span>RM{{ number_format($order->service_tax, 2) }}</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <strong>Total: RM{{ number_format($order->total_amount, 2) }}</strong>
                            </div>
                            
                            <!-- Payment Method -->
                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-credit-card me-1"></i>
                                    Payment: {{ ucfirst(str_replace('_', ' ', $order->payment_method)) }}
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    @else
        <div class="col-12 text-center py-5">
            <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
            <h4>No orders found</h4>
            <p class="text-muted">You haven't placed any orders yet.</p>
            <a href="{{ route('menu') }}" class="btn btn-primary">
                <i class="fas fa-utensils me-2"></i>Start Ordering
            </a>
        </div>
    @endif
</div>

<style>
.order-progress .progress-step {
    display: flex;
    align-items: flex-start;
    margin-bottom: 25px;
    position: relative;
}

.order-progress .progress-step:not(:last-child)::after {
    content: '';
    position: absolute;
    left: 20px;
    top: 40px;
    width: 2px;
    height: 40px;
    background: #dee2e6;
}

.order-progress .progress-step.completed::after {
    background: #28a745;
}

.order-progress .progress-step.active::after {
    background: linear-gradient(to bottom, #28a745 50%, #dee2e6 50%);
}

.progress-step .step-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #dee2e6;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    color: #6c757d;
    flex-shrink: 0;
}

.progress-step.completed .step-icon {
    background: #28a745;
    color: white;
}

.progress-step.active .step-icon {
    background: #007bff;
    color: white;
    animation: pulse 2s infinite;
}

.step-content h6 {
    margin-bottom: 2px;
    font-size: 14px;
}

.step-content small {
    color: #6c757d;
    font-size: 12px;
}

.progress-step.completed .step-content h6 {
    color: #28a745;
    font-weight: 600;
}

.progress-step.active .step-content h6 {
    color: #007bff;
    font-weight: 600;
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
    }
    70% {
        box-shadow: 0 0 0 10px rgba(0, 123, 255, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(0, 123, 255, 0);
    }
}

.card {
    border: none;
    border-radius: 15px;
}

.card-header {
    border-radius: 15px 15px 0 0 !important;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}
</style>
@endsection