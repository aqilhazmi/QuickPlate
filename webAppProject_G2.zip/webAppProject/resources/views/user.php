@extends('master.layout')

@section('title', 'Dashboard')

@section('content')
<main class="main">
    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Welcome back, <span style="color: #ce1212;">{{ auth()->user()->name }}!</span></h1>
                    <h2>Ready to order some delicious halal food?</h2>
                    <div class="btns mt-4">
                        <a href="{{ route('menu') }}" class="btn-get-started scrollto">Browse Menu</a>
                        <a href="{{ route('cart.index') }}" class="btn-get-started scrollto ms-4">
                            View Cart @if($cartCount > 0)({{ $cartCount }})@endif
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section id="stats" class="about section light-background">
        <div class="container section-title" data-aos="fade-up">
            <h2>Your Statistics</h2>
            <div><span>Your</span> <span class="description-title">Order Journey</span></div>
        </div>

        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->count() }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $cartCount }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Items in Cart</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->where('status', 'delivered')->count() }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Completed Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ number_format(auth()->user()->orders->where('status', 'delivered')->sum('total_amount'), 0) }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Spent</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Recent Orders Section -->
    @if($recentOrders->count() > 0)
    <section id="recent-orders" class="menu section">
        <div class="container section-title" data-aos="fade-up">
            <h2>Recent Orders</h2>
            <div><span>Your Recent</span> <span class="description-title">Food Orders</span></div>
        </div>

        <div class="container" data-aos="fade-up" data-aos-delay="100">
            <div class="row gy-4">
                @foreach($recentOrders as $order)
                <div class="col-lg-4 col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Order {{ $order->order_number }}</span>
                            <span class="badge bg-{{ $order->status_color }}">{{ ucfirst($order->status) }}</span>
                        </div>
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted">{{ $order->formatted_order_date }}</h6>
                            <p class="card-text">
                                <strong>{{ $order->orderItems->count() }} item(s)</strong><br>
                                <span class="text-primary fw-bold">{{ $order->formatted_total }}</span>
                            </p>
                            <div class="d-grid gap-2">
                                <a href="{{ route('orders.show', $order) }}" class="btn btn-outline-primary btn-sm">
                                    <i class="bi bi-eye"></i> View Details
                                </a>
                                @if(in_array($order->status, ['confirmed', 'preparing']))
                                <a href="{{ route('orders.track', $order) }}" class="btn btn-primary btn-sm">
                                    <i class="bi bi-geo-alt"></i> Track Order
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>

            <div class="text-center mt-4">
                <a href="{{ route('orders.index') }}" class="btn-get-started">View All Orders</a>
            </div>
        </div>
    </section>
    @endif

    <!-- Featured Food Section -->
    <section id="featured-food" class="menu section light-background">
        <div class="container section-title" data-aos="fade-up">
            <h2>Our Specialties</h2>
            <div><span>Try Our Signature</span> <span class="description-title">Halal Dishes</span></div>
        </div>

        <div class="container isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
            <div class="row isotope-container" data-aos="fade-up" data-aos-delay="200">
                @foreach($featuredFoods as $food)
                <div class="col-lg-6 menu-item isotope-item">
                    @if($food->image)
                    <img src="{{ asset('assets/img/menu/' . $food->image) }}" class="menu-img" alt="{{ $food->name }}">
                    @else
                    <img src="{{ asset('assets/img/menu/lobster-bisque.jpg') }}" class="menu-img" alt="{{ $food->name }}">
                    @endif
                    <div class="menu-content">
                        <a href="#">{{ $food->name }}</a>
                        <span>{{ $food->formatted_price }}</span>
                    </div>
                    <div class="menu-ingredients">
                        {{ $food->description }}
                        <div class="mt-2">
                            <form action="{{ route('cart.add', $food) }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-primary">
                                    <i class="bi bi-cart-plus"></i> Add to Cart
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>

            <div class="text-center mt-4">
                <a href="{{ route('menu') }}" class="btn-get-started">View Full Menu</a>
            </div>
        </div>
    </section>

    <!-- Quick Actions Section -->
    <section id="quick-actions" class="why-us section">
        <div class="container section-title" data-aos="fade-up">
            <h2>Quick Actions</h2>
            <div><span>Everything You Need</span> <span class="description-title">At Your Fingertips</span></div>
        </div>

        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-item text-center">
                        <span><i class="bi bi-grid-3x3-gap-fill" style="font-size: 3rem; color: #ce1212;"></i></span>
                        <h4><a href="{{ route('menu') }}" class="stretched-link">Browse Menu</a></h4>
                        <p>Explore our delicious halal food options crafted with care and authentic flavors.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-item text-center">
                        <span><i class="bi bi-cart3" style="font-size: 3rem; color: #ce1212;"></i></span>
                        <h4><a href="{{ route('cart.index') }}" class="stretched-link">My Cart</a></h4>
                        <p>Review and checkout your selected items for quick and easy ordering.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="card-item text-center">
                        <span><i class="bi bi-clock-history" style="font-size: 3rem; color: #ce1212;"></i></span>
                        <h4><a href="{{ route('orders.index') }}" class="stretched-link">Order History</a></h4>
                        <p>View your past and current orders, track delivery status and reorder favorites.</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="card-item text-center">
                        <span><i class="bi bi-person-gear" style="font-size: 3rem; color: #ce1212;"></i></span>
                        <h4><a href="#" class="stretched-link" data-bs-toggle="modal" data-bs-target="#profileModal">Profile Settings</a></h4>
                        <p>Update your account information and delivery preferences.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Profile Modal -->
<div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="profileModalLabel">
                    <i class="bi bi-person-gear me-2"></i>Profile Information
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="profileForm" method="POST" action="#">
                    @csrf
                    @method('PATCH')
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="{{ auth()->user()->name }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="{{ auth()->user()->email }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone" value="{{ auth()->user()->phone }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Delivery Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3" required>{{ auth()->user()->address }}</textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Close
                </button>
                <button type="submit" form="profileForm" class="btn btn-primary">
                    <i class="bi bi-check-circle"></i> Save Changes
                </button>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    // Initialize PureCounter for stats animation
    document.addEventListener('DOMContentLoaded', function() {
        // This will work with the existing PureCounter from Delicious template
        if (typeof PureCounter !== 'undefined') {
            new PureCounter();
        }
    });
</script>
@endpush

@endsection@extends('master.layout')

@section('content')
<!-- Hero Section -->
<section id="hero" class="d-flex align-items-center" style="min-height: 60vh;">
    <div class="container position-relative text-center text-lg-start">
        <div class="row">
            <div class="col-lg-8">
                <h1>Welcome back, <span style="color: #ffb03b;">{{ auth()->user()->name }}!</span></h1>
                <h2>Ready to order some delicious halal food?</h2>
                
                <div class="btns mt-4">
                    <a href="{{ route('menu') }}" class="btn-menu animated fadeInUp scrollto">Browse Menu</a>
                    <a href="{{ route('cart.index') }}" class="btn-book animated fadeInUp scrollto">
                        View Cart ({{ $cartCount }})
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Dashboard Content -->
<main id="main">
    <!-- Quick Stats Section -->
    <section id="stats" class="stats section-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->count() }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $cartCount }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Items in Cart</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->where('status', 'delivered')->count() }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Completed Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->where('status', 'delivered')->sum('total_amount') }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Spent</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Recent Orders Section -->
    @if($recentOrders->count() > 0)
    <section id="recent-orders" class="recent-orders">
        <div class="container">
            <div class="section-title">
                <h2>Your Recent Orders</h2>
                <p>Keep track of your recent food orders</p>
            </div>

            <div class="row">
                @foreach($recentOrders as $order)
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Order {{ $order->order_number }}</span>
                            <span class="badge bg-{{ $order->status_color }}">{{ ucfirst($order->status) }}</span>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <small class="text-muted">{{ $order->formatted_order_date }}</small>
                            </p>
                            <p class="card-text">
                                {{ $order->orderItems->count() }} item(s) • {{ $order->formatted_total }}
                            </p>
                            <div class="d-grid gap-2">
                                <a href="{{ route('orders.show', $order) }}" class="btn btn-outline-primary btn-sm">
                                    View Details
                                </a>
                                @if(in_array($order->status, ['confirmed', 'preparing']))
                                <a href="{{ route('orders.track', $order) }}" class="btn btn-primary btn-sm">
                                    Track Order
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>

            <div class="text-center">
                <a href="{{ route('orders.index') }}" class="btn btn-primary">View All Orders</a>
            </div>
        </div>
    </section>
    @endif

    <!-- Featured Food Section -->
    <section id="featured-food" class="menu section-bg">
        <div class="container">
            <div class="section-title">
                <h2>Our Specialties</h2>
                <p>Try our signature halal dishes</p>
            </div>

            <div class="row">
                @foreach($featuredFoods as $food)
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100">
                        @if($food->image)
                        <img src="{{ asset('assets/img/menu/' . $food->image) }}" class="card-img-top" alt="{{ $food->name }}" style="height: 200px; object-fit: cover;">
                        @endif
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">{{ $food->name }}</h5>
                            <p class="card-text flex-grow-1">{{ $food->description }}</p>
                            <div class="d-flex justify-content-between align-items-center mt-auto">
                                <span class="text-primary fw-bold">{{ $food->formatted_price }}</span>
                                <form action="{{ route('cart.add', $food) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-primary btn-sm">
                                        <i class="bi bi-cart-plus"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>

            <div class="text-center">
                <a href="{{ route('menu') }}" class="btn btn-primary">View Full Menu</a>
            </div>
        </div>
    </section>

    <!-- Quick Actions Section -->
    <section id="quick-actions" class="quick-actions">
        <div class="container">
            <div class="section-title">
                <h2>Quick Actions</h2>
                <p>Everything you need at your fingertips</p>
            </div>

            <div class="row text-center">
                <div class="col-lg-3 col-md-6 mb-4">
                    <a href="{{ route('menu') }}" class="text-decoration-none">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body">
                                <i class="bi bi-grid-3x3-gap-fill text-primary" style="font-size: 3rem;"></i>
                                <h5 class="card-title mt-3">Browse Menu</h5>
                                <p class="card-text">Explore our delicious halal food options</p>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <a href="{{ route('cart.index') }}" class="text-decoration-none">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body">
                                <i class="bi bi-cart3 text-primary" style="font-size: 3rem;"></i>
                                <h5 class="card-title mt-3">My Cart</h5>
                                <p class="card-text">Review and checkout your selected items</p>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <a href="{{ route('orders.index') }}" class="text-decoration-none">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body">
                                <i class="bi bi-clock-history text-primary" style="font-size: 3rem;"></i>
                                <h5 class="card-title mt-3">Order History</h5>
                                <p class="card-text">View your past and current orders</p>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#profileModal">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body">
                                <i class="bi bi-person-gear text-primary" style="font-size: 3rem;"></i>
                                <h5 class="card-title mt-3">Profile Settings</h5>
                                <p class="card-text">Update your account information</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Profile Modal -->
<div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="profileModalLabel">Profile Information</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="#" method="POST">
                    @csrf
                    @method('PATCH')
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="{{ auth()->user()->name }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="{{ auth()->user()->email }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone" value="{{ auth()->user()->phone }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Delivery Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3" required>{{ auth()->user()->address }}</textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
    </div>
</div>
@endsection