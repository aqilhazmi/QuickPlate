@extends('master.layout')

@section('title', 'Checkout')

@section('content')
<main class="main">
    <!-- Checkout Header -->
    <section id="checkout-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Checkout</h1>
                    <p>Complete your order and enjoy delicious halal food delivered to your door</p>
                    <div class="btns mt-4">
                        <a href="{{ route('cart.index') }}" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Cart
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Checkout Form -->
    <section id="checkout-form" class="section">
        <div class="container">
            
            @if($errors->any())
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i>
                    <strong>Please fix the following errors:</strong>
                    <ul class="mb-0 mt-2">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <form action="{{ route('checkout.store') }}" method="POST" id="checkout-form">
                @csrf
                
                <div class="row">
                    <!-- Customer Information -->
                    <div class="col-lg-8">
                        
                        <!-- Delivery Information -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-truck"></i> Delivery Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- Customer Name -->
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control @error('customer_name') is-invalid @enderror" 
                                               id="customer_name" 
                                               name="customer_name" 
                                               value="{{ old('customer_name', auth()->user()->name) }}" 
                                               placeholder="Enter your full name"
                                               required>
                                        @error('customer_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Customer Phone -->
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control @error('customer_phone') is-invalid @enderror" 
                                               id="customer_phone" 
                                               name="customer_phone" 
                                               value="{{ old('customer_phone', auth()->user()->phone) }}" 
                                               placeholder="e.g., +60123456789"
                                               required>
                                        @error('customer_phone')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Customer Email -->
                                <div class="mb-3">
                                    <label for="customer_email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                    <input type="email" 
                                           class="form-control @error('customer_email') is-invalid @enderror" 
                                           id="customer_email" 
                                           name="customer_email" 
                                           value="{{ old('customer_email', auth()->user()->email) }}" 
                                           placeholder="your.email@example.com"
                                           required>
                                    @error('customer_email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Delivery Address -->
                                <div class="mb-3">
                                    <label for="delivery_address" class="form-label">Delivery Address <span class="text-danger">*</span></label>
                                    <textarea class="form-control @error('delivery_address') is-invalid @enderror" 
                                              id="delivery_address" 
                                              name="delivery_address" 
                                              rows="3" 
                                              placeholder="Enter your complete delivery address with unit number, street name, etc."
                                              required>{{ old('delivery_address', auth()->user()->address) }}</textarea>
                                    @error('delivery_address')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="row">
                                    <!-- Postal Code -->
                                    <div class="col-md-4 mb-3">
                                        <label for="postal_code" class="form-label">Postal Code</label>
                                        <input type="text" 
                                               class="form-control @error('postal_code') is-invalid @enderror" 
                                               id="postal_code" 
                                               name="postal_code" 
                                               value="{{ old('postal_code') }}" 
                                               placeholder="e.g., 53100">
                                        @error('postal_code')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- City -->
                                    <div class="col-md-4 mb-3">
                                        <label for="city" class="form-label">City <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control @error('city') is-invalid @enderror" 
                                               id="city" 
                                               name="city" 
                                               value="{{ old('city', 'Kuala Lumpur') }}" 
                                               placeholder="City"
                                               required>
                                        @error('city')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- State -->
                                    <div class="col-md-4 mb-3">
                                        <label for="state" class="form-label">State <span class="text-danger">*</span></label>
                                        <select class="form-select @error('state') is-invalid @enderror" 
                                                id="state" 
                                                name="state" 
                                                required>
                                            <option value="">Select State</option>
                                            <option value="Selangor" {{ old('state', 'Selangor') == 'Selangor' ? 'selected' : '' }}>Selangor</option>
                                            <option value="Kuala Lumpur" {{ old('state') == 'Kuala Lumpur' ? 'selected' : '' }}>Kuala Lumpur</option>
                                            <option value="Putrajaya" {{ old('state') == 'Putrajaya' ? 'selected' : '' }}>Putrajaya</option>
                                            <option value="Johor" {{ old('state') == 'Johor' ? 'selected' : '' }}>Johor</option>
                                            <option value="Perak" {{ old('state') == 'Perak' ? 'selected' : '' }}>Perak</option>
                                            <option value="Penang" {{ old('state') == 'Penang' ? 'selected' : '' }}>Penang</option>
                                            <option value="Pahang" {{ old('state') == 'Pahang' ? 'selected' : '' }}>Pahang</option>
                                            <option value="Negeri Sembilan" {{ old('state') == 'Negeri Sembilan' ? 'selected' : '' }}>Negeri Sembilan</option>
                                            <option value="Melaka" {{ old('state') == 'Melaka' ? 'selected' : '' }}>Melaka</option>
                                            <option value="Kedah" {{ old('state') == 'Kedah' ? 'selected' : '' }}>Kedah</option>
                                            <option value="Perlis" {{ old('state') == 'Perlis' ? 'selected' : '' }}>Perlis</option>
                                            <option value="Kelantan" {{ old('state') == 'Kelantan' ? 'selected' : '' }}>Kelantan</option>
                                            <option value="Terengganu" {{ old('state') == 'Terengganu' ? 'selected' : '' }}>Terengganu</option>
                                            <option value="Sabah" {{ old('state') == 'Sabah' ? 'selected' : '' }}>Sabah</option>
                                            <option value="Sarawak" {{ old('state') == 'Sarawak' ? 'selected' : '' }}>Sarawak</option>
                                        </select>
                                        @error('state')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Payment Information -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-credit-card"></i> Payment Method</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="radio" 
                                                   name="payment_method" 
                                                   id="cash_on_delivery" 
                                                   value="cash_on_delivery"
                                                   {{ old('payment_method', 'cash_on_delivery') == 'cash_on_delivery' ? 'checked' : '' }}>
                                            <label class="form-check-label" for="cash_on_delivery">
                                                <i class="bi bi-cash-coin text-success"></i>
                                                <strong>Cash on Delivery</strong>
                                                <small class="d-block text-muted">Pay when your order arrives</small>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="radio" 
                                                   name="payment_method" 
                                                   id="bank_transfer" 
                                                   value="bank_transfer"
                                                   {{ old('payment_method') == 'bank_transfer' ? 'checked' : '' }}>
                                            <label class="form-check-label" for="bank_transfer">
                                                <i class="bi bi-bank text-primary"></i>
                                                <strong>Bank Transfer</strong>
                                                <small class="d-block text-muted">Transfer to our bank account</small>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="radio" 
                                                   name="payment_method" 
                                                   id="online_payment" 
                                                   value="online_payment"
                                                   {{ old('payment_method') == 'online_payment' ? 'checked' : '' }}>
                                            <label class="form-check-label" for="online_payment">
                                                <i class="bi bi-phone text-info"></i>
                                                <strong>Online Payment</strong>
                                                <small class="d-block text-muted">FPX, Credit Card, E-Wallet</small>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                @error('payment_method')
                                    <div class="text-danger small">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Special Instructions -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-chat-text"></i> Special Instructions (Optional)</h5>
                            </div>
                            <div class="card-body">
                                <textarea class="form-control @error('special_instructions') is-invalid @enderror" 
                                          id="special_instructions" 
                                          name="special_instructions" 
                                          rows="3" 
                                          placeholder="Any special requests, dietary requirements, or delivery instructions...">{{ old('special_instructions') }}</textarea>
                                <div class="form-text">Let us know if you have any special requirements or delivery preferences.</div>
                                @error('special_instructions')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                    </div>

                    <!-- Order Summary -->
                    <div class="col-lg-4">
                        <div class="card shadow-sm sticky-top" style="top: 100px;">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="bi bi-receipt"></i> Order Summary</h5>
                            </div>
                            <div class="card-body">
                                
                                <!-- Cart Items -->
                                <div class="order-items mb-3">
                                    <h6 class="mb-3">Your Items ({{ $cartItems->sum('quantity') }})</h6>
                                    @foreach($cartItems as $item)
                                    <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                                        <img src="{{ $item->foodItem->image_url }}" 
                                             alt="{{ $item->foodItem->name }}" 
                                             class="rounded me-3"
                                             style="width: 50px; height: 50px; object-fit: cover;">
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">{{ $item->foodItem->name }}</h6>
                                            <small class="text-muted">Qty: {{ $item->quantity }} × {{ $item->foodItem->formatted_price }}</small>
                                        </div>
                                        <div class="text-end">
                                            <strong>{{ $item->formatted_subtotal }}</strong>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                                <!-- Cost Breakdown -->
                                <div class="cost-breakdown">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Subtotal:</span>
                                        <span>RM {{ number_format($subtotal, 2) }}</span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Delivery Fee:</span>
                                        <span>RM {{ number_format($deliveryFee, 2) }}</span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Service Tax (6%):</span>
                                        <span>RM {{ number_format($serviceTax, 2) }}</span>
                                    </div>
                                    <hr>
                                    <div class="d-flex justify-content-between mb-3">
                                        <strong>Total:</strong>
                                        <strong class="text-primary h5">RM {{ number_format($total, 2) }}</strong>
                                    </div>
                                </div>

                                <!-- Estimated Delivery -->
                                <div class="delivery-info bg-light p-3 rounded mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-clock text-primary me-2"></i>
                                        <div>
                                            <strong>Estimated Delivery Time</strong>
                                            <div class="text-muted small">45 minutes from order confirmation</div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Place Order Button -->
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg" id="place-order-btn">
                                        <i class="bi bi-check-circle"></i> Place Order
                                    </button>
                                </div>

                                <!-- Security Info -->
                                <div class="text-center mt-3">
                                    <small class="text-muted">
                                        <i class="bi bi-shield-check text-success"></i> 
                                        100% Halal Guaranteed | Secure Ordering
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </section>
</main>

@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('checkout-form');
    const submitBtn = document.getElementById('place-order-btn');
    
    form.addEventListener('submit', function(e) {
        // Show loading state
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Processing Order...';
        submitBtn.disabled = true;
        
        // Re-enable after 10 seconds in case of error
        setTimeout(() => {
            if (submitBtn.disabled) {
                submitBtn.innerHTML = '<i class="bi bi-check-circle"></i> Place Order';
                submitBtn.disabled = false;
            }
        }, 10000);
    });
    
    // Auto-fill name if not already filled
    const nameField = document.getElementById('customer_name');
    if (!nameField.value.trim()) {
        nameField.value = '{{ auth()->user()->name }}';
    }
});
</script>
@endpush