@extends('layouts.auth')

@section('title', 'Register - QuickPlate')
@section('subtitle', 'Join Our Halal Food Community!')

@section('content')
<form method="POST" action="{{ route('register') }}">
    @csrf
    
    <div class="row">
        <div class="col-12 mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" 
                   class="form-control @error('name') is-invalid @enderror" 
                   id="name"
                   name="name" 
                   value="{{ old('name') }}" 
                   placeholder="Enter your full name" 
                   required 
                   autocomplete="name" 
                   autofocus>
            
            @error('name')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>

        <div class="col-12 mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" 
                   class="form-control @error('email') is-invalid @enderror" 
                   id="email"
                   name="email" 
                   value="{{ old('email') }}" 
                   placeholder="Enter your email address" 
                   required 
                   autocomplete="email">
            
            @error('email')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>

        <div class="col-12 mb-3">
            <label for="phone" class="form-label">Phone Number</label>
            <input type="tel" 
                   class="form-control @error('phone') is-invalid @enderror" 
                   id="phone"
                   name="phone" 
                   value="{{ old('phone') }}" 
                   placeholder="e.g., +60123456789" 
                   required>
            
            @error('phone')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>

        <div class="col-12 mb-3">
            <label for="address" class="form-label">Delivery Address</label>
            <textarea class="form-control @error('address') is-invalid @enderror" 
                      id="address"
                      name="address" 
                      placeholder="Enter your complete delivery address" 
                      rows="3" 
                      required>{{ old('address') }}</textarea>
            
            @error('address')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" 
                   class="form-control @error('password') is-invalid @enderror" 
                   id="password"
                   name="password" 
                   placeholder="Minimum 8 characters" 
                   required 
                   autocomplete="new-password">
            
            @error('password')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="password_confirmation" class="form-label">Confirm Password</label>
            <input type="password" 
                   class="form-control" 
                   id="password_confirmation"
                   name="password_confirmation" 
                   placeholder="Re-enter password" 
                   required 
                   autocomplete="new-password">
        </div>
    </div>

    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="terms" required>
            <label class="form-check-label" for="terms">
                <small>I agree to the <a href="#" class="text-decoration-none">Terms of Service</a> and confirm that I understand all food will be prepared according to halal standards</small>
            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-auth">
        <i class="bi bi-person-plus me-2"></i>Create My Account
    </button>

    <div class="auth-links">
        <span class="text-muted">Already have an account?</span><br>
        <a href="{{ route('login') }}" class="fw-bold">
            <i class="bi bi-box-arrow-in-right"></i> Login Here
        </a>
    </div>
</form>

<!-- Halal Assurance -->
<div class="text-center mt-4 pt-3 border-top">
    <small class="text-success">
        <i class="bi bi-shield-check"></i>
        <strong>100% Halal Certified</strong><br>
        All our food is prepared according to Islamic dietary guidelines
    </small>
</div>
@endsection