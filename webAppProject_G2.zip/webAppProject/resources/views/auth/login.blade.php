@extends('layouts.auth')

@section('title', 'Login - QuickPlate')
@section('subtitle', 'Welcome Back to Our Halal Kitchen!')

@section('content')
<form method="POST" action="{{ route('login') }}">
    @csrf
    
    <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <input type="email" 
               class="form-control @error('email') is-invalid @enderror" 
               id="email"
               name="email" 
               value="{{ old('email') }}" 
               placeholder="Enter your email address" 
               required 
               autocomplete="email" 
               autofocus>
        
        @error('email')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" 
               class="form-control @error('password') is-invalid @enderror" 
               id="password"
               name="password" 
               placeholder="Enter your password" 
               required 
               autocomplete="current-password">
        
        @error('password')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
            <label class="form-check-label" for="remember">
                Remember me on this device
            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-auth">
        <i class="bi bi-box-arrow-in-right me-2"></i>Login to QuickPlate
    </button>

    <div class="auth-links">
        @if (Route::has('password.request'))
            <a href="{{ route('password.request') }}">
                <i class="bi bi-key"></i> Forgot Your Password?
            </a>
        @endif
        <br><br>
        <span class="text-muted">Don't have an account yet?</span><br>
        <a href="{{ route('register') }}" class="fw-bold">
            <i class="bi bi-person-plus"></i> Create New Account
        </a>
    </div>
</form>

<!-- Admin Login Helper -->
<div class="text-center mt-4 pt-3 border-top">
    <small class="text-muted">
        <i class="bi bi-shield-check text-warning"></i>
        <strong>Test Accounts:</strong><br>
        Admin: admin@quickplate.com / admin123<br>
        User: user@test.com / password
    </small>
</div>
@endsection