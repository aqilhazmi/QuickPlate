@extends('master.layout')

@section('content')
<main class="main">

  <!-- Hero Section -->
  <section id="hero" class="hero section dark-background">
    <div id="hero-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
      <div class="carousel-item active">
        <img src="{{ asset('assets/img/carousel/carousel.jpg') }}" alt="">
        <div class="carousel-container">
  @auth
    <h2><span>Welcome back, {{ auth()->user()->name }}!</span></h2>
    <p>Ready to order your favorite halal meals? We've prepared fresh, wholesome food just for you.</p>
    <div>
      <a href="{{ route('menu') }}" class="btn-get-started">Browse Menu</a>
      <a href="{{ route('orders.tracking') }}" class="btn-get-started">
        <i class="bi bi-truck"></i> Track Orders
      </a>
      <a href="{{ route('dashboard') }}" class="btn-get-started">My Dashboard</a>
    </div>
  @else
    <h2><span>Just honest food</span></h2>
    <p>We believe food should be honest - clean, wholesome and easy to get. QuickPlate helps you order your favourite meals quickly without compromising on what matters most.</p>
    <div>
      <a href="#menu" class="btn-get-started">Our Menu</a>
      <a href="{{ route('register') }}" class="btn-get-started">Join Us</a>
    </div>
  @endauth
</div>
      </div>
    </div>
  </section><!-- /Hero Section -->

  <!-- About Section -->
  <section id="about" class="about section light-background">
    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-6 position-relative align-self-start" data-aos="fade-up" data-aos-delay="100">
          <img src="{{ asset('assets/img/about.jpeg') }}" class="img-fluid" alt="">
        </div>
        <div class="col-lg-6 content" data-aos="fade-up" data-aos-delay="200">
          <h3>Fresh Ingredients, Thoughtfully Sourced - Real Halal Food Made Simple.</h3>
          <p class="fst-italic">
            At QuickPlate, we believe great meals start with great ingredients. That's why we work directly with trusted halal suppliers who share our commitment to quality and Islamic dietary guidelines.
          </p>
          <ul>
            <li><i class="bi bi-check2-all"></i> <span>100% Halal certified ingredients ensuring compliance with Islamic dietary laws</span></li>
            <li><i class="bi bi-check2-all"></i> <span>Locally sourced fresh ingredients supporting community growers</span></li>
            <li><i class="bi bi-check2-all"></i> <span>Complete transparency in our sourcing process so you know exactly where your food comes from</span></li>
          </ul>
          <p>
            Every meal tells a story of careful selection and honest preparation according to halalan toyyiban principles. 
            We partner with certified halal suppliers and trusted local farms who prioritize both quality and religious compliance.
          </p>
        </div>
      </div>
    </div>
  </section><!-- /About Section -->

  <!-- Why Us Section -->
  <section id="why-us" class="why-us section">
    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
      <h2>Why Choose QuickPlate</h2>
      <div><span>Why choose</span> <span class="description-title">Our Halal Service</span></div>
    </div><!-- End Section Title -->

    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
          <div class="card-item">
            <span>01</span>
            <h4><a href="" class="stretched-link">Choose Your Halal Meal</a></h4>
            <p>Browse our curated selection of 100% halal-certified dishes. From traditional Malaysian comfort food to healthy options, every meal meets strict Islamic dietary requirements.</p>
          </div>
        </div><!-- Card Item -->

        <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
          <div class="card-item">
            <span>02</span>
            <h4><a href="" class="stretched-link">Quick Halal Delivery</a></h4>
            <p>Your food is prepared fresh in our halal-certified kitchens and delivered fast to your door. We ensure proper handling throughout the entire process.</p>
          </div>
        </div><!-- Card Item -->

        <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
          <div class="card-item">
            <span>03</span>
            <h4><a href="" class="stretched-link">Enjoy With Confidence</a></h4>
            <p>Savor honest, wholesome halal meals without worry. No compromises on religious compliance or quality - just great food made simple and trustworthy.</p>
          </div>
        </div><!-- Card Item -->
      </div>
    </div>
  </section><!-- /Why Us Section -->

  @auth
    <!-- Quick Stats for Logged In Users 
    <section id="user-stats" class="about section">
      <div class="container section-title" data-aos="fade-up">
        <h2>Your QuickPlate Journey</h2>
        <div><span>Your Order</span> <span class="description-title">Statistics</span></div>
      </div>
      
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->count() }}" data-purecounter-duration="1" class="purecounter"></span>
              <p>Total Orders</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="stats-item text-center w-100 h-100">
              @php
                $cart = auth()->user()->cart;
                $cartCount = $cart ? $cart->cartItems->sum('quantity') : 0;
              @endphp
              <span data-purecounter-start="0" data-purecounter-end="{{ $cartCount }}" data-purecounter-duration="1" class="purecounter"></span>
              <p>Items in Cart</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="{{ auth()->user()->orders->where('status', 'delivered')->count() }}" data-purecounter-duration="1" class="purecounter"></span>
              <p>Completed Orders</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="stats-item text-center w-100 h-100">
              <span class="purecounter">RM</span>
              <span data-purecounter-start="0" data-purecounter-end="{{ number_format(auth()->user()->orders->where('status', 'delivered')->sum('total_amount'), 0) }}" data-purecounter-duration="1" class="purecounter"></span>
              <p>Total Spent</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  @endauth
  -->
  <!-- Menu Section -->
  <section id="menu" class="menu section">
    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
      <h2>Menu</h2>
      <div><span>Check Our Tasty</span> <span class="description-title">Halal Menu</span></div>
    </div><!-- End Section Title -->

    <div class="container isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
      <div class="row" data-aos="fade-up" data-aos-delay="100">
        <div class="col-lg-12 d-flex justify-content-center">
          <ul class="menu-filters isotope-filters">
            <li data-filter="*" class="filter-active">All</li>
            <li data-filter=".filter-food">Food</li>
            <li data-filter=".filter-drinks">Drinks</li>
            <li data-filter=".filter-dessert">Desserts</li>
            <li data-filter=".filter-specialty">Specialty</li>
          </ul>
        </div>
      </div><!-- Menu Filters -->

      <div class="row isotope-container" data-aos="fade-up" data-aos-delay="200">
        
        @php
          // Get real food items from database (limit to 6 for homepage)
          $featuredItems = \App\Models\FoodItem::where('is_available', true)
                                                ->latest()
                                                ->take(6)
                                                ->get();
        @endphp

        @if($featuredItems->count() > 0)
          @foreach($featuredItems as $item)
          <div class="col-lg-6 menu-item isotope-item filter-{{ strtolower($item->category) }}">
            <img src="{{ $item->image_url }}" class="menu-img" alt="{{ $item->name }}">
            <div class="menu-content">
              <a href="#">{{ $item->name }}</a><span>RM {{ number_format($item->price, 2) }}</span>
            </div>
            <div class="menu-ingredients">
              {{ Str::limit($item->description, 80) }}
              @auth
                <div class="mt-2">
                  <button class="btn btn-sm btn-primary add-to-cart-btn" 
                          data-food-id="{{ $item->id }}" 
                          data-food-name="{{ $item->name }}">
                    <i class="bi bi-cart-plus"></i> Add to Cart
                  </button>
                </div>
              @endauth
            </div>
          </div><!-- Menu Item -->
          @endforeach
        @else
          <!-- Fallback to sample items if no database items exist -->
          @php
            $sampleItems = [
              ['name' => 'Nasi Lemak Special', 'price' => 8.50, 'category' => 'food', 'description' => 'Traditional Malaysian coconut rice with sambal, anchovies, peanuts, boiled egg, and fried chicken', 'image' => 'lobster-bisque.jpg'],
              ['name' => 'Ayam Penyet', 'price' => 9.90, 'category' => 'food', 'description' => 'Indonesian fried chicken served with spicy sambal and steamed rice', 'image' => 'bread-barrel.jpg'],
              ['name' => 'Mee Goreng Mamak', 'price' => 7.00, 'category' => 'food', 'description' => 'Spicy stir-fried yellow noodles with vegetables, tofu, and egg', 'image' => 'cake.jpg'],
              ['name' => 'Teh Tarik', 'price' => 2.50, 'category' => 'drinks', 'description' => 'Traditional Malaysian pulled milk tea', 'image' => 'caesar.jpg'],
              ['name' => 'Rendang Daging', 'price' => 12.90, 'category' => 'specialty', 'description' => 'Slow-cooked beef in coconut milk and spices - our signature dish', 'image' => 'lobster-roll.jpg'],
              ['name' => 'Cendol', 'price' => 4.50, 'category' => 'dessert', 'description' => 'Traditional dessert with pandan jelly, coconut milk, and palm sugar', 'image' => 'mozzarella.jpg'],
            ];
          @endphp

          @foreach($sampleItems as $item)
          <div class="col-lg-6 menu-item isotope-item filter-{{ $item['category'] }}">
            <img src="{{ asset('assets/img/menu/' . $item['image']) }}" class="menu-img" alt="{{ $item['name'] }}">
            <div class="menu-content">
              <a href="#">{{ $item['name'] }}</a><span>RM {{ number_format($item['price'], 2) }}</span>
            </div>
            <div class="menu-ingredients">
              {{ $item['description'] }}
              @auth
                <div class="mt-2">
                  <button class="btn btn-sm btn-secondary" disabled>
                    <i class="bi bi-info-circle"></i> Sample Item
                  </button>
                </div>
              @endauth
            </div>
          </div><!-- Menu Item -->
          @endforeach
        @endif

      </div><!-- Menu Container -->

      <div class="text-center mt-4">
        @auth
          <a href="{{ route('menu') }}" class="btn-get-started">View Full Menu</a>
        @else
          <a href="{{ route('register') }}" class="btn-get-started">Register to Order</a>
        @endauth
      </div>

    </div>
  </section><!-- /Menu Section -->

  <!-- CTA Section for Guests -->
  @guest
  <section id="cta" class="about section dark-background">
    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-8 content text-center mx-auto" data-aos="fade-up" data-aos-delay="200">
          <h3 style="color: white;">Ready to Experience Halal Food Delivery?</h3>
          <p class="fst-italic" style="color: #ccc;">
            Join thousands of satisfied customers who trust QuickPlate for their halal food needs. 
            Quick registration, fast delivery, and 100% halal guarantee.
          </p>
          <div class="mt-4">
            <a href="{{ route('register') }}" class="btn-get-started me-3">
              <i class="bi bi-person-plus"></i> Register Now
            </a>
            <a href="{{ route('login') }}" class="btn-get-started">
              <i class="bi bi-box-arrow-in-right"></i> Login
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
  @endguest

  <!-- Contact Section -->
  <section id="contact" class="contact section">
    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
      <h2>Contact</h2>
      <div><span>Get in</span> <span class="description-title">Touch</span></div>
    </div><!-- End Section Title -->

    <div class="mb-5">
      <iframe style="width: 100%; height: 400px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.6548926306147!2d101.71194731475395!3d3.2517064974778656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc3843bfb6a031%3A0x2dc5e067aae3ab84!2sKuala%20Lumpur%2C%20Federal%20Territory%20of%20Kuala%20Lumpur%2C%20Malaysia!5e0!3m2!1sen!2smy!4v1635000000000!5m2!1sen!2smy" frameborder="0" allowfullscreen></iframe>
    </div><!-- End Google Maps -->

    
  </section><!-- /Contact Section -->

</main>

<!-- Toast for notifications -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="cart-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <i class="bi bi-cart-check text-success me-2"></i>
            <strong class="me-auto">Cart</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body" id="toast-message">
            <!-- Message will be inserted here -->
        </div>
    </div>
</div>

@auth
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add to cart functionality
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const foodId = this.dataset.foodId;
            const foodName = this.dataset.foodName;
            const originalText = this.innerHTML;
            
            // Show loading state
            this.innerHTML = '<i class="bi bi-hourglass-split"></i> Adding...';
            this.disabled = true;
            
            addToCart(foodId, foodName, this, originalText);
        });
    });

    function addToCart(foodId, foodName, button, originalText) {
        fetch(`/api/cart/add/${foodId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                quantity: 1
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update cart count in navbar
                updateNavbarCartCount(data.cart_count);
                
                // Show success state
                button.innerHTML = '<i class="bi bi-check-circle"></i> Added!';
                button.classList.remove('btn-primary');
                button.classList.add('btn-success');
                
                // Show toast notification
                showToast(data.message);
                
                // Reset button after 2 seconds
                setTimeout(() => {
                    button.innerHTML = originalText;
                    button.classList.remove('btn-success');
                    button.classList.add('btn-primary');
                    button.disabled = false;
                }, 2000);
            } else {
                // Show error state
                button.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Error';
                button.classList.remove('btn-primary');
                button.classList.add('btn-danger');
                
                showToast(data.message || 'Error adding item to cart', 'error');
                
                // Reset button after 2 seconds
                setTimeout(() => {
                    button.innerHTML = originalText;
                    button.classList.remove('btn-danger');
                    button.classList.add('btn-primary');
                    button.disabled = false;
                }, 2000);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            
            // Show error state
            button.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Error';
            button.classList.remove('btn-primary');
            button.classList.add('btn-danger');
            
            showToast('Network error. Please try again.', 'error');
            
            // Reset button after 2 seconds
            setTimeout(() => {
                button.innerHTML = originalText;
                button.classList.remove('btn-danger');
                button.classList.add('btn-primary');
                button.disabled = false;
            }, 2000);
        });
    }

    function updateNavbarCartCount(count) {
        // Find the cart link in navbar
        const cartLink = document.querySelector('a[href*="cart"]');
        if (cartLink) {
            // Remove existing badge
            const existingBadge = cartLink.querySelector('.auth-badge');
            if (existingBadge) {
                existingBadge.remove();
            }
            
            // Add new badge if count > 0
            if (count > 0) {
                const badge = document.createElement('span');
                badge.className = 'auth-badge';
                badge.textContent = count;
                cartLink.appendChild(badge);
            }
        }
    }

    function showToast(message, type = 'success') {
        const toast = document.getElementById('cart-toast');
        const toastMessage = document.getElementById('toast-message');
        const toastIcon = toast.querySelector('.toast-header i');
        
        toastMessage.textContent = message;
        
        // Update icon and color based on type
        if (type === 'error') {
            toastIcon.className = 'bi bi-exclamation-triangle text-danger me-2';
        } else {
            toastIcon.className = 'bi bi-cart-check text-success me-2';
        }
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }
});
</script>
<!-- Toast for notifications -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="cart-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <i class="bi bi-cart-check text-success me-2"></i>
            <strong class="me-auto">Cart</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body" id="toast-message">
            <!-- Message will be inserted here -->
        </div>
    </div>
</div>
@endauth

@endsection