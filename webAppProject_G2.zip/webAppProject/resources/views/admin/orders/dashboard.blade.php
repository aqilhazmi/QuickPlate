@extends('master.layout')

@section('title', 'Orders Dashboard')

@section('content')
<main class="main">
    <!-- Header -->
    <section id="admin-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1><i class="bi bi-speedometer2"></i> Orders Dashboard</h1>
                    <p>Real-time overview of your restaurant orders</p>
                    <div class="btns mt-4">
                        <a href="{{ route('admin.orders.index') }}" class="btn-get-started">
                            <i class="bi bi-list-ul"></i> All Orders
                        </a>
                        <a href="{{ route('admin.dashboard') }}" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Admin
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Key Statistics 
    <section id="order-stats" class="about section">
        <div class="container section-title" data-aos="fade-up">
            <h2>Order Statistics</h2>
            <div><span>Today's</span> <span class="description-title">Performance</span></div>
        </div>
        
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $stats['total_orders'] }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $stats['pending_orders'] }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Pending Orders</p>
                        @if($stats['pending_orders'] > 0)
                            <small class="text-warning"><i class="bi bi-exclamation-triangle"></i> Need Attention</small>
                        @endif
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $stats['todays_orders'] }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Today's Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ number_format($stats['todays_revenue'], 0) }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Today's Revenue</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    -->
    <!-- Pending Orders Alert -->
    @if($pendingOrders->count() > 0)
    <section id="pending-orders" class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-warning border-0 shadow-sm">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-exclamation-triangle-fill me-3" style="font-size: 1.5rem;"></i>
                            <div>
                                <h5 class="alert-heading mb-1">{{ $pendingOrders->count() }} Pending Orders Need Your Attention!</h5>
                                <p class="mb-0">These orders are waiting for confirmation. Please review and update their status.</p>
                            </div>
                            <a href="{{ route('admin.orders.index', ['status' => 'pending']) }}" class="btn btn-warning ms-auto">
                                <i class="bi bi-eye"></i> View Pending Orders
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif

    <!-- Quick Actions -->
    <section id="quick-actions" class="about section light-background">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-item text-center">
                        <span><i class="bi bi-hourglass-split text-warning"></i></span>
                        <h4><a href="{{ route('admin.orders.index', ['status' => 'pending']) }}" class="stretched-link">Pending Orders</a></h4>
                        <p>{{ $stats['pending_orders'] }} orders waiting for confirmation</p>
                    </div>
                </div>

                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-item text-center">
                        <span><i class="bi bi-clock text-primary"></i></span>
                        <h4><a href="{{ route('admin.orders.index', ['status' => 'preparing']) }}" class="stretched-link">Active Orders</a></h4>
                        <p>{{ $stats['active_orders'] }} orders being prepared and delivered</p>
                    </div>
                </div>

                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="card-item text-center">
                        <span><i class="bi bi-calendar-day text-info"></i></span>
                        <h4><a href="{{ route('admin.orders.index', ['date_from' => today()->format('Y-m-d'), 'date_to' => today()->format('Y-m-d')]) }}" class="stretched-link">Today's Orders</a></h4>
                        <p>{{ $stats['todays_orders'] }} orders placed today</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Recent Orders -->
    @if($recentOrders->count() > 0)
    <section id="recent-orders" class="section">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Recent Orders</h2>
                <div><span>Latest</span> <span class="description-title">Customer Orders</span></div>
            </div>

            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent Orders</h5>
                            <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-list-ul"></i> View All Orders
                            </a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Order #</th>
                                            <th>Customer</th>
                                            <th>Time</th>
                                            <th>Items</th>
                                            <th>Status</th>
                                            <th>Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($recentOrders as $order)
                                        <tr>
                                            <td><strong>{{ $order->order_number }}</strong></td>
                                            <td>
                                                <div>
                                                    {{ $order->customer_name }}<br>
                                                    <small class="text-muted">{{ $order->customer_phone }}</small>
                                                </div>
                                            </td>
                                            <td>
                                                <span title="{{ $order->created_at->format('M d, Y H:i A') }}">
                                                    {{ $order->created_at->diffForHumans() }}
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info">{{ $order->total_items }} items</span>
                                            </td>
                                            <td>
                                                <span class="badge bg-{{ $order->status_badge_color }}">
                                                    {{ $order->status_label }}
                                                </span>
                                            </td>
                                            <td><strong>{{ $order->formatted_total }}</strong></td>
                                            <td>
                                                <a href="{{ route('admin.orders.show', $order) }}" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye"></i> View
                                                </a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif

    <!-- Revenue Overview -->
    <section id="revenue-overview" class="about section">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Revenue Overview</h2>
                <div><span>Financial</span> <span class="description-title">Summary</span></div>
            </div>
            
            <div class="row gy-4">
                <div class="col-lg-4 col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ number_format($stats['todays_revenue'], 0) }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Today's Revenue</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ number_format($stats['total_revenue'] / 7, 0) }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Weekly Average</p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ number_format($stats['total_revenue'], 0) }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Revenue</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Auto-refresh for real-time updates -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh every 30 seconds for real-time updates
    setInterval(function() {
        // Only refresh if there are pending orders to avoid unnecessary requests
        if ({{ $stats['pending_orders'] }} > 0) {
            window.location.reload();
        }
    }, 30000); // 30 seconds
    
    // Sound notification for new pending orders (optional)
    @if($stats['pending_orders'] > 0)
        // You can add a notification sound here
        console.log('{{ $stats["pending_orders"] }} pending orders need attention!');
    @endif
});
</script>
@endsection