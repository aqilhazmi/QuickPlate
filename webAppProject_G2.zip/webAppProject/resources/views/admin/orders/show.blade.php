@extends('master.layout')

@section('title', 'Order Details #' . $order->order_number)

@section('content')
<main class="main">
    <!-- Header -->
    <section id="admin-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1><i class="bi bi-receipt"></i> Order {{ $order->order_number }}</h1>
                    <p>Detailed view of customer order placed on {{ $order->created_at->format('M d, Y \a\t H:i A') }}</p>
                    <div class="btns mt-4">
                        <a href="{{ route('admin.orders.index') }}" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Orders
                        </a>
                        <a href="{{ route('admin.orders.dashboard') }}" class="btn-get-started">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Order Summary Cards -->
    <section class="section">
        <div class="container">
            <div class="row gy-4">
                <!-- Order Status Card -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-info-circle" style="font-size: 2rem; color: #{{ $order->status_badge_color == 'warning' ? 'ffc107' : ($order->status_badge_color == 'success' ? '198754' : '0d6efd') }};"></i>
                            <h5 class="card-title mt-3">Order Status</h5>
                            <span class="badge bg-{{ $order->status_badge_color }} fs-6" id="current-status">
                                {{ $order->status_label }}
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Payment Status Card -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-credit-card" style="font-size: 2rem; color: #{{ $order->payment_status_badge_color == 'success' ? '198754' : 'ffc107' }};"></i>
                            <h5 class="card-title mt-3">Payment</h5>
                            <span class="badge bg-{{ $order->payment_status_badge_color }} fs-6">
                                {{ ucfirst($order->payment_status) }}
                            </span>
                            <p class="small text-muted mt-2">{{ ucfirst($order->payment_method) }}</p>
                        </div>
                    </div>
                </div>

                <!-- Total Amount Card -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-calculator" style="font-size: 2rem; color: #198754;"></i>
                            <h5 class="card-title mt-3">Total Amount</h5>
                            <h4 class="text-success">{{ $order->formatted_total }}</h4>
                            <p class="small text-muted">{{ $order->total_items }} items</p>
                        </div>
                    </div>
                </div>

                <!-- Delivery Time Card -->
                <div class="col-lg-3 col-md-6">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-clock" style="font-size: 2rem; color: #0d6efd;"></i>
                            <h5 class="card-title mt-3">Delivery Time</h5>
                            @if($order->estimated_delivery_time)
                                <p class="mb-1">{{ $order->estimated_delivery_time->format('H:i A') }}</p>
                                <small class="text-muted">{{ $order->estimated_delivery_time->format('M d, Y') }}</small>
                            @else
                                <p class="text-muted">Not set</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Order Details -->
    <section class="section">
        <div class="container">
            <div class="row">
                <!-- Customer Information -->
                <div class="col-lg-4 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-person"></i> Customer Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <strong>Name:</strong><br>
                                {{ $order->customer_name }}
                            </div>
                            <div class="mb-3">
                                <strong>Email:</strong><br>
                                <a href="mailto:{{ $order->customer_email }}">{{ $order->customer_email }}</a>
                            </div>
                            <div class="mb-3">
                                <strong>Phone:</strong><br>
                                <a href="tel:{{ $order->customer_phone }}">{{ $order->customer_phone }}</a>
                            </div>
                            @if($order->user)
                            <div class="mb-3">
                                <strong>Account:</strong><br>
                                <small class="text-success"><i class="bi bi-check-circle"></i> Registered Customer</small>
                            </div>
                            @else
                            <div class="mb-3">
                                <small class="text-muted"><i class="bi bi-person"></i> Guest Order</small>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Delivery Information -->
                <div class="col-lg-4 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-geo-alt"></i> Delivery Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <strong>Address:</strong><br>
                                {{ $order->delivery_address }}
                            </div>
                            @if($order->city || $order->state || $order->postal_code)
                            <div class="mb-3">
                                <strong>City:</strong> {{ $order->city }}<br>
                                <strong>State:</strong> {{ $order->state }}<br>
                                <strong>Postal Code:</strong> {{ $order->postal_code }}
                            </div>
                            @endif
                            @if($order->special_instructions)
                            <div class="mb-3">
                                <strong>Special Instructions:</strong><br>
                                <em>{{ $order->special_instructions }}</em>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Order Timeline -->
                <div class="col-lg-4 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Order Timeline</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <strong>Order Placed:</strong><br>
                                <small>{{ $order->created_at->format('M d, Y \a\t H:i A') }}</small><br>
                                <small class="text-muted">{{ $order->created_at->diffForHumans() }}</small>
                            </div>
                            
                            @if($order->estimated_delivery_time)
                            <div class="mb-3">
                                <strong>Estimated Delivery:</strong><br>
                                <small>{{ $order->estimated_delivery_time->format('M d, Y \a\t H:i A') }}</small>
                            </div>
                            @endif

                            @if($order->delivered_at)
                            <div class="mb-3">
                                <strong>Delivered:</strong><br>
                                <small>{{ $order->delivered_at->format('M d, Y \a\t H:i A') }}</small><br>
                                <small class="text-success"><i class="bi bi-check-circle"></i> Order completed</small>
                            </div>
                            @endif

                            @if($order->status == 'cancelled')
                            <div class="mb-3">
                                <strong>Cancelled:</strong><br>
                                <small class="text-danger">{{ $order->updated_at->format('M d, Y \a\t H:i A') }}</small>
                                @if($order->cancellation_reason)
                                <br><small class="text-muted">Reason: {{ $order->cancellation_reason }}</small>
                                @endif
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Order Items -->
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-list-ul"></i> Order Items ({{ $order->orderItems->count() }})</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Item</th>
                                            <th>Description</th>
                                            <th>Category</th>
                                            <th>Unit Price</th>
                                            <th>Quantity</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($order->orderItems as $item)
                                        <tr>
                                            <td>
                                                <strong>{{ $item->food_name }}</strong>
                                                @if($item->special_notes)
                                                <br><small class="text-muted"><em>Note: {{ $item->special_notes }}</em></small>
                                                @endif
                                            </td>
                                            <td>
                                                <small>{{ Str::limit($item->food_description, 100) }}</small>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary">{{ ucfirst($item->food_category) }}</span>
                                            </td>
                                            <td>{{ $item->formatted_unit_price }}</td>
                                            <td>
                                                <span class="badge bg-info">{{ $item->quantity }}</span>
                                            </td>
                                            <td><strong>{{ $item->formatted_subtotal }}</strong></td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Order Summary & Status Update -->
    <section class="section">
        <div class="container">
            <div class="row">
                <!-- Order Summary -->
                <div class="col-lg-6">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-calculator"></i> Order Summary</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col">Subtotal:</div>
                                <div class="col-auto">{{ $order->formatted_subtotal }}</div>
                            </div>
                            <div class="row mb-2">
                                <div class="col">Delivery Fee:</div>
                                <div class="col-auto">{{ $order->formatted_delivery_fee }}</div>
                            </div>
                            <div class="row mb-2">
                                <div class="col">Service Tax:</div>
                                <div class="col-auto">{{ $order->formatted_service_tax }}</div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Amount:</strong></div>
                                <div class="col-auto"><strong>{{ $order->formatted_total }}</strong></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Status Update -->
                <div class="col-lg-6">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-arrow-repeat"></i> Update Order Status</h5>
                        </div>
                        <div class="card-body">
                            @if($order->isActive())
                                <form id="status-update-form">
                                    @csrf
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Change Status To:</label>
                                        <select name="status" id="status" class="form-select">
                                            <option value="">Select new status...</option>
                                            @if($order->status == 'pending')
                                                <option value="confirmed">Confirm Order</option>
                                                <option value="preparing">Start Preparing</option>
                                                <option value="cancelled">Cancel Order</option>
                                            @elseif($order->status == 'confirmed')
                                                <option value="preparing">Start Preparing</option>
                                                <option value="cancelled">Cancel Order</option>
                                            @elseif($order->status == 'preparing')
                                                <option value="out_for_delivery">Out for Delivery</option>
                                                <option value="delivered">Mark as Delivered</option>
                                            @elseif($order->status == 'out_for_delivery')
                                                <option value="delivered">Mark as Delivered</option>
                                            @endif
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="notes" class="form-label">Notes (Optional):</label>
                                        <textarea name="notes" id="notes" class="form-control" rows="3" placeholder="Add any notes about this status change..."></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-check-circle"></i> Update Status
                                    </button>
                                </form>
                            @else
                                <div class="text-center py-4">
                                    @if($order->status == 'delivered')
                                        <i class="bi bi-check-circle text-success" style="font-size: 3rem;"></i>
                                        <h5 class="mt-3 text-success">Order Completed</h5>
                                        <p class="text-muted">This order has been successfully delivered.</p>
                                    @elseif($order->status == 'cancelled')
                                        <i class="bi bi-x-circle text-danger" style="font-size: 3rem;"></i>
                                        <h5 class="mt-3 text-danger">Order Cancelled</h5>
                                        <p class="text-muted">This order has been cancelled.</p>
                                    @endif
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Status Update JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const statusForm = document.getElementById('status-update-form');
    
    if (statusForm) {
        statusForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const statusSelect = document.getElementById('status');
            const newStatus = statusSelect.value;
            
            if (!newStatus) {
                alert('Please select a status to update to.');
                return;
            }
            
            if (confirm(`Are you sure you want to change this order status to "${newStatus.replace('_', ' ')}"?`)) {
                const submitButton = this.querySelector('button[type="submit"]');
                const originalText = submitButton.innerHTML;
                
                // Show loading
                submitButton.innerHTML = '<i class="bi bi-hourglass-split"></i> Updating...';
                submitButton.disabled = true;
                
                fetch(`/admin/orders/{{ $order->id }}/status`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update the status badge
                        const statusBadge = document.getElementById('current-status');
                        statusBadge.textContent = data.status_label;
                        statusBadge.className = `badge bg-${data.badge_color} fs-6`;
                        
                        // Show success message
                        showNotification(data.message, 'success');
                        
                        // Refresh page after 1 second to show updated form
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        submitButton.innerHTML = originalText;
                        submitButton.disabled = false;
                        showNotification(data.message || 'Error updating status', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                    showNotification('Network error. Please try again.', 'error');
                });
            }
        });
    }
    
    function showNotification(message, type) {
        const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        const notification = document.createElement('div');
        notification.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
});
</script>
@endsection















































