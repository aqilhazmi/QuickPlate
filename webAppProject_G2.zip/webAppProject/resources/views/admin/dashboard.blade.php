@extends('master.layout')

@section('title', 'Admin Dashboard')

@section('content')
<main class="main">
    <!-- Admin Header -->
    <section id="admin-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Admin Dashboard</h1>
                    <p>Manage your QuickPlate restaurant operations</p>
                    <div class="btns mt-4">
                        <a href="{{ route('admin.food-items.index') }}" class="btn-get-started">
                            <i class="bi bi-grid-3x3-gap"></i> Manage Menu
                        </a>
                        <a href="{{ route('admin.orders.index') }}" class="btn-get-started">
                            <i class="bi bi-list-ul"></i> View Orders
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Admin Statistics 
    <section id="admin-stats" class="about section">
        <div class="container section-title" data-aos="fade-up">
            <h2>Restaurant Overview</h2>
            <div><span>Business</span> <span class="description-title">Statistics</span></div>
        </div>
        
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $totalFoodItems ?? 0 }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Menu Items</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $totalOrders ?? 0 }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Orders</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="stats-item text-center w-100 h-100">
                        <span data-purecounter-start="0" data-purecounter-end="{{ $totalUsers ?? 0 }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Customers</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="stats-item text-center w-100 h-100">
                        <span class="purecounter">RM</span>
                        <span data-purecounter-start="0" data-purecounter-end="{{ $totalRevenue ?? 0 }}" data-purecounter-duration="1" class="purecounter"></span>
                        <p>Total Revenue</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    -->

    <!-- Quick Actions -->
    <section id="admin-actions" class="about section light-background">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-item text-center">
                        <span><i class="bi bi-plus-circle"></i></span>
                        <h4><a href="{{ route('admin.food-items.create') }}" class="stretched-link">Add Menu Item</a></h4>
                        <p>Add new delicious items to your menu for customers to order.</p>
                    </div>
                </div>

                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-item text-center">
                        <span><i class="bi bi-list-ul"></i></span>
                        <h4><a href="{{ route('admin.orders.index') }}" class="stretched-link">Manage Orders</a></h4>
                        <p>View and update the status of customer orders.</p>
                    </div>
                </div>

                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="card-item text-center">
                        <span><i class="bi bi-grid-3x3-gap"></i></span>
                        <h4><a href="{{ route('admin.food-items.index') }}" class="stretched-link">View Menu</a></h4>
                        <p>See all menu items and edit them as needed.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Recent Activity (if any data exists) -->
    @if(isset($recentOrders) && $recentOrders->count() > 0)
    <section id="recent-activity" class="section">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Recent Orders</h2>
                <div><span>Latest</span> <span class="description-title">Customer Orders</span></div>
            </div>

            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent Orders</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Order #</th>
                                            <th>Customer</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($recentOrders as $order)
                                        <tr>
                                            <td><strong>#{{ $order->id }}</strong></td>
                                            <td>{{ $order->user->name ?? 'Guest' }}</td>
                                            <td>{{ $order->created_at->format('M d, Y H:i') }}</td>
                                            <td>
                                                <span class="badge bg-{{ $order->status == 'pending' ? 'warning' : ($order->status == 'delivered' ? 'success' : 'primary') }}">
                                                    {{ ucfirst($order->status) }}
                                                </span>
                                            </td>
                                            <td><strong>RM {{ number_format($order->total_amount, 2) }}</strong></td>
                                            <td>
                                                <a href="#" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye"></i> View
                                                </a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif
</main>
@endsection