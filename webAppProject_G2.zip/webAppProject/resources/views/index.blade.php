@extends('layouts.app')

@section('title', 'Menu - QuickPlate')

@section('content')
<div class="container py-5" style="margin-top: 80px;">
    <div class="row">
        <div class="col-12 text-center mb-4">
            <h1>MENU</h1>
            <p class="text-muted">Discover our delicious halal food options</p>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-center mb-3">
                <div class="btn-group category-filters" role="group">
                    <a href="{{ route('menu.index') }}" 
                       class="btn {{ !request('category') || request('category') == 'all' ? 'btn-primary' : 'btn-outline-primary' }}">
                        All
                    </a>
                    @foreach($categories as $category)
                        <a href="{{ route('menu.index', ['category' => $category]) }}" 
                           class="btn {{ request('category') == $category ? 'btn-primary' : 'btn-outline-primary' }}">
                            {{ ucfirst($category) }}
                        </a>
                    @endforeach
                </div>
            </div>
            
            <!-- Search Form -->
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form action="{{ route('menu.index') }}" method="GET" class="d-flex">
                        <input type="hidden" name="category" value="{{ request('category') }}">
                        <input type="text" name="search" class="form-control me-2" 
                               placeholder="Search food items..." value="{{ request('search') }}">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Food Items Grid -->
    <div class="row">
        @forelse($foodItems as $item)
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card food-card h-100 shadow-sm">
                    <img src="{{ $item->image_url }}" class="card-img-top" alt="{{ $item->name }}" 
                         style="height: 250px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">{{ $item->name }}</h5>
                        <p class="card-text flex-grow-1 text-muted">{{ $item->description }}</p>
                        <div class="d-flex justify-content-between align-items-center mt-auto">
                            <span class="price h5 text-primary mb-0">RM{{ number_format($item->price, 2) }}</span>
                            @auth
                                @if($item->is_available)
                                    <button class="btn btn-primary add-to-cart" data-food-id="{{ $item->id }}">
                                        <i class="fas fa-plus"></i> Add to Cart
                                    </button>
                                @else
                                    <span class="badge bg-secondary">Out of Stock</span>
                                @endif
                            @else
                                <a href="{{ route('login') }}" class="btn btn-outline-primary">Login to Order</a>
                            @endauth
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12 text-center py-5">
                <h4>No food items found</h4>
                <p class="text-muted">Try adjusting your search or filter criteria</p>
                <a href="{{ route('menu.index') }}" class="btn btn-primary">View All Items</a>
            </div>
        @endforelse
    </div>

    <!-- Pagination -->
    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            {{ $foodItems->appends(request()->query())->links() }}
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    $('.add-to-cart').click(function() {
        const button = $(this);
        const foodId = button.data('food-id');
        
        button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Adding...');
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
        $.post(`/cart/add/${foodId}`, {
            quantity: 1
        }).done(function(response) {
            if (response.success) {
                $('#cart-count').text(response.cartCount);
                button.html('<i class="fas fa-check"></i> Added!').removeClass('btn-primary').addClass('btn-success');
                
                setTimeout(function() {
                    button.html('<i class="fas fa-plus"></i> Add to Cart').removeClass('btn-success').addClass('btn-primary');
                }, 2000);
            }
        }).fail(function() {
            alert('Error adding item to cart. Please try again.');
        }).always(function() {
            button.prop('disabled', false);
        });
    });
});
</script>
@endpush

{{-- resources/views/cart/index.blade.php --}}
@extends('layouts.app')

@section('title', 'Shopping Cart - QuickPlate')

@section('content')
<div class="container py-5" style="margin-top: 80px;">
    <div class="row">
        <div class="col-12">
            <h2><i class="fas fa-shopping-cart me-2"></i>Shopping Cart</h2>
            <hr>
        </div>
    </div>

    @if($cartItems->count() > 0)
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        @foreach($cartItems as $item)
                            <div class="cart-item row align-items-center py-3 border-bottom" data-cart-item-id="{{ $item->id }}">
                                <div class="col-md-2">
                                    <img src="{{ $item->foodItem->image_url }}" 
                                         class="img-fluid rounded" alt="{{ $item->foodItem->name }}"
                                         style="height: 80px; width: 80px; object-fit: cover;">
                                </div>
                                <div class="col-md-4">
                                    <h6 class="mb-1">{{ $item->foodItem->name }}</h6>
                                    <p class="text-muted small mb-0">{{ Str::limit($item->foodItem->description, 60) }}</p>
                                </div>
                                <div class="col-md-2 text-center">
                                    <span class="fw-bold">RM{{ number_format($item->foodItem->price, 2) }}</span>
                                </div>
                                <div class="col-md-3 text-center">
                                    <div class="quantity-controls d-flex align-items-center justify-content-center">
                                        <button class="btn btn-outline-secondary btn-sm quantity-btn" 
                                                data-action="decrease" data-cart-item-id="{{ $item->id }}">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        <span class="mx-3 quantity-display">{{ $item->quantity }}</span>
                                        <button class="btn btn-outline-secondary btn-sm quantity-btn" 
                                                data-action="increase" data-cart-item-id="{{ $item->id }}">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-md-1 text-center">
                                    <button class="btn btn-outline-danger btn-sm remove-item" 
                                            data-cart-item-id="{{ $item->id }}">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                
                <div class="mt-3">
                    <a href="{{ route('menu.index') }}" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                    </a>
                    <button class="btn btn-outline-danger ms-2" id="clear-cart">
                        <i class="fas fa-trash me-2"></i>Clear Cart
                    </button>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Items ({{ $cart->getTotalItems() }})</span>
                            <span id="cart-subtotal">RM{{ number_format($cart->getTotalAmount(), 2) }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Delivery Fee</span>
                            <span>RM5.00</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <strong>Total</strong>
                            <strong id="cart-total">RM{{ number_format($cart->getTotalAmount() + 5, 2) }}</strong>
                        </div>
                        
                        <a href="{{ route('orders.checkout') }}" class="btn btn-primary w-100">
                            Proceed to Payment
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @else
        <div class="row">
            <div class="col-12 text-center py-5">
                <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                <h4>Your cart is empty</h4>
                <p class="text-muted">Add some delicious food items to get started!</p>
                <a href="{{ route('menu.index') }}" class="btn btn-primary">
                    <i class="fas fa-utensils me-2"></i>Browse Menu
                </a>
            </div>
        </div>
    @endif
</div>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Quantity controls
    $('.quantity-btn').click(function() {
        const action = $(this).data('action');
        const cartItemId = $(this).data('cart-item-id');
        const quantityDisplay = $(this).closest('.quantity-controls').find('.quantity-display');
        let currentQuantity = parseInt(quantityDisplay.text());
        
        if (action === 'decrease' && currentQuantity <= 1) {
            return; // Don't allow quantity below 1
        }
        
        const newQuantity = action === 'increase' ? currentQuantity + 1 : currentQuantity - 1;
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
        $.ajax({
            url: `/cart/update/${cartItemId}`,
            method: 'PATCH',
            data: { quantity: newQuantity }
        }).done(function(response) {
            if (response.success) {
                quantityDisplay.text(newQuantity);
                $('#cart-subtotal').text('RM' + parseFloat(response.total).toFixed(2));
                $('#cart-total').text('RM' + (parseFloat(response.total) + 5).toFixed(2));
                $('#cart-count').text(newQuantity); // Update header cart count
            }
        }).fail(function() {
            alert('Error updating cart. Please try again.');
        });
    });
    
    // Remove item
    $('.remove-item').click(function() {
        if (!confirm('Are you sure you want to remove this item?')) {
            return;
        }
        
        const cartItemId = $(this).data('cart-item-id');
        const cartItemRow = $(this).closest('.cart-item');
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
        $.ajax({
            url: `/cart/remove/${cartItemId}`,
            method: 'DELETE'
        }).done(function(response) {
            if (response.success) {
                cartItemRow.fadeOut(300, function() {
                    $(this).remove();
                    
                    // Update totals
                    $('#cart-subtotal').text('RM' + parseFloat(response.total).toFixed(2));
                    $('#cart-total').text('RM' + (parseFloat(response.total) + 5).toFixed(2));
                    $('#cart-count').text(response.cartCount);
                    
                    // If cart is empty, reload page to show empty state
                    if (response.cartCount === 0) {
                        location.reload();
                    }
                });
            }
        }).fail(function() {
            alert('Error removing item. Please try again.');
        });
    });
    
    // Clear cart
    $('#clear-cart').click(function() {
        if (!confirm('Are you sure you want to clear your cart?')) {
            return;
        }
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
        $.ajax({
            url: '/cart/clear',
            method: 'DELETE'
        }).done(function() {
            location.reload();
        }).fail(function() {
            alert('Error clearing cart. Please try again.');
        });
    });
});
</script>
@endpush

{{-- resources/views/orders/checkout.blade.php --}}
@extends('layouts.app')

@section('title', 'Checkout - QuickPlate')

@section('content')
<div class="container py-5" style="margin-top: 80px;">
    <div class="row">
        <div class="col-12">
            <h2><i class="fas fa-credit-card me-2"></i>Checkout</h2>
            <hr>
        </div>
    </div>

    <form action="{{ route('orders.store') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-lg-8">
                <!-- Contact Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Contact Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" class="form-control" value="{{ Auth::user()->email }}" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Phone Number *</label>
                                    <input type="tel" name="phone_number" class="form-control @error('phone_number') is-invalid @enderror" 
                                           value="{{ old('phone_number', Auth::user()->phone) }}" required>
                                    @error('phone_number')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Billing & Shipping -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Delivery Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" value="{{ Auth::user()->name }}" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Delivery Address *</label>
                            <textarea name="delivery_address" class="form-control @error('delivery_address') is-invalid @enderror" 
                                      rows="3" required>{{ old('delivery_address', Auth::user()->address) }}</textarea>
                            @error('delivery_address')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">ZIP Code</label>
                                    <input type="text" class="form-control" placeholder="12345">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">City</label>
                                    <input type="text" class="form-control" placeholder="Kuala Lumpur">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Payment Method -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Payment Method</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="radio" name="payment_method" value="cod" id="cod" checked>
                            <label class="form-check-label" for="cod">
                                <i class="fas fa-money-bill-wave me-2"></i>Cash on Delivery
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" value="online" id="online">
                            <label class="form-check-label" for="online">
                                <i class="fas fa-credit-card me-2"></i>Online Payment (Coming Soon)
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <!-- Order Summary -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Order Summary</h5>
                        <small class="text-muted">Order #{{ rand(1000, 9999) }}</small>
                    </div>
                    <div class="card-body">
                        @foreach($cartItems as $item)
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="d-flex align-items-center">
                                    <img src="{{ $item->foodItem->image_url }}" 
                                         class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                    <div>
                                        <small class="fw-bold">{{ $item->foodItem->name }}</small><br>
                                        <small class="text-muted">Qty: {{ $item->quantity }}</small>
                                    </div>
                                </div>
                                <span class="fw-bold">RM{{ number_format($item->getSubtotal(), 2) }}</span>
                            </div>
                        @endforeach
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal ({{ $cart->getTotalItems() }} items)</span>
                            <span>RM{{ number_format($cart->getTotalAmount(), 2) }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Delivery Fee</span>
                            <span>RM5.00</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <strong>Total</strong>
                            <strong>RM{{ number_format($cart->getTotalAmount() + 5, 2) }}</strong>
                        </div>
                        
                        <button type="submit" class="btn btn-success w-100 mb-2">
                            <i class="fas fa-check me-2"></i>Place Order
                        </button>
                        
                        <a href="{{ route('cart.index') }}" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-arrow-left me-2"></i>Back to Cart
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection