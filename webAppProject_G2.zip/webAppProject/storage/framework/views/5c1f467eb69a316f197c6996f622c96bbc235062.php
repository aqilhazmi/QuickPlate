

<?php $__env->startSection('title', 'Order Details'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Order Header -->
    <section id="order-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Order <?php echo e($order->order_number); ?></h1>
                    <p><?php echo e($order->status_label); ?> • Placed on <?php echo e($order->created_at->format('M d, Y \a\t g:i A')); ?></p>
                    <div class="btns mt-4">
                        <a href="<?php echo e(route('orders.index')); ?>" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Orders
                        </a>
                        <?php if($order->isActive()): ?>
                            <a href="<?php echo e(route('checkout.track', $order->order_number)); ?>" class="btn-get-started">
                                <i class="bi bi-geo-alt"></i> Track Order
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Order Details -->
    <section id="order-details" class="section">
        <div class="container">
            
            <!-- Order Status Timeline -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="bi bi-clock-history"></i> Order Status</h5>
                </div>
                <div class="card-body">
                    <div class="order-timeline">
                        <div class="row text-center">
                            <div class="col-md-2">
                                <div class="timeline-step <?php echo e(in_array($order->status, ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered']) ? 'completed' : 'pending'); ?>">
                                    <i class="bi bi-check-circle"></i>
                                    <h6>Order Placed</h6>
                                    <small><?php echo e($order->created_at->format('g:i A')); ?></small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="timeline-step <?php echo e(in_array($order->status, ['confirmed', 'preparing', 'out_for_delivery', 'delivered']) ? 'completed' : ($order->status == 'pending' ? 'active' : 'pending')); ?>">
                                    <i class="bi bi-clipboard-check"></i>
                                    <h6>Confirmed</h6>
                                    <small><?php echo e($order->status == 'confirmed' ? 'Confirmed' : ($order->status == 'pending' ? 'Pending' : '')); ?></small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="timeline-step <?php echo e(in_array($order->status, ['preparing', 'out_for_delivery', 'delivered']) ? 'completed' : ($order->status == 'confirmed' ? 'active' : 'pending')); ?>">
                                    <i class="bi bi-fire"></i>
                                    <h6>Preparing</h6>
                                    <small><?php echo e($order->status == 'preparing' ? 'In Progress' : ''); ?></small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="timeline-step <?php echo e(in_array($order->status, ['out_for_delivery', 'delivered']) ? 'completed' : ($order->status == 'preparing' ? 'active' : 'pending')); ?>">
                                    <i class="bi bi-truck"></i>
                                    <h6>Out for Delivery</h6>
                                    <small><?php echo e($order->status == 'out_for_delivery' ? 'On the way' : ''); ?></small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="timeline-step <?php echo e($order->status == 'delivered' ? 'completed' : ($order->status == 'out_for_delivery' ? 'active' : 'pending')); ?>">
                                    <i class="bi bi-house-check"></i>
                                    <h6>Delivered</h6>
                                    <small><?php echo e($order->delivered_at ? $order->delivered_at->format('g:i A') : ''); ?></small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="timeline-step <?php echo e($order->isCompleted() ? 'completed' : 'pending'); ?>">
                                    <i class="bi bi-star"></i>
                                    <h6>Rate & Review</h6>
                                    <small><?php echo e($order->isCompleted() ? 'Complete' : ''); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Current Status -->
                    <div class="current-status mt-4 p-3 bg-light rounded">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h6 class="mb-1">Current Status: <span class="badge bg-<?php echo e($order->status_badge_color); ?>"><?php echo e($order->status_label); ?></span></h6>
                                <?php if($order->estimated_delivery_time && $order->isActive()): ?>
                                    <p class="mb-0 text-muted">Estimated delivery: <?php echo e($order->estimated_delivery_time->format('g:i A')); ?></p>
                                <?php endif; ?>
                                <?php if($order->delivered_at): ?>
                                    <p class="mb-0 text-success">Delivered on <?php echo e($order->delivered_at->format('M d, Y \a\t g:i A')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <?php if($order->canBeCancelled()): ?>
                                    <button type="button" 
                                            class="btn btn-outline-danger" 
                                            onclick="cancelOrder(<?php echo e($order->id); ?>, '<?php echo e($order->order_number); ?>')">
                                        <i class="bi bi-x-circle"></i> Cancel Order
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Order Items -->
                <div class="col-lg-8">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-basket"></i> Order Items (<?php echo e($order->total_items); ?>)</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-borderless mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Item</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th class="text-end">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center py-2">
                                                    <?php if($item->foodItem && $item->foodItem->image): ?>
                                                        <img src="<?php echo e($item->foodItem->image_url); ?>" 
                                                             alt="<?php echo e($item->food_name); ?>" 
                                                             class="rounded me-3"
                                                             style="width: 60px; height: 60px; object-fit: cover;">
                                                    <?php else: ?>
                                                        <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center"
                                                             style="width: 60px; height: 60px;">
                                                            <i class="bi bi-image text-muted"></i>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div>
                                                        <h6 class="mb-1"><?php echo e($item->food_name); ?></h6>
                                                        <small class="text-muted"><?php echo e(ucfirst($item->food_category)); ?></small>
                                                        <?php if($item->food_description): ?>
                                                            <p class="mb-0 small text-muted"><?php echo e(Str::limit($item->food_description, 80)); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="align-middle"><?php echo e($item->formatted_unit_price); ?></td>
                                            <td class="align-middle"><?php echo e($item->quantity); ?></td>
                                            <td class="align-middle text-end"><strong><?php echo e($item->formatted_subtotal); ?></strong></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Special Instructions -->
                    <?php if($order->special_instructions): ?>
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-chat-text"></i> Special Instructions</h5>
                        </div>
                        <div class="card-body">
                            <p class="mb-0"><?php echo e($order->special_instructions); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Order Summary & Info -->
                <div class="col-lg-4">
                    <!-- Order Summary -->
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-receipt"></i> Order Summary</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal:</span>
                                <span><?php echo e($order->formatted_subtotal); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Delivery Fee:</span>
                                <span><?php echo e($order->formatted_delivery_fee); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Service Tax (6%):</span>
                                <span><?php echo e($order->formatted_service_tax); ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-3">
                                <strong>Total:</strong>
                                <strong class="text-primary h5"><?php echo e($order->formatted_total); ?></strong>
                            </div>
                            <div class="text-center">
                                <span class="badge bg-<?php echo e($order->payment_status_badge_color); ?> fs-6">
                                    Payment <?php echo e(ucfirst($order->payment_status)); ?>

                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Delivery Information -->
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-truck"></i> Delivery Details</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Customer:</strong> <?php echo e($order->customer_name); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($order->customer_phone); ?></p>
                            <p><strong>Email:</strong> <?php echo e($order->customer_email); ?></p>
                            <p><strong>Address:</strong><br>
                                <?php echo e($order->delivery_address); ?><br>
                                <?php if($order->postal_code): ?><?php echo e($order->postal_code); ?> <?php endif; ?><?php echo e($order->city); ?>, <?php echo e($order->state); ?>

                            </p>
                            <p><strong>Payment Method:</strong><br><?php echo e(ucwords(str_replace('_', ' ', $order->payment_method))); ?></p>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="card shadow-sm">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-gear"></i> Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <?php if($order->isActive()): ?>
                                    <a href="<?php echo e(route('checkout.track', $order->order_number)); ?>" class="btn btn-primary">
                                        <i class="bi bi-geo-alt"></i> Track Order
                                    </a>
                                <?php endif; ?>
                                
                                <a href="<?php echo e(route('menu')); ?>" class="btn btn-outline-primary">
                                    <i class="bi bi-grid-3x3-gap"></i> Order More
                                </a>
                                
                                <?php if($order->isCompleted()): ?>
                                    <button type="button" class="btn btn-outline-success">
                                        <i class="bi bi-star"></i> Rate & Review
                                    </button>
                                <?php endif; ?>
                                
                                <button type="button" class="btn btn-outline-secondary" onclick="window.print()">
                                    <i class="bi bi-printer"></i> Print Order
                                </button>
                                
                                <?php if($order->canBeCancelled()): ?>
                                    <button type="button" 
                                            class="btn btn-outline-danger" 
                                            onclick="cancelOrder(<?php echo e($order->id); ?>, '<?php echo e($order->order_number); ?>')">
                                        <i class="bi bi-x-circle"></i> Cancel Order
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Support -->
                    <div class="card shadow-sm mt-4">
                        <div class="card-body text-center">
                            <h6><i class="bi bi-headset"></i> Need Help?</h6>
                            <p class="small text-muted">Contact our support team for any questions about your order.</p>
                            <a href="tel:+60113118119" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-telephone"></i> Call Support
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
</main>

<!-- Cancel Order Modal -->
<div class="modal fade" id="cancelOrderModal" tabindex="-1" aria-labelledby="cancelOrderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cancelOrderModalLabel">Cancel Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to cancel order <strong id="cancelOrderNumber"></strong>?</p>
                <div class="form-group">
                    <label for="cancellation_reason" class="form-label">Reason for cancellation (optional):</label>
                    <textarea class="form-control" id="cancellation_reason" rows="3" placeholder="Please let us know why you're cancelling this order..."></textarea>
                </div>
                <p class="text-muted small mt-2">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keep Order</button>
                <form id="cancelOrderForm" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="cancellation_reason" id="hidden_cancellation_reason">
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-x-circle"></i> Cancel Order
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function cancelOrder(orderId, orderNumber) {
    const modal = new bootstrap.Modal(document.getElementById('cancelOrderModal'));
    const form = document.getElementById('cancelOrderForm');
    const orderNumberElement = document.getElementById('cancelOrderNumber');
    const reasonTextarea = document.getElementById('cancellation_reason');
    const hiddenReasonInput = document.getElementById('hidden_cancellation_reason');
    
    // Set the order number in modal
    orderNumberElement.textContent = orderNumber;
    
    // Set the form action URL
    form.action = `/orders/${orderId}/cancel`;
    
    // Update hidden input when textarea changes
    reasonTextarea.addEventListener('input', function() {
        hiddenReasonInput.value = this.value;
    });
    
    // Show the modal
    modal.show();
}

// Auto-refresh every 30 seconds for active orders
<?php if($order->isActive()): ?>
setTimeout(() => {
    location.reload();
}, 30000);
<?php endif; ?>
</script>
<?php $__env->stopPush(); ?>

<style>
.timeline-step {
    padding: 20px 10px;
    text-align: center;
    position: relative;
}

.timeline-step i {
    font-size: 2rem;
    margin-bottom: 10px;
    color: #ccc;
}

.timeline-step.completed i {
    color: #28a745;
}

.timeline-step.active i {
    color: #007bff;
    animation: pulse 2s infinite;
}

.timeline-step h6 {
    font-size: 0.9rem;
    margin-bottom: 5px;
    color: #333;
}

.timeline-step small {
    color: #6c757d;
    font-size: 0.75rem;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

@media print {
    .btn, .modal, .hero { display: none !important; }
    .card { border: 1px solid #000 !important; }
}
</style>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/orders/show.blade.php ENDPATH**/ ?>