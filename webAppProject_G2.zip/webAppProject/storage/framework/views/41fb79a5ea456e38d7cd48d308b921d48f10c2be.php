

<?php $__env->startSection('title', 'Manage Orders'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Header -->
    <section id="admin-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1><i class="bi bi-list-ul"></i> Order Management</h1>
                    <p>Manage and track all customer orders</p>
                    <div class="btns mt-4">
                        <a href="<?php echo e(route('admin.orders.dashboard')); ?>" class="btn-get-started">
                            <i class="bi bi-speedometer2"></i> Orders Dashboard
                        </a>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Admin
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Filters & Search -->
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-funnel"></i> Filter Orders</h5>
                        </div>
                        <div class="card-body">
                            <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <label class="form-label">Search</label>
                                        <input type="text" name="search" class="form-control" 
                                               placeholder="Order ID, Customer Name, Phone..." 
                                               value="<?php echo e(request('search')); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">Status</label>
                                        <select name="status" class="form-select">
                                            <option value="">All Status</option>
                                            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                            <option value="confirmed" <?php echo e(request('status') == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                                            <option value="preparing" <?php echo e(request('status') == 'preparing' ? 'selected' : ''); ?>>Preparing</option>
                                            <option value="out_for_delivery" <?php echo e(request('status') == 'out_for_delivery' ? 'selected' : ''); ?>>Out for Delivery</option>
                                            <option value="delivered" <?php echo e(request('status') == 'delivered' ? 'selected' : ''); ?>>Delivered</option>
                                            <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">Payment</label>
                                        <select name="payment_status" class="form-select">
                                            <option value="">All Payment</option>
                                            <option value="pending" <?php echo e(request('payment_status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                            <option value="paid" <?php echo e(request('payment_status') == 'paid' ? 'selected' : ''); ?>>Paid</option>
                                            <option value="failed" <?php echo e(request('payment_status') == 'failed' ? 'selected' : ''); ?>>Failed</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">From Date</label>
                                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">To Date</label>
                                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                                    </div>
                                    <div class="col-md-1">
                                        <label class="form-label">&nbsp;</label>
                                        <button type="submit" class="btn btn-primary w-100">
                                            <i class="bi bi-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Orders Table -->
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="bi bi-list-ul"></i> All Orders (<?php echo e($orders->total()); ?>)</h5>
                            <a href="<?php echo e(route('admin.orders.dashboard')); ?>" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                        </div>
                        <div class="card-body p-0">
                            <?php if($orders->count() > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Order #</th>
                                                <th>Customer</th>
                                                <th>Date & Time</th>
                                                <th>Items</th>
                                                <th>Status</th>
                                                <th>Payment</th>
                                                <th>Total</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo e($order->order_number); ?></strong>
                                                </td>
                                                <td>
                                                    <div>
                                                        <strong><?php echo e($order->customer_name); ?></strong><br>
                                                        <small class="text-muted"><?php echo e($order->customer_phone); ?></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div>
                                                        <?php echo e($order->created_at->format('M d, Y')); ?><br>
                                                        <small class="text-muted"><?php echo e($order->created_at->format('H:i A')); ?></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="badge bg-info"><?php echo e($order->total_items); ?> items</span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo e($order->status_badge_color); ?>" id="status-badge-<?php echo e($order->id); ?>">
                                                        <?php echo e($order->status_label); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo e($order->payment_status_badge_color); ?>">
                                                        <?php echo e(ucfirst($order->payment_status)); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <strong><?php echo e($order->formatted_total); ?></strong>
                                                </td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="<?php echo e(route('admin.orders.show', $order)); ?>" 
                                                           class="btn btn-sm btn-outline-primary"
                                                           title="View Details">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                        
                                                        <?php if($order->isActive()): ?>
                                                        <div class="dropdown">
                                                            <button class="btn btn-sm btn-outline-success dropdown-toggle" 
                                                                    type="button" 
                                                                    data-bs-toggle="dropdown">
                                                                <i class="bi bi-arrow-repeat"></i>
                                                            </button>
                                                            <ul class="dropdown-menu">
                                                                <?php if($order->status == 'pending'): ?>
                                                                    <li><a class="dropdown-item update-status" 
                                                                           href="#" 
                                                                           data-order-id="<?php echo e($order->id); ?>" 
                                                                           data-status="confirmed">
                                                                        <i class="bi bi-check-circle text-info"></i> Confirm Order
                                                                    </a></li>
                                                                <?php endif; ?>
                                                                
                                                                <?php if(in_array($order->status, ['pending', 'confirmed'])): ?>
                                                                    <li><a class="dropdown-item update-status" 
                                                                           href="#" 
                                                                           data-order-id="<?php echo e($order->id); ?>" 
                                                                           data-status="preparing">
                                                                        <i class="bi bi-clock text-primary"></i> Start Preparing
                                                                    </a></li>
                                                                <?php endif; ?>
                                                                
                                                                <?php if($order->status == 'preparing'): ?>
                                                                    <li><a class="dropdown-item update-status" 
                                                                           href="#" 
                                                                           data-order-id="<?php echo e($order->id); ?>" 
                                                                           data-status="out_for_delivery">
                                                                        <i class="bi bi-truck text-warning"></i> Out for Delivery
                                                                    </a></li>
                                                                <?php endif; ?>
                                                                
                                                                <?php if($order->status == 'out_for_delivery'): ?>
                                                                    <li><a class="dropdown-item update-status" 
                                                                           href="#" 
                                                                           data-order-id="<?php echo e($order->id); ?>" 
                                                                           data-status="delivered">
                                                                        <i class="bi bi-check-circle text-success"></i> Mark Delivered
                                                                    </a></li>
                                                                <?php endif; ?>
                                                                
                                                                <?php if($order->canBeCancelled()): ?>
                                                                    <li><hr class="dropdown-divider"></li>
                                                                    <li><a class="dropdown-item update-status" 
                                                                           href="#" 
                                                                           data-order-id="<?php echo e($order->id); ?>" 
                                                                           data-status="cancelled">
                                                                        <i class="bi bi-x-circle text-danger"></i> Cancel Order
                                                                    </a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <!-- Pagination -->
                                <div class="card-footer">
                                    <?php echo e($orders->links()); ?>

                                </div>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <i class="bi bi-inbox" style="font-size: 3rem; color: #ccc;"></i>
                                    <h4 class="mt-3">No Orders Found</h4>
                                    <p class="text-muted">No orders match your current filters.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Status Update JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle status updates via AJAX
    document.querySelectorAll('.update-status').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const orderId = this.dataset.orderId;
            const newStatus = this.dataset.status;
            const buttonText = this.innerHTML;
            
            if (confirm(`Are you sure you want to change this order status to "${newStatus.replace('_', ' ')}"?`)) {
                // Show loading
                this.innerHTML = '<i class="bi bi-hourglass-split"></i> Updating...';
                
                fetch(`/admin/orders/${orderId}/status`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        status: newStatus
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update the status badge
                        const statusBadge = document.getElementById(`status-badge-${orderId}`);
                        statusBadge.textContent = data.status_label;
                        statusBadge.className = `badge bg-${data.badge_color}`;
                        
                        // Show success message
                        showNotification(data.message, 'success');
                        
                        // Refresh page after 1 second to show updated actions
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        this.innerHTML = buttonText;
                        showNotification(data.message || 'Error updating status', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    this.innerHTML = buttonText;
                    showNotification('Network error. Please try again.', 'error');
                });
            }
        });
    });
    
    function showNotification(message, type) {
        // Simple notification - you can replace with a better notification system
        const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        const notification = document.createElement('div');
        notification.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>