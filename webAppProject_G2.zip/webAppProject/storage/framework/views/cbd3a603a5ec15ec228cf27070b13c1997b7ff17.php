<?php $__env->startSection('title', 'Login - QuickPlate'); ?>
<?php $__env->startSection('subtitle', 'Welcome Back to Our Halal Kitchen!'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    
    <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <input type="email" 
               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               id="email"
               name="email" 
               value="<?php echo e(old('email')); ?>" 
               placeholder="Enter your email address" 
               required 
               autocomplete="email" 
               autofocus>
        
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" 
               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               id="password"
               name="password" 
               placeholder="Enter your password" 
               required 
               autocomplete="current-password">
        
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label class="form-check-label" for="remember">
                Remember me on this device
            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-auth">
        <i class="bi bi-box-arrow-in-right me-2"></i>Login to QuickPlate
    </button>

    <div class="auth-links">
        <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>">
                <i class="bi bi-key"></i> Forgot Your Password?
            </a>
        <?php endif; ?>
        <br><br>
        <span class="text-muted">Don't have an account yet?</span><br>
        <a href="<?php echo e(route('register')); ?>" class="fw-bold">
            <i class="bi bi-person-plus"></i> Create New Account
        </a>
    </div>
</form>

<!-- Admin Login Helper -->
<div class="text-center mt-4 pt-3 border-top">
    <small class="text-muted">
        <i class="bi bi-shield-check text-warning"></i>
        <strong>Test Accounts:</strong><br>
        Admin: admin@quickplate.com / admin123<br>
        User: user@test.com / password
    </small>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/auth/login.blade.php ENDPATH**/ ?>