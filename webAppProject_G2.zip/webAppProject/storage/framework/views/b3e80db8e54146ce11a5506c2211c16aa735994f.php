

<?php $__env->startSection('title', 'Order Tracking - QuickPlate'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5" style="margin-top: 120px; margin-bottom: 80px;">
    <div class="row">
        <div class="col-12">
            <h2><i class="fas fa-map-marker-alt me-2"></i>Track Your Orders</h2>
            <hr>
        </div>
    </div>

    <?php if($orders->count() > 0): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4 shadow">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">Order <?php echo e($order->order_number); ?></h5>
                        <small class="text-muted">Placed on <?php echo e($order->created_at->format('M d, Y \a\t g:i A')); ?></small>
                    </div>
                    <span class="badge bg-<?php echo e($order->status_color); ?> fs-6">
                        <?php echo e($order->status_text); ?>

                    </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- Order Progress -->
                            <div class="order-progress mb-3">
                                <div class="progress-step <?php echo e(in_array($order->status, ['confirmed', 'preparing', 'out_for_delivery', 'delivered']) ? 'completed' : ''); ?>">
                                    <div class="step-icon">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Order Received</h6>
                                        <small>Your order has been placed</small>
                                        <br><small class="text-muted"><?php echo e($order->created_at->format('g:i A')); ?></small>
                                    </div>
                                </div>
                                
                                <div class="progress-step <?php echo e(in_array($order->status, ['preparing', 'out_for_delivery', 'delivered']) ? 'completed' : ($order->status === 'confirmed' ? 'active' : '')); ?>">
                                    <div class="step-icon">
                                        <i class="fas fa-utensils"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Preparing Order</h6>
                                        <small>Your food is being prepared</small>
                                        <?php if(in_array($order->status, ['preparing', 'out_for_delivery', 'delivered'])): ?>
                                            <br><small class="text-muted"><?php echo e($order->updated_at->format('g:i A')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="progress-step <?php echo e(in_array($order->status, ['out_for_delivery', 'delivered']) ? 'completed' : ($order->status === 'preparing' ? 'active' : '')); ?>">
                                    <div class="step-icon">
                                        <i class="fas fa-motorcycle"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Out for Delivery</h6>
                                        <small>Your order is on the way</small>
                                        <?php if(in_array($order->status, ['out_for_delivery', 'delivered'])): ?>
                                            <br><small class="text-muted"><?php echo e($order->updated_at->format('g:i A')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="progress-step <?php echo e($order->status === 'delivered' ? 'completed' : ($order->status === 'out_for_delivery' ? 'active' : '')); ?>">
                                    <div class="step-icon">
                                        <i class="fas fa-home"></i>
                                    </div>
                                    <div class="step-content">
                                        <h6>Delivered</h6>
                                        <small>Order has been delivered</small>
                                        <?php if($order->status === 'delivered'): ?>
                                            <br><small class="text-muted"><?php echo e($order->delivered_at ? $order->delivered_at->format('g:i A') : $order->updated_at->format('g:i A')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Delivery Info -->
                            <div class="delivery-info">
                                <h6><i class="fas fa-map-marker-alt me-2"></i>Delivery Address</h6>
                                <p class="mb-1"><strong><?php echo e($order->customer_name); ?></strong></p>
                                <p class="mb-1"><?php echo e($order->delivery_address); ?></p>
                                <p class="mb-1"><?php echo e($order->city); ?>, <?php echo e($order->state); ?></p>
                                <?php if($order->postal_code): ?>
                                    <p class="mb-1"><?php echo e($order->postal_code); ?></p>
                                <?php endif; ?>
                                <p class="mb-0 text-muted">
                                    <i class="fas fa-phone me-1"></i><?php echo e($order->customer_phone); ?>

                                </p>
                                
                                <!-- Estimated Delivery Time -->
                                <?php if($order->estimated_delivery_time && $order->status !== 'delivered'): ?>
                                    <div class="alert alert-info mt-3">
                                        <i class="fas fa-clock me-2"></i>
                                        <strong>Estimated Delivery:</strong> 
                                        <?php echo e($order->estimated_delivery_time->format('g:i A')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <!-- Order Items -->
                            <h6>Your Order</h6>
                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="d-flex align-items-center">
                                        <?php if($item->foodItem && $item->foodItem->image_url): ?>
                                            <img src="<?php echo e($item->foodItem->image_url); ?>" 
                                                 class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="bg-secondary rounded me-2 d-flex align-items-center justify-content-center" 
                                                 style="width: 40px; height: 40px;">
                                                <i class="fas fa-utensils text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <small class="fw-bold"><?php echo e($item->food_name); ?></small><br>
                                            <small class="text-muted">Qty: <?php echo e($item->quantity); ?></small>
                                        </div>
                                    </div>
                                    <span>RM<?php echo e(number_format($item->subtotal, 2)); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <hr>
                            <!-- Order Summary -->
                            <div class="d-flex justify-content-between mb-1">
                                <span>Subtotal:</span>
                                <span>RM<?php echo e(number_format($order->subtotal, 2)); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-1">
                                <span>Delivery Fee:</span>
                                <span>RM<?php echo e(number_format($order->delivery_fee, 2)); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-1">
                                <span>Service Tax:</span>
                                <span>RM<?php echo e(number_format($order->service_tax, 2)); ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <strong>Total: RM<?php echo e(number_format($order->total_amount, 2)); ?></strong>
                            </div>
                            
                            <!-- Payment Method -->
                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-credit-card me-1"></i>
                                    Payment: <?php echo e(ucfirst(str_replace('_', ' ', $order->payment_method))); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="col-12 text-center py-5">
            <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
            <h4>No orders found</h4>
            <p class="text-muted">You haven't placed any orders yet.</p>
            <a href="<?php echo e(route('menu')); ?>" class="btn btn-primary">
                <i class="fas fa-utensils me-2"></i>Start Ordering
            </a>
        </div>
    <?php endif; ?>
</div>

<style>
.order-progress .progress-step {
    display: flex;
    align-items: flex-start;
    margin-bottom: 25px;
    position: relative;
}

.order-progress .progress-step:not(:last-child)::after {
    content: '';
    position: absolute;
    left: 20px;
    top: 40px;
    width: 2px;
    height: 40px;
    background: #dee2e6;
}

.order-progress .progress-step.completed::after {
    background: #28a745;
}

.order-progress .progress-step.active::after {
    background: linear-gradient(to bottom, #28a745 50%, #dee2e6 50%);
}

.progress-step .step-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #dee2e6;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    color: #6c757d;
    flex-shrink: 0;
}

.progress-step.completed .step-icon {
    background: #28a745;
    color: white;
}

.progress-step.active .step-icon {
    background: #007bff;
    color: white;
    animation: pulse 2s infinite;
}

.step-content h6 {
    margin-bottom: 2px;
    font-size: 14px;
}

.step-content small {
    color: #6c757d;
    font-size: 12px;
}

.progress-step.completed .step-content h6 {
    color: #28a745;
    font-weight: 600;
}

.progress-step.active .step-content h6 {
    color: #007bff;
    font-weight: 600;
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7);
    }
    70% {
        box-shadow: 0 0 0 10px rgba(0, 123, 255, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(0, 123, 255, 0);
    }
}

.card {
    border: none;
    border-radius: 15px;
}

.card-header {
    border-radius: 15px 15px 0 0 !important;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/tracking.blade.php ENDPATH**/ ?>