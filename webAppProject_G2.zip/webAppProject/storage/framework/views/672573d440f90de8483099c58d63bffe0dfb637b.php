

<?php $__env->startSection('title', 'Our Menu'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Hero Section -->
    <section id="menu-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Our Delicious Menu</h1>
                    <p>Discover our carefully crafted halal dishes made with the finest ingredients</p>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="btns mt-4">
                            <a href="<?php echo e(route('cart.index')); ?>" class="btn-get-started">
                                <i class="bi bi-cart"></i> View Cart
                                <?php
                                    $cart = auth()->user()->cart;
                                    $cartCount = $cart ? $cart->cartItems->sum('quantity') : 0;
                                ?>
                                <?php if($cartCount > 0): ?>
                                    <span class="badge bg-warning text-dark ms-1"><?php echo e($cartCount); ?></span>
                                <?php endif; ?>
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="btns mt-4">
                            <a href="<?php echo e(route('register')); ?>" class="btn-get-started">
                                <i class="bi bi-person-plus"></i> Register to Order
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Menu Section -->
    <section id="menu" class="menu section">
        <div class="container isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">
            
            <!-- Search and Filter Bar -->
            <div class="row mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="col-lg-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search for food..." id="menuSearch">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-filter"></i></span>
                        <select class="form-select" id="priceFilter">
                            <option value="">All Prices</option>
                            <option value="0-10">Under RM 10</option>
                            <option value="10-20">RM 10 - RM 20</option>
                            <option value="20-50">RM 20 - RM 50</option>
                            <option value="50+">Above RM 50</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Menu Filters -->
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-lg-12 d-flex justify-content-center">
                    <ul class="menu-filters isotope-filters">
                        <li data-filter="*" class="filter-active">All</li>
                        <li data-filter=".filter-food">Food</li>
                        <li data-filter=".filter-drinks">Drinks</li>
                        <li data-filter=".filter-dessert">Desserts</li>
                        <li data-filter=".filter-specialty">Specialty</li>
                    </ul>
                </div>
            </div>

            <!-- Menu Items -->
            <?php if($foodItems->count() > 0): ?>
                <div class="row isotope-container" data-aos="fade-up" data-aos-delay="200" id="menuContainer">
                    <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 menu-item isotope-item filter-<?php echo e($item->category); ?> food-card" 
                         data-name="<?php echo e(strtolower($item->name)); ?>" 
                         data-price="<?php echo e($item->price); ?>"
                         data-description="<?php echo e(strtolower($item->description)); ?>">
                        
                        <div class="menu-item-card h-100">
                            <?php if($item->image): ?>
                                <img src="<?php echo e(asset('assets/img/menu/' . $item->image)); ?>" class="menu-img" alt="<?php echo e($item->name); ?>">
                            <?php else: ?>
                                <div class="menu-img bg-light d-flex align-items-center justify-content-center">
                                    <i class="bi bi-image text-muted" style="font-size: 3rem;"></i>
                                </div>
                            <?php endif; ?>
                            
                            <div class="menu-content">
                                <div class="d-flex justify-content-between align-items-start">
                                    <a href="#" onclick="showItemDetails(<?php echo e($item->id); ?>)"><?php echo e($item->name); ?></a>
                                    <span class="price"><?php echo e($item->formatted_price); ?></span>
                                </div>
                                
                                <?php if(!$item->is_available): ?>
                                    <span class="badge bg-danger mb-2">Out of Stock</span>
                                <?php endif; ?>
                                
                                <div class="menu-ingredients">
                                    <?php echo e(Str::limit($item->description, 80)); ?>

                                    
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if($item->is_available): ?>
                                            <div class="mt-3">
                                                <div class="d-flex align-items-center gap-2">
                                                    <div class="quantity-controls">
                                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="decreaseQuantity(<?php echo e($item->id); ?>)">-</button>
                                                        <span class="quantity-display mx-2" id="quantity-<?php echo e($item->id); ?>">1</span>
                                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="increaseQuantity(<?php echo e($item->id); ?>)">+</button>
                                                    </div>
                                                    <button type="button" class="btn btn-primary btn-sm flex-grow-1" onclick="addToCart(<?php echo e($item->id); ?>)">
                                                        <i class="bi bi-cart-plus"></i> Add to Cart
                                                    </button>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="mt-3">
                                                <button class="btn btn-secondary btn-sm w-100" disabled>
                                                    <i class="bi bi-x-circle"></i> Currently Unavailable
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="mt-3">
                                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary btn-sm w-100">
                                                <i class="bi bi-box-arrow-in-right"></i> Login to Order
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Load More Button -->
                <?php if($foodItems->hasPages()): ?>
                <div class="text-center mt-4">
                    <?php echo e($foodItems->links()); ?>

                </div>
                <?php endif; ?>

            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up" data-aos-delay="200">
                    <i class="bi bi-grid-3x3-gap text-muted" style="font-size: 5rem;"></i>
                    <h3 class="mt-3">Menu Coming Soon</h3>
                    <p class="text-muted">We're preparing something delicious for you. Please check back later!</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<!-- Item Details Modal -->
<div class="modal fade" id="itemModal" tabindex="-1" aria-labelledby="itemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="itemModalLabel">Food Item Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="itemModalBody">
                <!-- Content loaded dynamically -->
            </div>
        </div>
    </div>
</div>

<?php if(auth()->guard()->check()): ?>
<!-- Success Toast -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="cartToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <i class="bi bi-cart-check text-success me-2"></i>
            <strong class="me-auto">Added to Cart</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body" id="toastBody">
            Item added to your cart successfully!
        </div>
    </div>
</div>
<?php endif; ?>

<style>
.menu-item-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    transition: transform 0.3s ease;
    margin-bottom: 20px;
}

.menu-item-card:hover {
    transform: translateY(-5px);
}

.menu-img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.quantity-controls {
    display: flex;
    align-items: center;
}

.quantity-display {
    min-width: 30px;
    text-align: center;
    font-weight: bold;
}

.price {
    color: #ce1212;
    font-weight: bold;
    font-size: 1.1em;
}
</style>

<?php if(auth()->guard()->check()): ?>
<?php $__env->startPush('scripts'); ?>
<script>
    let quantities = {};

    function increaseQuantity(itemId) {
        if (!quantities[itemId]) quantities[itemId] = 1;
        quantities[itemId]++;
        document.getElementById(`quantity-${itemId}`).textContent = quantities[itemId];
    }

    function decreaseQuantity(itemId) {
        if (!quantities[itemId]) quantities[itemId] = 1;
        if (quantities[itemId] > 1) {
            quantities[itemId]--;
            document.getElementById(`quantity-${itemId}`).textContent = quantities[itemId];
        }
    }

    function addToCart(itemId) {
        const quantity = quantities[itemId] || 1;
        
        fetch(`/api/cart/add/${itemId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ quantity: quantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success toast
                document.getElementById('toastBody').textContent = `${data.quantity} × ${data.item_name} added to cart!`;
                new bootstrap.Toast(document.getElementById('cartToast')).show();
                
                // Reset quantity
                quantities[itemId] = 1;
                document.getElementById(`quantity-${itemId}`).textContent = 1;
                
                // Update cart count in header
                updateCartCount(data.cart_count);
            } else

    function updateCartCount() {
        // Update cart count in navigation
        // This would fetch the current cart count
    }

    // Search and filter functionality
    document.getElementById('menuSearch').addEventListener('input', filterMenu);
    document.getElementById('priceFilter').addEventListener('change', filterMenu);

    function filterMenu() {
        const searchTerm = document.getElementById('menuSearch').value.toLowerCase();
        const priceRange = document.getElementById('priceFilter').value;
        const cards = document.querySelectorAll('.food-card');

        cards.forEach(card => {
            const name = card.getAttribute('data-name');
            const description = card.getAttribute('data-description');
            const price = parseFloat(card.getAttribute('data-price'));
            
            let matchesSearch = name.includes(searchTerm) || description.includes(searchTerm);
            let matchesPrice = true;
            
            if (priceRange) {
                if (priceRange === '0-10') matchesPrice = price < 10;
                else if (priceRange === '10-20') matchesPrice = price >= 10 && price < 20;
                else if (priceRange === '20-50') matchesPrice = price >= 20 && price < 50;
                else if (priceRange === '50+') matchesPrice = price >= 50;
            }
            
            card.style.display = (matchesSearch && matchesPrice) ? 'block' : 'none';
        });
    }

    function showItemDetails(itemId) {
        // This would load item details in a modal
        console.log('Show details for item:', itemId);
    }
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/menu.blade.php ENDPATH**/ ?>