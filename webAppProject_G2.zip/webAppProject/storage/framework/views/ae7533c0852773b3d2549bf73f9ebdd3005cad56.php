

<?php $__env->startSection('title', 'Order Confirmation'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Success Header -->
    <section id="confirmation-hero" class="hero section dark-background">
        <div class="container position-relative text-center" data-aos="zoom-in" data-aos-delay="100">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="success-icon mb-4">
                        <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
                    </div>
                    <h1>Order Confirmed!</h1>
                    <p class="lead">Thank you for your order. We're preparing your delicious halal meal!</p>
                    <div class="order-number mt-4">
                        <span class="badge bg-primary fs-6 px-4 py-2">Order #<?php echo e($order->order_number); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Order Details -->
    <section id="order-details" class="section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    
                    <!-- Order Status -->
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="mb-0"><i class="bi bi-info-circle"></i> Order Status</h5>
                                </div>
                                <div class="col-md-6 text-md-end">
                                    <span class="badge bg-<?php echo e($order->status_badge_color); ?> fs-6"><?php echo e($order->status_label); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Order Number:</strong> <?php echo e($order->order_number); ?></p>
                                    <p><strong>Order Date:</strong> <?php echo e($order->created_at->format('M d, Y \a\t g:i A')); ?></p>
                                    <p><strong>Payment Method:</strong> <?php echo e(ucwords(str_replace('_', ' ', $order->payment_method))); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Estimated Delivery:</strong> <?php echo e($order->estimated_delivery_time->format('g:i A')); ?></p>
                                    <p><strong>Total Amount:</strong> <span class="text-primary fs-5"><?php echo e($order->formatted_total); ?></span></p>
                                    <p><strong>Payment Status:</strong> 
                                        <span class="badge bg-<?php echo e($order->payment_status_badge_color); ?>"><?php echo e(ucfirst($order->payment_status)); ?></span>
                                    </p>
                                </div>
                            </div>
                            
                            <?php if($order->special_instructions): ?>
                            <div class="mt-3">
                                <strong>Special Instructions:</strong>
                                <p class="text-muted"><?php echo e($order->special_instructions); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Order Items -->
                        <div class="col-lg-8">
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="bi bi-basket"></i> Order Items</h5>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-borderless mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Price</th>
                                                    <th>Qty</th>
                                                    <th class="text-end">Subtotal</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <?php if($item->foodItem && $item->foodItem->image): ?>
                                                                <img src="<?php echo e($item->foodItem->image_url); ?>" 
                                                                     alt="<?php echo e($item->food_name); ?>" 
                                                                     class="rounded me-3"
                                                                     style="width: 50px; height: 50px; object-fit: cover;">
                                                            <?php else: ?>
                                                                <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center"
                                                                     style="width: 50px; height: 50px;">
                                                                    <i class="bi bi-image text-muted"></i>
                                                                </div>
                                                            <?php endif; ?>
                                                            <div>
                                                                <h6 class="mb-1"><?php echo e($item->food_name); ?></h6>
                                                                <small class="text-muted"><?php echo e(ucfirst($item->food_category)); ?></small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="align-middle"><?php echo e($item->formatted_unit_price); ?></td>
                                                    <td class="align-middle"><?php echo e($item->quantity); ?></td>
                                                    <td class="align-middle text-end"><strong><?php echo e($item->formatted_subtotal); ?></strong></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Order Summary & Delivery -->
                        <div class="col-lg-4">
                            <!-- Order Summary -->
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="bi bi-receipt"></i> Order Summary</h5>
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Subtotal:</span>
                                        <span><?php echo e($order->formatted_subtotal); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Delivery Fee:</span>
                                        <span><?php echo e($order->formatted_delivery_fee); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Service Tax:</span>
                                        <span><?php echo e($order->formatted_service_tax); ?></span>
                                    </div>
                                    <hr>
                                    <div class="d-flex justify-content-between">
                                        <strong>Total:</strong>
                                        <strong class="text-primary"><?php echo e($order->formatted_total); ?></strong>
                                    </div>
                                </div>
                            </div>

                            <!-- Delivery Information -->
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="bi bi-truck"></i> Delivery Details</h5>
                                </div>
                                <div class="card-body">
                                    <p><strong>Deliver to:</strong> <?php echo e($order->customer_name); ?></p>
                                    <p><strong>Phone:</strong> <?php echo e($order->customer_phone); ?></p>
                                    <p><strong>Address:</strong><br>
                                        <?php echo e($order->delivery_address); ?><br>
                                        <?php if($order->postal_code): ?><?php echo e($order->postal_code); ?> <?php endif; ?><?php echo e($order->city); ?>, <?php echo e($order->state); ?>

                                    </p>
                                    <div class="bg-light p-3 rounded">
                                        <div class="d-flex align-items-center">
                                            <i class="bi bi-clock text-primary me-2"></i>
                                            <div>
                                                <strong>Estimated Delivery</strong>
                                                <div class="text-muted"><?php echo e($order->estimated_delivery_time->format('g:i A')); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Payment Information -->
                            <?php if($order->payment_method === 'bank_transfer'): ?>
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-warning text-dark">
                                    <h5 class="mb-0"><i class="bi bi-exclamation-triangle"></i> Payment Required</h5>
                                </div>
                                <div class="card-body">
                                    <p><strong>Bank Transfer Details:</strong></p>
                                    <p class="mb-2"><strong>Bank:</strong> Maybank</p>
                                    <p class="mb-2"><strong>Account No:</strong> 1234567890</p>
                                    <p class="mb-2"><strong>Account Name:</strong> QuickPlate Sdn Bhd</p>
                                    <p class="mb-2"><strong>Amount:</strong> <?php echo e($order->formatted_total); ?></p>
                                    <p class="mb-2"><strong>Reference:</strong> <?php echo e($order->order_number); ?></p>
                                    <small class="text-muted">Please transfer the exact amount and use the order number as reference.</small>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="row mt-4">
                        <div class="col-12 text-center">
                            <a href="<?php echo e(route('checkout.track', $order->order_number)); ?>" class="btn btn-primary btn-lg me-3">
                                <i class="bi bi-geo-alt"></i> Track Order
                            </a>
                            <a href="<?php echo e(route('menu')); ?>" class="btn btn-outline-primary btn-lg me-3">
                                <i class="bi bi-grid-3x3-gap"></i> Order More
                            </a>
                            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary btn-lg">
                                <i class="bi bi-list-ul"></i> Order History
                            </a>
                        </div>
                    </div>

                    <!-- Next Steps -->
                    <div class="card shadow-sm mt-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><i class="bi bi-lightbulb"></i> What Happens Next?</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3 text-center mb-3">
                                    <i class="bi bi-check-circle text-success" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">Order Received</h6>
                                    <small class="text-muted">We've received your order</small>
                                </div>
                                <div class="col-md-3 text-center mb-3">
                                    <i class="bi bi-clock text-warning" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">Confirmation</h6>
                                    <small class="text-muted">We'll confirm your order shortly</small>
                                </div>
                                <div class="col-md-3 text-center mb-3">
                                    <i class="bi bi-fire text-danger" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">Preparation</h6>
                                    <small class="text-muted">Our chefs will prepare your meal</small>
                                </div>
                                <div class="col-md-3 text-center mb-3">
                                    <i class="bi bi-truck text-primary" style="font-size: 2rem;"></i>
                                    <h6 class="mt-2">Delivery</h6>
                                    <small class="text-muted">Fresh halal food at your door</small>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Auto-refresh page every 30 seconds to check for status updates
setTimeout(() => {
    location.reload();
}, 30000);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/checkout/confirmation.blade.php ENDPATH**/ ?>