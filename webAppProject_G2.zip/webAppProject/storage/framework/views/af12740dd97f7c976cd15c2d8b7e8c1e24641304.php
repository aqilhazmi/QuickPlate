

<?php $__env->startSection('title', 'Manage Menu Items'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Admin Header -->
    <section id="admin-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Manage Menu Items</h1>
                    <p>Add, edit, and manage your restaurant's menu items</p>
                    <div class="btns mt-4">
                        <a href="<?php echo e(route('admin.food-items.create')); ?>" class="btn-get-started">
                            <i class="bi bi-plus-circle"></i> Add New Item
                        </a>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Food Items Management -->
    <section id="food-items-management" class="section">
        <div class="container">
            
            <!-- Search and Filter -->
            <div class="row mb-4">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.food-items.index')); ?>" method="GET" class="row g-3">
                                <div class="col-md-6">
                                    <label for="search" class="form-label">Search Items</label>
                                    <input type="text" class="form-control" id="search" name="search" 
                                           placeholder="Search by name or description..." 
                                           value="<?php echo e(request('search')); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label for="category" class="form-label">Category</label>
                                    <select class="form-select" id="category" name="category">
                                        <option value="">All Categories</option>
                                        <option value="food" <?php echo e(request('category') == 'food' ? 'selected' : ''); ?>>Food</option>
                                        <option value="drinks" <?php echo e(request('category') == 'drinks' ? 'selected' : ''); ?>>Drinks</option>
                                        <option value="dessert" <?php echo e(request('category') == 'dessert' ? 'selected' : ''); ?>>Desserts</option>
                                        <option value="specialty" <?php echo e(request('category') == 'specialty' ? 'selected' : ''); ?>>Specialty</option>
                                    </select>
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search"></i> Search
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Quick Stats</h5>
                            <p class="mb-1"><strong>Total Items:</strong> <?php echo e($foodItems->total() ?? 0); ?></p>
                            <p class="mb-0"><strong>Available:</strong> <?php echo e(isset($foodItems) ? $foodItems->where('is_available', true)->count() : 0); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Success/Error Messages -->
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Food Items Table -->
            <?php if(isset($foodItems) && $foodItems->count() > 0): ?>
                <div class="card shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="bi bi-grid-3x3-gap"></i> Menu Items</h5>
                        <a href="<?php echo e(route('admin.food-items.create')); ?>" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Add New Item
                        </a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 80px;">Image</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th style="width: 120px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($item->image): ?>
                                                 <img src="<?php echo e($item->image_url); ?>" 
                                                    alt="<?php echo e($item->name); ?>" 
                                                    class="rounded"
                                                    style="width: 60px; height: 60px; object-fit: cover;"
                                                    onerror="this.src='<?php echo e(asset('assets/img/menu/default.jpg')); ?>'">
                                            <?php else: ?>
                                                <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                                    style="width: 60px; height: 60px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo e($item->name); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo e(Str::limit($item->description, 50)); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo e(ucfirst($item->category)); ?></span>
                                        </td>
                                        <td>
                                            <strong class="text-primary">RM <?php echo e(number_format($item->price, 2)); ?></strong>
                                        </td>
                                        <td>
                                            <?php if($item->is_available): ?>
                                                <span class="badge bg-success">Available</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Unavailable</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo e($item->created_at->format('M d, Y')); ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.food-items.edit', $item->id)); ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        onclick="deleteItem(<?php echo e($item->id); ?>, '<?php echo e($item->name); ?>')"
                                                        title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if(method_exists($foodItems, 'links')): ?>
                        <div class="card-footer">
                            <div class="d-flex justify-content-center">
                                <?php echo e($foodItems->appends(request()->query())->links()); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            <?php else: ?>
                <!-- No Items -->
                <div class="card shadow-sm">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-grid-3x3-gap text-muted" style="font-size: 4rem;"></i>
                        <h3 class="mt-3">No Menu Items Found</h3>
                        <p class="text-muted">
                            <?php if(request()->hasAny(['search', 'category'])): ?>
                                No items match your search criteria.
                            <?php else: ?>
                                Start building your menu by adding your first item.
                            <?php endif; ?>
                        </p>
                        <div class="mt-4">
                            <?php if(request()->hasAny(['search', 'category'])): ?>
                                <a href="<?php echo e(route('admin.food-items.index')); ?>" class="btn btn-outline-secondary me-2">
                                    <i class="bi bi-arrow-clockwise"></i> Clear Filters
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('admin.food-items.create')); ?>" class="btn btn-primary">
                                <i class="bi bi-plus-circle"></i> Add First Item
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>
</main>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="itemName"></strong>?</p>
                <p class="text-muted small">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteForm" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Delete Item
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function deleteItem(itemId, itemName) {
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    const form = document.getElementById('deleteForm');
    const nameElement = document.getElementById('itemName');
    
    // Set the item name in modal
    nameElement.textContent = itemName;
    
    // Set the form action URL
    form.action = `/admin/food-items/${itemId}`;
    
    // Show the modal
    modal.show();
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/admin/food-items/index.blade.php ENDPATH**/ ?>