

<?php $__env->startSection('title', 'My Orders'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Orders Header -->
    <section id="orders-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>My Orders</h1>
                    <p>Track your current orders and view your order history</p>
                    <div class="btns mt-4">
                        <a href="<?php echo e(route('menu')); ?>" class="btn-get-started">
                            <i class="bi bi-plus-circle"></i> Order More Food
                        </a>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn-get-started">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Orders Content -->
    <section id="orders-content" class="section">
        <div class="container">
            
            <!-- Filter and Search -->
            <div class="row mb-4">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo e(route('orders.index')); ?>" method="GET" class="row g-3">
                                <div class="col-md-4">
                                    <label for="search" class="form-label">Search Orders</label>
                                    <input type="text" 
                                           class="form-control" 
                                           id="search" 
                                           name="search" 
                                           placeholder="Order number, food items..."
                                           value="<?php echo e(request('search')); ?>">
                                </div>
                                <div class="col-md-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="">All Status</option>
                                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                        <option value="confirmed" <?php echo e(request('status') == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                                        <option value="preparing" <?php echo e(request('status') == 'preparing' ? 'selected' : ''); ?>>Preparing</option>
                                        <option value="out_for_delivery" <?php echo e(request('status') == 'out_for_delivery' ? 'selected' : ''); ?>>Out for Delivery</option>
                                        <option value="delivered" <?php echo e(request('status') == 'delivered' ? 'selected' : ''); ?>>Delivered</option>
                                        <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="date_from" class="form-label">From Date</label>
                                    <input type="date" 
                                           class="form-control" 
                                           id="date_from" 
                                           name="date_from" 
                                           value="<?php echo e(request('date_from')); ?>">
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search"></i> Search
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Order Statistics</h5>
                            <p class="mb-1"><strong>Total Orders:</strong> <?php echo e($orders->total() ?? 0); ?></p>
                            <p class="mb-0"><strong>Active Orders:</strong> <?php echo e(isset($orders) ? $orders->whereIn('status', ['pending', 'confirmed', 'preparing', 'out_for_delivery'])->count() : 0); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Active/Recent Orders -->
            <?php if(isset($orders) && $orders->count() > 0): ?>
                
                <!-- Clear Filters -->
                <?php if(request()->hasAny(['search', 'status', 'date_from'])): ?>
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="alert alert-info d-flex justify-content-between align-items-center">
                            <div>
                                <i class="bi bi-info-circle"></i>
                                Filters applied:
                                <?php if(request('search')): ?>
                                    <span class="badge bg-primary">Search: "<?php echo e(request('search')); ?>"</span>
                                <?php endif; ?>
                                <?php if(request('status')): ?>
                                    <span class="badge bg-primary">Status: <?php echo e(ucfirst(request('status'))); ?></span>
                                <?php endif; ?>
                                <?php if(request('date_from')): ?>
                                    <span class="badge bg-primary">From: <?php echo e(request('date_from')); ?></span>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Clear All
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Results Count -->
                <div class="row mb-3">
                    <div class="col-12">
                        <p class="text-muted">
                            Showing <?php echo e($orders->firstItem() ?? 0); ?> to <?php echo e($orders->lastItem() ?? 0); ?> 
                            of <?php echo e($orders->total()); ?> orders
                        </p>
                    </div>
                </div>

                <!-- Orders List -->
                <div class="row">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mb-4">
                        <div class="card shadow-sm order-card">
                            <div class="card-header bg-light">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <h6 class="mb-0">
                                            <i class="bi bi-receipt"></i> 
                                            Order <?php echo e($order->order_number); ?>

                                        </h6>
                                        <small class="text-muted"><?php echo e($order->created_at->format('M d, Y \a\t g:i A')); ?></small>
                                    </div>
                                    <div class="col-md-6 text-md-end">
                                        <span class="badge bg-<?php echo e($order->status_badge_color); ?> fs-6 me-2"><?php echo e($order->status_label); ?></span>
                                        <span class="badge bg-<?php echo e($order->payment_status_badge_color); ?> fs-6"><?php echo e(ucfirst($order->payment_status)); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- Order Items Preview -->
                                    <div class="col-md-6">
                                        <h6 class="mb-2">Items (<?php echo e($order->total_items); ?>)</h6>
                                        <div class="order-items-preview">
                                            <?php $__currentLoopData = $order->orderItems->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex align-items-center mb-2">
                                                <?php if($item->foodItem && $item->foodItem->image): ?>
                                                    <img src="<?php echo e($item->foodItem->image_url); ?>" 
                                                         alt="<?php echo e($item->food_name); ?>" 
                                                         class="rounded me-2"
                                                         style="width: 30px; height: 30px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-light rounded me-2 d-flex align-items-center justify-content-center"
                                                         style="width: 30px; height: 30px;">
                                                        <i class="bi bi-image text-muted" style="font-size: 0.8rem;"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="flex-grow-1">
                                                    <small><strong><?php echo e($item->food_name); ?></strong></small>
                                                    <small class="text-muted d-block"><?php echo e($item->quantity); ?>x <?php echo e($item->formatted_unit_price); ?></small>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($order->orderItems->count() > 3): ?>
                                                <small class="text-muted">+<?php echo e($order->orderItems->count() - 3); ?> more items</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Order Summary -->
                                    <div class="col-md-3">
                                        <h6 class="mb-2">Order Total</h6>
                                        <p class="h5 text-primary mb-1"><?php echo e($order->formatted_total); ?></p>
                                        <small class="text-muted"><?php echo e(ucwords(str_replace('_', ' ', $order->payment_method))); ?></small>
                                        
                                        <?php if($order->estimated_delivery_time): ?>
                                        <div class="mt-2">
                                            <small class="text-muted d-block">Estimated Delivery</small>
                                            <small><strong><?php echo e($order->estimated_delivery_time->format('g:i A')); ?></strong></small>
                                        </div>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Actions -->
                                    <div class="col-md-3 text-md-end">
                                        <div class="d-grid gap-2">
                                            <a href="<?php echo e(route('orders.show', $order->id)); ?>" class="btn btn-primary btn-sm">
                                                <i class="bi bi-eye"></i> View Details
                                            </a>
                                            
                                            <?php if($order->isActive()): ?>
                                                <a href="<?php echo e(route('checkout.track', $order->order_number)); ?>" class="btn btn-outline-primary btn-sm">
                                                    <i class="bi bi-geo-alt"></i> Track Order
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if($order->canBeCancelled()): ?>
                                                <button type="button" 
                                                        class="btn btn-outline-danger btn-sm" 
                                                        onclick="cancelOrder(<?php echo e($order->id); ?>, '<?php echo e($order->order_number); ?>')">
                                                    <i class="bi bi-x-circle"></i> Cancel
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if($order->isCompleted()): ?>
                                                <button type="button" class="btn btn-outline-success btn-sm">
                                                    <i class="bi bi-star"></i> Rate Order
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="d-flex justify-content-center">
                            <?php echo e($orders->appends(request()->query())->links()); ?>

                        </div>
                    </div>
                </div>

            <?php else: ?>
                <!-- No Orders -->
                <div class="row">
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-basket text-muted" style="font-size: 5rem;"></i>
                        <h3 class="mt-3">No Orders Found</h3>
                        <p class="text-muted">
                            <?php if(request()->hasAny(['search', 'status', 'date_from'])): ?>
                                No orders match your search criteria. Try adjusting your filters.
                            <?php else: ?>
                                You haven't placed any orders yet. Start by browsing our delicious menu!
                            <?php endif; ?>
                        </p>
                        <div class="mt-4">
                            <?php if(request()->hasAny(['search', 'status', 'date_from'])): ?>
                                <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary me-2">
                                    <i class="bi bi-arrow-clockwise"></i> Clear Filters
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('menu')); ?>" class="btn btn-primary">
                                <i class="bi bi-grid-3x3-gap"></i> Browse Menu
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>
</main>

<!-- Cancel Order Modal -->
<div class="modal fade" id="cancelOrderModal" tabindex="-1" aria-labelledby="cancelOrderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cancelOrderModalLabel">Cancel Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to cancel order <strong id="cancelOrderNumber"></strong>?</p>
                <div class="form-group">
                    <label for="cancellation_reason" class="form-label">Reason for cancellation (optional):</label>
                    <textarea class="form-control" id="cancellation_reason" rows="3" placeholder="Please let us know why you're cancelling this order..."></textarea>
                </div>
                <p class="text-muted small mt-2">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keep Order</button>
                <form id="cancelOrderForm" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="cancellation_reason" id="hidden_cancellation_reason">
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-x-circle"></i> Cancel Order
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function cancelOrder(orderId, orderNumber) {
    const modal = new bootstrap.Modal(document.getElementById('cancelOrderModal'));
    const form = document.getElementById('cancelOrderForm');
    const orderNumberElement = document.getElementById('cancelOrderNumber');
    const reasonTextarea = document.getElementById('cancellation_reason');
    const hiddenReasonInput = document.getElementById('hidden_cancellation_reason');
    
    // Set the order number in modal
    orderNumberElement.textContent = orderNumber;
    
    // Set the form action URL
    form.action = `/orders/${orderId}/cancel`;
    
    // Update hidden input when textarea changes
    reasonTextarea.addEventListener('input', function() {
        hiddenReasonInput.value = this.value;
    });
    
    // Show the modal
    modal.show();
}

// Auto-refresh every 30 seconds for active orders
document.addEventListener('DOMContentLoaded', function() {
    const hasActiveOrders = document.querySelectorAll('.order-card').length > 0;
    if (hasActiveOrders) {
        setTimeout(() => {
            location.reload();
        }, 30000);
    }
});
</script>
<?php $__env->stopPush(); ?>

<style>
.order-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.order-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.order-items-preview {
    max-height: 150px;
    overflow-y: auto;
}
</style>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/orders/index.blade.php ENDPATH**/ ?>