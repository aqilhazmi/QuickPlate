

<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Checkout Header -->
    <section id="checkout-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Checkout</h1>
                    <p>Complete your order and enjoy delicious halal food delivered to your door</p>
                    <div class="btns mt-4">
                        <a href="<?php echo e(route('cart.index')); ?>" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Back to Cart
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Checkout Form -->
    <section id="checkout-form" class="section">
        <div class="container">
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i>
                    <strong>Please fix the following errors:</strong>
                    <ul class="mb-0 mt-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('checkout.store')); ?>" method="POST" id="checkout-form">
                <?php echo csrf_field(); ?>
                
                <div class="row">
                    <!-- Customer Information -->
                    <div class="col-lg-8">
                        
                        <!-- Delivery Information -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-truck"></i> Delivery Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- Customer Name -->
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="customer_name" 
                                               name="customer_name" 
                                               value="<?php echo e(old('customer_name', auth()->user()->name)); ?>" 
                                               placeholder="Enter your full name"
                                               required>
                                        <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Customer Phone -->
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="customer_phone" 
                                               name="customer_phone" 
                                               value="<?php echo e(old('customer_phone', auth()->user()->phone)); ?>" 
                                               placeholder="e.g., +60123456789"
                                               required>
                                        <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Customer Email -->
                                <div class="mb-3">
                                    <label for="customer_email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                    <input type="email" 
                                           class="form-control <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="customer_email" 
                                           name="customer_email" 
                                           value="<?php echo e(old('customer_email', auth()->user()->email)); ?>" 
                                           placeholder="your.email@example.com"
                                           required>
                                    <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Delivery Address -->
                                <div class="mb-3">
                                    <label for="delivery_address" class="form-label">Delivery Address <span class="text-danger">*</span></label>
                                    <textarea class="form-control <?php $__errorArgs = ['delivery_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="delivery_address" 
                                              name="delivery_address" 
                                              rows="3" 
                                              placeholder="Enter your complete delivery address with unit number, street name, etc."
                                              required><?php echo e(old('delivery_address', auth()->user()->address)); ?></textarea>
                                    <?php $__errorArgs = ['delivery_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row">
                                    <!-- Postal Code -->
                                    <div class="col-md-4 mb-3">
                                        <label for="postal_code" class="form-label">Postal Code</label>
                                        <input type="text" 
                                               class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="postal_code" 
                                               name="postal_code" 
                                               value="<?php echo e(old('postal_code')); ?>" 
                                               placeholder="e.g., 53100">
                                        <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- City -->
                                    <div class="col-md-4 mb-3">
                                        <label for="city" class="form-label">City <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="city" 
                                               name="city" 
                                               value="<?php echo e(old('city', 'Kuala Lumpur')); ?>" 
                                               placeholder="City"
                                               required>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- State -->
                                    <div class="col-md-4 mb-3">
                                        <label for="state" class="form-label">State <span class="text-danger">*</span></label>
                                        <select class="form-select <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="state" 
                                                name="state" 
                                                required>
                                            <option value="">Select State</option>
                                            <option value="Selangor" <?php echo e(old('state', 'Selangor') == 'Selangor' ? 'selected' : ''); ?>>Selangor</option>
                                            <option value="Kuala Lumpur" <?php echo e(old('state') == 'Kuala Lumpur' ? 'selected' : ''); ?>>Kuala Lumpur</option>
                                            <option value="Putrajaya" <?php echo e(old('state') == 'Putrajaya' ? 'selected' : ''); ?>>Putrajaya</option>
                                            <option value="Johor" <?php echo e(old('state') == 'Johor' ? 'selected' : ''); ?>>Johor</option>
                                            <option value="Perak" <?php echo e(old('state') == 'Perak' ? 'selected' : ''); ?>>Perak</option>
                                            <option value="Penang" <?php echo e(old('state') == 'Penang' ? 'selected' : ''); ?>>Penang</option>
                                            <option value="Pahang" <?php echo e(old('state') == 'Pahang' ? 'selected' : ''); ?>>Pahang</option>
                                            <option value="Negeri Sembilan" <?php echo e(old('state') == 'Negeri Sembilan' ? 'selected' : ''); ?>>Negeri Sembilan</option>
                                            <option value="Melaka" <?php echo e(old('state') == 'Melaka' ? 'selected' : ''); ?>>Melaka</option>
                                            <option value="Kedah" <?php echo e(old('state') == 'Kedah' ? 'selected' : ''); ?>>Kedah</option>
                                            <option value="Perlis" <?php echo e(old('state') == 'Perlis' ? 'selected' : ''); ?>>Perlis</option>
                                            <option value="Kelantan" <?php echo e(old('state') == 'Kelantan' ? 'selected' : ''); ?>>Kelantan</option>
                                            <option value="Terengganu" <?php echo e(old('state') == 'Terengganu' ? 'selected' : ''); ?>>Terengganu</option>
                                            <option value="Sabah" <?php echo e(old('state') == 'Sabah' ? 'selected' : ''); ?>>Sabah</option>
                                            <option value="Sarawak" <?php echo e(old('state') == 'Sarawak' ? 'selected' : ''); ?>>Sarawak</option>
                                        </select>
                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Payment Information -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-credit-card"></i> Payment Method</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="radio" 
                                                   name="payment_method" 
                                                   id="cash_on_delivery" 
                                                   value="cash_on_delivery"
                                                   <?php echo e(old('payment_method', 'cash_on_delivery') == 'cash_on_delivery' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="cash_on_delivery">
                                                <i class="bi bi-cash-coin text-success"></i>
                                                <strong>Cash on Delivery</strong>
                                                <small class="d-block text-muted">Pay when your order arrives</small>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="radio" 
                                                   name="payment_method" 
                                                   id="bank_transfer" 
                                                   value="bank_transfer"
                                                   <?php echo e(old('payment_method') == 'bank_transfer' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="bank_transfer">
                                                <i class="bi bi-bank text-primary"></i>
                                                <strong>Bank Transfer</strong>
                                                <small class="d-block text-muted">Transfer to our bank account</small>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="radio" 
                                                   name="payment_method" 
                                                   id="online_payment" 
                                                   value="online_payment"
                                                   <?php echo e(old('payment_method') == 'online_payment' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="online_payment">
                                                <i class="bi bi-phone text-info"></i>
                                                <strong>Online Payment</strong>
                                                <small class="d-block text-muted">FPX, Credit Card, E-Wallet</small>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Special Instructions -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-chat-text"></i> Special Instructions (Optional)</h5>
                            </div>
                            <div class="card-body">
                                <textarea class="form-control <?php $__errorArgs = ['special_instructions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="special_instructions" 
                                          name="special_instructions" 
                                          rows="3" 
                                          placeholder="Any special requests, dietary requirements, or delivery instructions..."><?php echo e(old('special_instructions')); ?></textarea>
                                <div class="form-text">Let us know if you have any special requirements or delivery preferences.</div>
                                <?php $__errorArgs = ['special_instructions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>

                    <!-- Order Summary -->
                    <div class="col-lg-4">
                        <div class="card shadow-sm sticky-top" style="top: 100px;">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="bi bi-receipt"></i> Order Summary</h5>
                            </div>
                            <div class="card-body">
                                
                                <!-- Cart Items -->
                                <div class="order-items mb-3">
                                    <h6 class="mb-3">Your Items (<?php echo e($cartItems->sum('quantity')); ?>)</h6>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                                        <img src="<?php echo e($item->foodItem->image_url); ?>" 
                                             alt="<?php echo e($item->foodItem->name); ?>" 
                                             class="rounded me-3"
                                             style="width: 50px; height: 50px; object-fit: cover;">
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1"><?php echo e($item->foodItem->name); ?></h6>
                                            <small class="text-muted">Qty: <?php echo e($item->quantity); ?> × <?php echo e($item->foodItem->formatted_price); ?></small>
                                        </div>
                                        <div class="text-end">
                                            <strong><?php echo e($item->formatted_subtotal); ?></strong>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <!-- Cost Breakdown -->
                                <div class="cost-breakdown">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Subtotal:</span>
                                        <span>RM <?php echo e(number_format($subtotal, 2)); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Delivery Fee:</span>
                                        <span>RM <?php echo e(number_format($deliveryFee, 2)); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Service Tax (6%):</span>
                                        <span>RM <?php echo e(number_format($serviceTax, 2)); ?></span>
                                    </div>
                                    <hr>
                                    <div class="d-flex justify-content-between mb-3">
                                        <strong>Total:</strong>
                                        <strong class="text-primary h5">RM <?php echo e(number_format($total, 2)); ?></strong>
                                    </div>
                                </div>

                                <!-- Estimated Delivery -->
                                <div class="delivery-info bg-light p-3 rounded mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-clock text-primary me-2"></i>
                                        <div>
                                            <strong>Estimated Delivery Time</strong>
                                            <div class="text-muted small">45 minutes from order confirmation</div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Place Order Button -->
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg" id="place-order-btn">
                                        <i class="bi bi-check-circle"></i> Place Order
                                    </button>
                                </div>

                                <!-- Security Info -->
                                <div class="text-center mt-3">
                                    <small class="text-muted">
                                        <i class="bi bi-shield-check text-success"></i> 
                                        100% Halal Guaranteed | Secure Ordering
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </section>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('checkout-form');
    const submitBtn = document.getElementById('place-order-btn');
    
    form.addEventListener('submit', function(e) {
        // Show loading state
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Processing Order...';
        submitBtn.disabled = true;
        
        // Re-enable after 10 seconds in case of error
        setTimeout(() => {
            if (submitBtn.disabled) {
                submitBtn.innerHTML = '<i class="bi bi-check-circle"></i> Place Order';
                submitBtn.disabled = false;
            }
        }, 10000);
    });
    
    // Auto-fill name if not already filled
    const nameField = document.getElementById('customer_name');
    if (!nameField.value.trim()) {
        nameField.value = '<?php echo e(auth()->user()->name); ?>';
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/checkout/index.blade.php ENDPATH**/ ?>