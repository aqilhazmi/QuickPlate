

<?php $__env->startSection('title', 'Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <!-- Header Section -->
    <section id="cart-hero" class="hero section dark-background">
        <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
            <div class="row">
                <div class="col-lg-8">
                    <h1>Shopping Cart</h1>
                    <p>Review your selected items before checkout</p>
                    <div class="btns mt-4">
                        <a href="<?php echo e(route('menu')); ?>" class="btn-get-started">
                            <i class="bi bi-arrow-left"></i> Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Cart Content -->
    <section id="cart-content" class="section">
        <div class="container">
            <?php if($cartItems->count() > 0): ?>
                <div class="row">
                    <!-- Cart Items -->
                    <div class="col-lg-8">
                        <div class="card shadow-sm">
                            <div class="card-header bg-light">
                                <h5 class="mb-0"><i class="bi bi-cart"></i> Your Order Items</h5>
                            </div>
                            <div class="card-body p-0">
                                <div id="cartItemsContainer">
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="cart-item p-4 border-bottom" data-item-id="<?php echo e($item->id); ?>">
                                        <div class="row align-items-center">
                                            <div class="col-md-2 text-center">
                                                <?php if($item->foodItem->image): ?>
                                                    <img src="<?php echo e($item->foodItem->image_url); ?>" 
                                                         alt="<?php echo e($item->foodItem->name); ?>" 
                                                         class="img-fluid rounded"
                                                         style="max-height: 80px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-light rounded d-flex align-items-center justify-content-center" style="height: 80px; width: 80px;">
                                                        <i class="bi bi-image text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <div class="col-md-4">
                                                <h6 class="mb-1"><?php echo e($item->foodItem->name); ?></h6>
                                                <p class="text-muted small mb-0"><?php echo e(Str::limit($item->foodItem->description, 60)); ?></p>
                                                <span class="badge bg-secondary small"><?php echo e(ucfirst($item->foodItem->category)); ?></span>
                                            </div>
                                            
                                            <div class="col-md-2 text-center">
                                                <small class="text-muted">Price</small>
                                                <div class="fw-bold"><?php echo e($item->foodItem->formatted_price); ?></div>
                                            </div>
                                            
                                            <div class="col-md-2 text-center">
                                                <small class="text-muted">Quantity</small>
                                                <div class="quantity-controls mt-1">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="updateQuantity(<?php echo e($item->id); ?>, <?php echo e($item->quantity - 1); ?>)">-</button>
                                                    <span class="mx-2 fw-bold" id="quantity-<?php echo e($item->id); ?>"><?php echo e($item->quantity); ?></span>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="updateQuantity(<?php echo e($item->id); ?>, <?php echo e($item->quantity + 1); ?>)">+</button>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-1 text-center">
                                                <small class="text-muted">Subtotal</small>
                                                <div class="fw-bold text-primary" id="subtotal-<?php echo e($item->id); ?>"><?php echo e($item->formatted_subtotal); ?></div>
                                            </div>
                                            
                                            <div class="col-md-1 text-center">
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeItem(<?php echo e($item->id); ?>)" title="Remove item">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Cart Actions -->
                        <div class="mt-3">
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-outline-danger" onclick="clearCart()">
                                        <i class="bi bi-trash"></i> Clear Cart
                                    </button>
                                </div>
                                <div class="col-md-6 text-end">
                                    <a href="<?php echo e(route('menu')); ?>" class="btn btn-outline-primary">
                                        <i class="bi bi-plus-circle"></i> Add More Items
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Order Summary -->
                    <div class="col-lg-4">
                        <div class="card shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="bi bi-receipt"></i> Order Summary</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-3">
                                    <span>Subtotal:</span>
                                    <span id="cartSubtotal">RM <?php echo e(number_format($totalAmount, 2)); ?></span>
                                </div>
                                
                                <div class="d-flex justify-content-between mb-3">
                                    <span>Delivery Fee:</span>
                                    <span class="text-success">FREE</span>
                                </div>
                                
                                <div class="d-flex justify-content-between mb-3">
                                    <span>Tax (6% SST):</span>
                                    <span id="cartTax">RM <?php echo e(number_format($totalAmount * 0.06, 2)); ?></span>
                                </div>
                                
                                <hr>
                                
                                <div class="d-flex justify-content-between mb-4">
                                    <strong>Total:</strong>
                                    <strong class="text-primary" id="cartTotal">RM <?php echo e(number_format($totalAmount * 1.06, 2)); ?></strong>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="button" class="btn btn-primary btn-lg" onclick="proceedToCheckout()">
                                        <i class="bi bi-credit-card"></i> Proceed to Checkout
                                    </button>
                                    
                                    <small class="text-muted text-center mt-2">
                                        <i class="bi bi-shield-check"></i> 100% Halal Guaranteed
                                    </small>
                                </div>
                            </div>
                        </div>

                        <!-- Promo Code -->
                        <div class="card shadow-sm mt-3">
                            <div class="card-body">
                                <h6><i class="bi bi-tag"></i> Have a Promo Code?</h6>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Enter promo code" id="promoCode">
                                    <button class="btn btn-outline-secondary" type="button" onclick="applyPromo()">Apply</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <!-- Empty Cart -->
                <div class="text-center py-5">
                    <i class="bi bi-cart-x text-muted" style="font-size: 5rem;"></i>
                    <h3 class="mt-3">Your Cart is Empty</h3>
                    <p class="text-muted">Looks like you haven't added any items to your cart yet.</p>
                    <a href="<?php echo e(route('menu')); ?>" class="btn-get-started mt-3">
                        <i class="bi bi-grid-3x3-gap"></i> Browse Menu
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<!-- Success/Error Toast -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="cartToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
            <i class="bi bi-cart-check text-success me-2"></i>
            <strong class="me-auto">Cart Update</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body" id="toastBody">
            Cart updated successfully!
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmModalLabel">Confirm Action</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="confirmModalBody">
                Are you sure you want to proceed?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmButton">Confirm</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function updateQuantity(itemId, newQuantity) {
        if (newQuantity < 1) {
            removeItem(itemId);
            return;
        }
        
        if (newQuantity > 10) {
            showToast('Maximum quantity is 10 per item.', 'warning');
            return;
        }

        fetch(`/cart/update/${itemId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ quantity: newQuantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById(`quantity-${itemId}`).textContent = newQuantity;
                document.getElementById(`subtotal-${itemId}`).textContent = data.subtotal;
                updateTotals(data.total);
                showToast(data.message, 'success');
            } else {
                showToast('Failed to update cart.', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Failed to update cart.', 'error');
        });
    }

    function removeItem(itemId) {
        fetch(`/cart/remove/${itemId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector(`[data-item-id="${itemId}"]`).remove();
                showToast(data.message, 'success');
                
                // Check if cart is empty
                if (document.querySelectorAll('.cart-item').length === 0) {
                    location.reload();
                } else {
                    updateCartDisplay();
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Failed to remove item.', 'error');
        });
    }

    function clearCart() {
        document.getElementById('confirmModalBody').textContent = 'Are you sure you want to clear your entire cart?';
        document.getElementById('confirmButton').onclick = function() {
            fetch('/cart/clear', {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
            
            new bootstrap.Modal(document.getElementById('confirmModal')).hide();
        };
        
        new bootstrap.Modal(document.getElementById('confirmModal')).show();
    }

    function updateTotals(subtotal) {
        const tax = subtotal * 0.06;
        const total = subtotal + tax;
        
        document.getElementById('cartSubtotal').textContent = `RM ${subtotal.toFixed(2)}`;
        document.getElementById('cartTax').textContent = `RM ${tax.toFixed(2)}`;
        document.getElementById('cartTotal').textContent = `RM ${total.toFixed(2)}`;
    }

    function updateCartDisplay() {
        // Recalculate totals based on remaining items
        let subtotal = 0;
        document.querySelectorAll('.cart-item').forEach(item => {
            // This would need to calculate based on remaining items
        });
    }

    function proceedToCheckout() {
        // Redirect to checkout page (we'll implement this next)
        window.location.href = '/checkout';
    }

    function applyPromo() {
        const promoCode = document.getElementById('promoCode').value.trim();
        if (!promoCode) {
            showToast('Please enter a promo code.', 'warning');
            return;
        }
        
        // Placeholder for promo code functionality
        showToast('Promo code functionality coming soon!', 'info');
    }

    function showToast(message, type = 'success') {
        const toast = document.getElementById('cartToast');
        const toastBody = document.getElementById('toastBody');
        
        toastBody.textContent = message;
        
        // Update toast style based on type
        const toastHeader = toast.querySelector('.toast-header');
        toastHeader.className = 'toast-header';
        
        switch(type) {
            case 'success':
                toastHeader.classList.add('bg-success', 'text-white');
                break;
            case 'warning':
                toastHeader.classList.add('bg-warning', 'text-dark');
                break;
            case 'error':
                toastHeader.classList.add('bg-danger', 'text-white');
                break;
            default:
                toastHeader.classList.add('bg-info', 'text-white');
        }
        
        new bootstrap.Toast(toast).show();
    }
</script>
<?php $__env->stopPush(); ?>

<style>
.cart-item {
    transition: all 0.3s ease;
}

.cart-item:hover {
    background-color: #f8f9fa;
}

.quantity-controls {
    display: flex;
    align-items: center;
    justify-content: center;
}

.quantity-controls button {
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
}

@media (max-width: 768px) {
    .cart-item .row > div {
        margin-bottom: 10px;
        text-align: center !important;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webAppProject\resources\views/cart/index.blade.php ENDPATH**/ ?>